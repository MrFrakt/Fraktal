# Fraktal Core — Implementation Notes (Milestone 1, 2026-07-02)

*Scope: `Fraktal_Core` library + aggregate `Fraktal_Tests` gate + scaffold, implementing Core §2.2 (base classes), §3.2 (interfaces), §3.8/§3.15/§3.16 (provider/connector/carrier contracts), §6.1 (lifecycle), §6.5/§6.9(b)/§6.11 (step/condition/decision records), §7.2 (`FB_PermIntlk`), §8.2 (rollup), §8.8 (`E_Reason`). Source draft: `Specification/Guides/Fraktal_QuickStart_and_Suite.md`. Status: **compiles under TwinCAT 3.1.4024.75** (0 errors, 0 warnings) and has been deployed to a runtime and exercised end-to-end from the HMI over ADS. A **pinned compile in CI is still pending** — it needs a self-hosted Windows runner with licensed TwinCAT XAE; the source-level rules (naming, §4.4 prefixes, 4024 compatibility, contract usage) do run on every commit via `tools/plc_lint.py`. See "Bring-up" in README and `Specification/Reports/OBJECTIVES_AUDIT.md` (O10 G7).*

## 1. Draft pseudocode fixed in the implementation

| Draft construct | Problem | Implemented as |
|---|---|---|
| `_exec IN (E_ExecState.DONE, …)` | no set-membership operator in IEC ST | explicit `OR` chain in the Execute-drop reset |
| `SysTime()` | not a TwinCAT function | `F_Now()` — [TC3] wrapper over `Tc2_Utilities.F_GetSystemTime()` (UTC, 1601-epoch FILETIME → DT); one clock feeds all timestamps (Core §2.7) |
| `CONCAT3/4/5` (Annex C drafts) | Tc2_Standard `CONCAT` is 2-arg | not needed in M1; the M2 stall walk will chain 2-arg `CONCAT` (noted for the Unit base) |
| `_M_OnAbort` (base-classes draft) | §3.14 names the hook `OnAbort` | hook named `OnAbort`/`OnCyclic` per the §3.14 catalogue, with the call-`SUPER^`-first contract in the method headers |
| bare `FOR i := 1 TO _nChild` rollup | no null/bounds guards (Core §5.6) | `_M_Register` bounds-checked; rollup/tick guard `<> 0` with `AND_THEN` (Core §5.3 short-circuit rule) |

## 2. Contract reconciliations against Core §3.2 — **folded back into Core on 2026-07-02**

These compile-driven deviations are now normative: Core §3.2 (interface surfaces + rationale), §2.2 (hooks = the §3.14 family; bases implement `I_Module`), §5.7 (inherited rows proven once), and §8.8 (band-extensibility rule) were amended accordingly, each clause stating the §1.1 objective it serves. The list below is the original record:

- **`I_Module` has no `ErrorID` property.** Every module already exposes `ErrorID` as a PLCopen `VAR_OUTPUT` (§6.1); an identically-named interface property on the same FB does not compile. Callers use `GetFaultSummary().ReasonCode` (richer anyway). `FaultActive`/`State` remain.
- **`GetFaultSummary` returns `ST_Diagnostic`,** not the §3.2 text's `ST_FaultSummary` — the §8.8 record is the one every other clause (rollup §8.2, stall walk §6.9, PermIntlk §7.2) uses; a second summary type would duplicate it.
- **Recipe changeover is transactional.** `I_Module` exposes `PrepareRecipe(Model)`/`CommitRecipe()`/`AbortRecipe()`; types stage validated `ParCfg`, and composites recurse before the Unit publishes its new `Model`.
- **Generic command ids are `DINT`.** Per-type command enums cannot appear in a common interface. Both command-bearing tiers use `ExecuteCommand(Command : DINT)` and `AbortCommand()`; the typed PLCopen `Command`/`Execute` surface remains primary.
- **`FB_ModuleBase` implements `I_Module`; tier wrappers implement their tier interfaces.** `FB_CompositeModuleBase` owns child registration, recipe recursion, and rollup without implying that a Unit is an Equipment Module.
- **Published status is `ST_ModuleStatus`.** The abandoned tier-specific `ST_CmStatus` duplicate was removed.

## 3. `E_Reason` extensibility

IEC enums cannot be extended across libraries, but Core §8.8's model is "one number space, per-type bands." Implementation: `E_Reason` declares the **framework bands only** and deliberately omits `{attribute 'strict'}`, so a module type declares its band codes (10000+) as `DINT` constants in its own library and assigns them into `ST_Diagnostic.ReasonCode` / `_M_Fault` directly. The §8.8 registry remains the single collision authority; the generated catalog (§8.8) is built from the union of the framework enum and the registered type bands.

## 4. Numbers newly pinned (Core §8.8 registry updated accordingly)

`TIMEOUT`=2001 · `PERMISSIVE_NOT_MET`=2002 · `INTERLOCK_DROPPED`=2003 · `RECIPE_INVALID`=2004 · `STEP_STALLED`=2005 (already pinned) · `RETRY_EXHAUSTED`=2006 (was named but unnumbered) · new sub-range **2900–2909 framework self-test** with `TEST_FAULT`=2901 (used only by the base suite; never raised in production). These match the values Annex A already declared (2001–2004), so docs, annexes, and code now agree.

## 5. Design decisions

- **Body = one inherited `Cyclic()` call.** Calling a module as `inst()` and through
  `inst.Cyclic()` (the `I_Module` path a parent uses) must execute the same lifecycle.
  TwinCAT source objects for concrete types therefore keep the generated FB body as the
  single statement `Cyclic();`; they put no application logic there. Per-scan extension
  work goes in an `OnCyclic` override (base first, per §3.14.2), and device logic stays in
  `_M_Dispatch`. This is the enforceable invariant; “concrete types do not write a body”
  was inaccurate for the shipped XAE objects.
- **`_M_Complete` / `_M_Fault` / `_M_FaultDiag` / `_M_ClearDiag` / `_M_SetName`** are the whole protected toolkit a type needs; `_M_Fault` stamps `SourcePath`/`Since` (`F_Now`), `_M_FaultDiag` adopts a diagnostic *verbatim* (rollup/connector, §8.2 — the child's `SourcePath` survives).
- **`FB_PermIntlk`** implements the full §7.2 canonical surface; `Since` is stamped only when the first-out *changes*; `SourcePath` is left for the owner to set when copying `Diagnostic` up (per the §7.2 usage contract). Bypass honors §7.3 (only `Bypassable`, always flagged via `AnyBypassed`).
- **The EM base extends the CM base** (per the draft): it *adds* `_M_Register`/`_M_TickChildren`/`_M_RollupFault` and overrides `ModuleType`.
- **Test coverage:** `FB_Base_Tests` proves **T1, T2, T4** once for every inheriting type, plus the **rollup (T6 at base level)** via `FB_ProbeEM` — asserting the child's `SourcePath` (`Test.EM.ChildB`) survives adoption verbatim. `FB_PermIntlk_Tests` proves first-out ordering (a later FALSE never masks an earlier one) and the bypass rules. Concrete types remain responsible for T2/T3/T5 with *their* reasons (scaffold) and tier rows per §5.7.
- **Scaffold is born RED** (Quick-start §2): `FB_TemplateCM_Tests` ships with failing T2/T3/T5 placeholders (`16#FFFF_FFFF` expected values, `AssertTrue(FALSE)`) so the §5.7 checklist drives development; T1/T4 are inherited and not repeated.
- **`OPC.UA.DA` pragmas [TC3] (superseded by §67):** the first implementation placed these on base classes and also marked every root Unit instance. Live TF6100 evidence later showed definition-level publication projecting implementation references as duplicate browse trees; §67 replaces this with deployed-root-only publication.

## 6. Known M1 limits → Milestone plan

- **M2 — `FB_UnitBase`:** mode model (§3.4, `_M_Supports`, graceful cascade §3.7 via `__QUERYINTERFACE` [TC3]), the step-chain base with `_M_SetStep`/`_M_Await` condition records, the §6.9(c) stall walk (2-arg `CONCAT` chains), `OnInit`/`OnCommandStart`/`OnModeChanged`/`OnModeExit` hooks, decision queue (§6.11).
- **M3 — providers & connectors:** `FB_LocalRecipeProvider` with SchemaVersion migrate-or-fault (§3.8), an `FB_DeviceConnectorBase` (heartbeat, `LinkTimeout`, HOLD/ABORT/MODE_STOP reaction, bounded backoff, no self-resume — §3.15).
- **M4 — first shipping type:** `FB_CylinderCM` + `FB_ClampEM` from Annexes A/B against a sim plant model (`FB_CylinderSim`, §5.7 should-clause), turning the Annex H suite into real CI.
- The **`SimForceInterlock` SIM-only hook** (§5.7) is deferred to M4 with the first HAL-bound type; the scaffold marks where it belongs.

## 7. Timing capture & time classification (Core §8.11.4) — M1.x, 2026-07-02

Implements the cycle-time-profile amendment, including clause (f) time classification. Design points:
- **Two clocks, deliberately (§8.11.4(e) / TC3 §8.11):** durations from the monotonic ms clock (`TIME()` differenced as `DWORD`, wrap-safe across the ~49-day rollover); wall-clock `Started`/stamps from `F_Now()` so profiles align across stations (§2.7). Never mix the two.
- **`F_TimingUpdate` is a pure function** (running mean `avg += (x−avg)/n`) so the aggregate math is unit-tested with exact values (100/200/300 → avg 200 in `FB_Timing_Tests`).
- **Base-class capture is transition-driven:** the row closes on `BUSY → DONE/ERROR/ABORTED` via `_prevExec`, so faulted/aborted commands are measured too. A type contributes only `_M_TagCommand(TO_DINT(Command), '<label>')` — one idempotent line, in the scaffold; untagged types still get `LastCmdTime` and an id-0 row.
- **Classification is opt-in per wait step (§8.11.4(f)):** `StepChanged(…, TimeClass := E_TimeClass.WAIT_UPSTREAM)` — default `WORK`, so non-wait steps cost nothing. The profiler accumulates `ByClass[TO_INT(time class)]` and publishes `WorkTime` (**the real cycle time**) and `WaitTime` at `CycleComplete`; the suite asserts `Total = WorkTime + WaitTime` and that classes survive into both the waterfall and the per-step aggregates. `WAIT_UPSTREAM`/`WAIT_DOWNSTREAM` are the per-step attribution of §8.11.3 Starved/Blocked; M2's chain base may auto-attribute them from the Unit's Starved/Blocked conditions (explicit class wins).
- **Find-or-allocate rows, fixed arrays:** `Count = 0` marks a free slot; overflow sets `Truncated`/`StatsTruncated` rather than growing — capture never allocates at runtime.
- **`FB_CycleProfiler` is event-driven** (`StepChanged`/`CycleComplete`, no cyclic body): a refreshed same-step call is a no-op (but may re-declare the class), the first step opens the cycle (§8.11.1 start marker), `ResetStats` exists but the *caller* must log the reset (§8.11.2).
- **M2 wiring:** the Unit/step-chain base will call `StepChanged` inside `_M_SetStep` (forwarding the step record's class) and `CycleComplete` at `N999` — step timing and classification become zero-effort by construction; until then a Unit adds the two calls once (Annex C §C.6 note).
- **HMI:** `Timing`, `Current`, `LastCycle`, `StepStats` are fixed framework DUTs under the base-class pragmas — the §3.13 waterfall (coloured by class, Total/Work/waits header) and Pareto bind to them with no per-type wiring.

## 8. M2–M4: the lifecycle family completed (2026-07-02)

**M2 — `FB_UnitBase`** (now extends `FB_CompositeModuleBase`, implements `I_Unit`): modes reject unsupported requests gracefully; Start/Stop reuse the §6.1 lifecycle; step records power pending diagnostics, rollup, Starved/Blocked, and profiling. A non-graceful mode change performs an **immediate non-safety software abort**; `OnModeExit` stages graceful stopping. The one-slot decision and cycle profiler remain inherited services.

**M3 — `FB_DeviceConnectorBase`** (§3.15): abstract transport quartet `_M_Open/_M_Close/_M_HbStart/_M_HbPoll : E_HbResult`; heartbeat, `LinkTimeout` loss confirm, `DEVICE_PROTOCOL_ERROR` vs `LINK_TIMEOUT` first-outs, bounded exponential backoff (DINT-ms doubling capped at `BackoffMax`), session drop on loss, **no self-resume** (the fronting CM owns `Reaction`). Row **T7 proven once** (§5.7 amendment). **`FB_LocalRecipeProvider`** (§3.8): generic validation via the new **SchemaVersion-first-member rule** (spec amendment) — stored first-`UINT` vs target's initialized first-`UINT`; unknown id, size mismatch, or schema mismatch → `Load = FALSE`, caller faults `RECIPE_INVALID`; `MEMCPY` only after full validation (never partial).

**M4 — `Fraktal_Modules`** (separate reusable-module library, own §8.8 band constants `PL_ModuleReasons`): `FB_CylinderCM` provides interlock-first device logic and direction-specific diagnostics; `FB_ClampEM` provides parallel fork/join, partner abort, settle/confirm, and transactional recipe recursion; `FB_CylinderSim` is the §5.7 plant model.

**Suites** (all in one open-ended gate, §6.8/H.6): `FB_Unit_Tests` (stall text asserted verbatim: `'Step 100 StepA stalled'`; Starved from wait class; stop-after-cycle; 2-step profile published; E-stop-by-default mode change), `FB_Connector_Tests` (T7: healthy beat links; protocol FAIL and silent LINK_TIMEOUT paths, `SourcePath` asserted), `FB_CylinderCM_Tests` (T2/T3/T5 with the type's own reasons + functional completion against the sim; deterministic timing via `T#0S` timeouts), `FB_ClampEM_Tests` (H.5 rollup: `ClampStation.CylB` verbatim). T1/T4 are not repeated per type (§5.7).

**Compile-plausibility caveats to watch at first build:** `SEL` on `STRING` operands in `FB_CylinderCM` (replace with IF if the pinned compiler objects), `DINT_TO_TIME`/`TIME_TO_DINT` availability, and interface `= 0` comparisons.

## 9. Pre-HMI gap closure (M5, 2026-07-02)

The pre-HMI review found that the HMI-facing surface was accidentally accessor-shaped: `Name`/`State`/`FaultActive` were properties and the diagnostic only reachable via `GetFaultSummary()` — **none of which appear in the OPC UA namespace** (TF6100 publishes symbols, not accessors). That also made the base non-conformant with §6.9(a)'s "publish the diagnostic each scan". Closed by: **`ST_ModuleStatus` data mirror** refreshed every scan in `FB_ControlModuleBase` (name set in `_M_SetName`; on Units the live `Pending` stall surfaces on the mirror whenever no fault is active); **§6.9(a) ring buffer** (`History`, fixed size, newest at `HistoryHead`, pushed on the ERROR rising edge); **§8.11 counters** (`GoodCount`/`NokCount` + public `CountGood`/`CountNok`). Spec: new **§3.10(a′)** ("the HMI contract is data, not accessors") and a **§3.13 discovery-and-binding bullet** (module marker = the `Status` member; narrow write surface). `HMI_CONTRACT.md` is the bind table the HMI phase builds against. Deliberately deferred to the HMI phase, recorded there: §7.6 manual-function release gating (item #1, blocks any HMI write of `Command`/`Execute`), §8.3 alarm ack workflow, §8.8 text catalog. Proven in `FB_Hmi_Tests` (mirror fields, pending-on-mirror, counters).

## 10. Pre-HMI regression fix (2026-07-04)

Audit before starting the HMI found one **compile-blocking regression**: the `Model : ST_ModelId` member declaration in `FB_UnitBase` had been dropped during a later edit to that FB's `VAR` block (which added the HMI data-mirror members `Status`/`History`/`GoodCount`/`NokCount`). The `SetModel` method (`Model := Id`) and `ModelCode` property (`Model.ModelCode`) both reference it, so the type would not have compiled. **Restored** the declaration between `StallTime` and `GoodCount`. Verified: `Model`, `Status`, `History`, `HistoryHead`, `GoodCount`, `NokCount`, `Pending`, `Profiler`, `CurrentStep` all resolve in `FB_UnitBase` through the inheritance chain; all 80 files pass XML/lint/VAR-balance/project-list gates.

Also confirmed sound (not regressions): the HMI-prep additions from the prior session — `ST_ModuleStatus` data mirror refreshed each scan by `FB_ControlModuleBase` (+ `Pending` overlay in `FB_UnitBase`), the §6.9(a) `History` ring via `_M_PushHistory`, `CountGood`/`CountNok`, `HMI_CONTRACT.md`, and `FB_Hmi_Tests` — are internally consistent, wired into the runner, and present in the project compile lists. There is correctly **no `FB_Hmi` POU**: per §3.10(a′) the HMI binds published *data*, not a PLC-side HMI object.

## 11. Alarm & event history — §8.3 implemented (2026-07-04)

Spec: §8.3 rewritten from a two-line promise into the full contract — (a) `ST_AlarmEvent` record with `Duration` (monotonic come→gone per the two-clock rule) and synchronized `ComeAt/GoneAt/ResetAt`; (b) `E_ResetClass`: **AUTO_RESET** closes when the condition re-establishes, **MANUAL_RESET** stays blocking (`WAIT_RESET`) until a deliberate, release-gated operator reset — never self-closing (§9.3 principle), and the Unit **refuses `Start`** while any such event is open; (c) automatic capture: `FB_UnitBase` raises an ERROR/MANUAL_RESET event from the rolled-up first-out on ERROR entry and marks it gone on exit — the event IS the diagnostic plus lifecycle, nothing double-authored (O1/O3); (d) per-Unit `Active[]` + closed `Ring[]` browsable over OPC UA; **`I_EventSink`** invoked at come and close so a DB/historian adapter subscribes later without touching the log — interface normative now, adapters deferred by design (exactly the user's "we don't have to code this now"); (e) ISA-18.2 state mapping, reset doubles as acknowledge.

Code: `E_Severity`/`E_ResetClass`/`E_AlarmState`/`ST_AlarmEvent`, `I_EventSink`, `FB_AlarmLog` (Raise/RaiseDiag/Gone/OperatorReset/SetSink, fixed arrays, `Blocking`), UnitBase wiring (`AlarmLog`, `_faultEvt`, Start gate, public `OperatorReset`). Severity is the sole presentation/priority axis. Suite `FB_AlarmLog_Tests`: AUTO closes with Duration into the ring; MANUAL survives condition-gone and unblocks only on OperatorReset; Unit refuses Start while blocking.

**Honest gap:** the third test asserts Start-blocking by raising through the log directly; the *automatic* ERROR-entry capture path in `OnCyclic` is wired but not yet asserted by a test (FB_ProbeUnit has no easy fault injection). Add a `SimFaultStep` input to the probe and assert `AlarmLog.NActive = 1` after a forced fault — small item for the next pass or first compile session.

## 12. User access levels — §7.7 implemented (2026-07-04)

New Core §7.7: access level as the **who** dimension of release, ANDed with §7.2–§7.6's machine dimensions. Ordinal `E_AccessLevel` (NONE<OPERATOR<TECHNICIAN<ENGINEER<ADMIN); nine `E_GatedAction`s covering exactly the user's list (data read/write, manual — with per-function override via §7.6 —, changeover, mode change, start/stop, alarm history, alarm reset, policy edit). **Per-station policy** = persistent station config (§3.8a); **shipped default fully open** (every threshold NONE ⇒ no login needed — the deliberate-decision principle: locking down is a commissioning choice per §14 checklist, never silent). `I_AccessProvider` + `FB_LocalAccessProvider` default (persistent user/PIN table) mirror the provider pattern; `FB_AccessManager` per root: data-driven login per §3.10(a′) (methods are invisible to OPC UA), secret cleared after every attempt, idle auto-logout, audit via §8.3 MESSAGE events. Gated in `FB_UnitBase`: `SetMode`/`SetModel`/`Start`/`Stop`/`OperatorReset`. Cascade safety: thresholds enforce at the root the HMI addresses; framework-internal calls are trusted (documented in §7.7(c)) — with fully-open child defaults the cascade is unaffected in every configuration. Suite `FB_Access_Tests`: open-by-default; threshold denial audited; wrong-PIN rejected; login grants; secret cleared; logout re-denies. Deferred to their owning phases: `DATA_WRITE` enforcement in the generic editor and per-function `MANUAL` in the §7.6 implementation (both spec'd now). Security caveat, stated honestly: the local PIN travels the OPC UA write path — pair with server-side encryption/auth (§7.7(d), TC3 §11.1) for anything beyond shop-floor-trust deployments.

## 13. Configurable cylinder Control Module — FB_ConfigurableCylinderCM (2026-07-04)

A production-grade reusable cylinder CM alongside the Annex-A/B teaching `FB_CylinderCM`. Answers the brief (2 optional home/work sensors, 5 s default max move time) and adds what a real cylinder CM needs, each justified by an objective:
- **Optional AND redundant sensors (0..N per position).** `Cfg.HomeSensorCount`/`WorkSensorCount` (0 = sensorless/time-based; N up to `PL_Fraktal.MAX_POS_SENSORS`, default 2, raise for 2oo3). HAL carries sensor **arrays** `HomeFb[]`/`WorkFb[]`. **Arrival = ALL wired sensors TRUE** (`_M_PosArrived`, AND-combine — the safest rule for safety cylinders). One type serves sensorless, single-sensor, and duplex/redundant actuators (O4/O1).
- **Your timing.** `MoveTimeout := T#5S` default; `SettleTime` debounce so a chattering reed switch can't false-complete; `TravelTime` for the sensorless path (must be `< MoveTimeout`, checked).
- **Plausibility & integrity faults** (own §8.8 band 10200s): `CYL_WORK/HOME_NOT_REACHED` (timeout), `CYL_DISCREPANCY` (redundant sensors for one position disagree longer than `DiscrepancyTime` — dual-channel monitoring, like a safety-gate discrepancy timer; checked continuously in OnCyclic), `CYL_BOTH_SENSORS` (home+work both confirmed — implausible), `CYL_SENSOR_LOST` (reserved), `CYL_CFG_INVALID` (count out of range or bad travel/timeout — bad config faults, never runs wrong; O3/O7).
- **Single- or double-acting** (`SingleActing`: spring return drives home with no solenoid), **fail-safe abort** (`DeenergizeOnAbort` default, or drive to `SafePosOnAbort`) per §3.14.2, **startup position resolve** (`Position`/`AtPos` from whatever sensors exist, §3.12).
- Inherits the whole lifecycle: edge/handshake, ErrorID, per-command timing (§8.11.4 `TO_HOME`/`TO_WORK` tags), abort routing. `FB_ConfigurableCylinderSim` (per-sensor stuck-mask to inject faults) + `FB_ConfigurableCylinderCM_Tests` (duplex AND-arrival, discrepancy, sensorless, and timeout cases). SIM force hook for interlock (§5.7).

## 14. Fieldbus ADS adapter — contract sketch (2026-07-04)

Deliverable so an integrator can wire real EtherCAT data. Not runnable against a master here — a *seam + guide*, honest about what needs InfoSys verification.
- **PLC seam:** `I_FieldbusScanner` (Scan / RefreshValues / ForceChannel) + `FB_EcFieldbusScanner` skeleton naming the real `Tc2_EtherCAT` building blocks (`FB_EcGetSlaveCount`/`GetAllSlaveStates`/`GetSlaveIdentity`, `FB_CoeSdoReadEx`) with TODO bodies and a working AL-state→`E_NodeState` map (`_M_MapState`, low-nibble 0x01/0x02/0x04/0x08 + 0x10 error bit). Flat node table (`MAX_BUS_NODES`).
- **HMI seam (historical):** this pass originally added an `EtherCatGatewayRepository` stub; §41 supersedes it with the native OPC UA repository and versioned Web gateway client.
- **Doc:** `fraktal-tc3/FIELDBUS_ADS_ADAPTER.md` — two deployment paths (A: PLC-published `ST_BusNode` over OPC UA, works on all 4 platforms incl. Web; B: direct client, no Web without a gateway), the channel-value design (read the process image via HAL references, not raw addresses — keeps the channel↔module link exact), the honestly-flagged force path (write mapped output vs true ADS force), and an acceptance checklist. TC3 §10.6 points to it.
- **Objectives:** O4/O8 (any bus fills the same table; neutral node state), O1 (fieldbus knowledge in one place, Path A), O3 (topology + alarms are one source, not a side-channel). The force path re-uses §7.6/§7.7 gating + §8.3 audit — the caller gates and logs, the scanner only writes.

## 15. Manual command surface — §7.6.1 (2026-07-04)

Single manual path (MANUAL-mode-only, no override). Each command-bearing module publishes a self-describing `{value,label}` catalog. `FB_ModuleBase` owns the generic request latch, and `FB_UnitBase.ManualCommandTo` is the mode/access/release gate. `FB_ConfigurableCylinderCM` demonstrates that the HMI, generic interface, and typed PLCopen path all reach the same validated dispatch and interlocks. `FB_ManualCmd_Tests` covers publication, rejection outside MANUAL, and acceptance in MANUAL.

## 16. Mode control bar + switch policy + run styles — §3.4.1/§3.4.2 (2026-07-04)

*(Refinements: `_M_StepGate` gained a per-step `Steppable` input — a step passed as FALSE runs through even in SINGLE_STEP/HOLD_TO_RUN, both styles honouring it identically. `StopPending` property (TRUE while stop requested + still BUSY) drives a blinking stop button in the HMI. On the pinned 4024 binding every method input is explicit; optional method inputs require 4026+.)*


Resolved the tension in the brief (immediate-interrupt vs safe-finish vs disabled-per-mode) with the rule **Stop is graceful, mode-change is the interrupt**, and made the interrupt behaviour per-mode policy. Spec §3.4.1: two orthogonal axes — `E_ModeSwitchShield` (INTERRUPTIBLE/CONFIRM/BLOCKED_WHILE_RUNNING) × `E_ModeSwitchStyle` (GRACEFUL/IMMEDIATE) — as `ST_ModePolicy[E_Mode]`, station config with safety defaults (AUTO=CONFIRM+GRACEFUL, CHANGEOVER/CALIBRATION=BLOCKED, HOME=INTERRUPTIBLE+IMMEDIATE). The policy of the mode being LEFT governs. §3.4.2: `E_RunStyle` (CONTINUOUS/SINGLE_STEP/HOLD_TO_RUN), optional per mode via `_M_SupportsRunStyle`, consulted by the sequence author through `_M_StepGate` at step boundaries. **HOLD_TO_RUN over HMI is explicitly NON-SAFETY** (no dead-man; interlocks still apply) — spec callout + code comments.
Code (FB_UnitBase): `ModePolicy[]`, `RunStyle`, shield check in `SetMode` (BLOCKED returns FALSE while BUSY — graceful rejection, not a fault), style applied in the pending-mode path (GRACEFUL sets `_stopReq` to finish the cycle; IMMEDIATE keeps the OnModeExit/OnAbort path), `_M_InitModePolicy`, `SetRunStyle`/`_M_SupportsRunStyle`, `StepRequest`, `SetHoldRun`, `_M_StepGate`. 116 PLC files pass.
HMI: `ModeBar` on the right (mode icon + selector top, play/stop bottom, step toggle), reads `running`/`runStyle`/`supportedModes`/`supportedRunStyles`/`modePolicy`; prompts/blocks per policy; MANUAL hides run controls; hold-to-run is press-and-hold labelled non-safety. Repo methods `setRunStyle`/`stepRequest`/`setHoldRun` on both impls. 19 Dart files pass.

## 17. Show-why-blocked release transparency — §7.6.0 (2026-07-04)

Rule: pressing any not-released control shows why. Full rollup (user's choice), persistent bottom panel (user's choice). Spec §7.6.0: every gated action publishes, on demand, the complete set of withholding reasons (not first-out) across mode/access/alarm/interlock sources; live; read-only (never bypasses). Code: `ST_ReleaseReason` DUT; `FB_PermIntlk.AppendFailed` (enumerates every defined+FALSE+non-bypassed condition into a caller list); `FB_UnitBase.WhyBlocked(action, list)` assembles framework reasons (access via Access.Permits, mode-pending, AlarmLog.Blocking, not-READY, not-MANUAL) + delegates child interlocks to overridable `_M_AppendModuleReasons`; probe Unit demonstrates the override via `Cyl.Intlk.AppendFailed`. 117 PLC files pass. HMI: `ReleaseReason` + `ModuleNode.blockReasons` (per GatedAction), `whyBlocked` on both repos, `WhyBlockedPanel` at the bottom of the module view (auto-updates, shows 'released' when free), blocked Start (amber, reveals why) + blocked manual buttons (reveal panel) — pressing a blocked control shows reasons instead of no-op. 20 Dart files pass. Objective O3 (diagnosability) applied pre-action, not just post-fault.

## 18. Release panel wiring fix — blocked buttons now actually open it (2026-07-04)

### 18.1 Extended to all gated controls (2026-07-04)
Applied the same act-or-explain rule to the remaining controls. PLC: `FB_UnitBase.WhyBlockedAction(E_GatedAction)` — a general rollup (access + per-action state: CHANGEOVER not-while-running, ALARM_RESET needs a blocking alarm, MODE_CHANGE not-while-pending) using the same predicate as the gates; Start keeps its richer `WhyBlockedStart` (interlocks), manual keeps `WhyBlockedManual` (target). HMI: generic `whyBlockedAction`/`showWhyBlockedAction`; mode-bar **step** and module-detail **Stop**, **operator-reset**, **changeover** now explain-when-blocked via the release panel (changeover made always-visible instead of hidden below access). **Force** (fieldbus, channel-scoped not Unit-scoped) explains inline via a snackbar rather than the Unit panel — routing a channel concern through the Unit release report would be a category error. Every gated control is now pressable and either acts or explains; no silent dead buttons remain. 20 Dart + PLC gates pass.


Audit prompted by 'are the buttons ready to open it when not released?' found the honest answer was NO/inconsistent: (1) the mode-bar Start used `onPressed: permits && !stopPending ? .. : null` — a null onPressed can't fire, so the access-denied case was a DEAD button that couldn't open the panel; (2) two parallel release mechanisms had accreted across turns — `blockReasons`(node map)+`showWhyBlocked`+`why_blocked_panel.dart` vs this turn's PLC-query `releaseReport`+`showWhyBlockedStart/Manual`+`release_panel.dart` — with the mode bar mixing them; (3) module_detail had a duplicate Start/Stop (`: null` when blocked, never explained); (4) the dead sim `_blockReasonsA` built `ReleaseReason(str, str)` — a signature that no longer matched the domain (`description, kind`) and would not compile. Fix: consolidated on the PLC-query path, deleted `why_blocked_panel.dart` + `blockReasons` + `blockPanel*` + dead `whyBlocked(singular)`; made every blocked-press (mode-bar Start, module_detail Start, manual buttons) stay pressable and call `showWhyBlockedStart/Manual` (act-or-explain); sim `whyBlockedStart` returns reasons for all four causes so the panel is never empty. Rule now uniform: a blocked control is pressable and either acts or explains — never a silent dead button. 20 Dart files pass.

## 19. Rename WhyBlocked → ReleaseReport (2026-07-04)

Renamed the live release-query API for consistency with `ST_ReleaseReport` / the release panel: PLC `WhyBlockedStart/Manual/Action` → `ReleaseReportStart/Manual/Action`; HMI `whyBlocked*` → `releaseReport*`, `showWhyBlocked*` → `showReleaseReport*`. The rename also flushed out **orphaned dead code** from the earlier (list-based) release iteration that the prior consolidation had missed: `FB_UnitBase.WhyBlocked : INT` and its `_M_AppendModuleReasons` hook (uncalled) were deleted, and stale `WhyBlocked`/`why_blocked_panel` references in the spec §7.8 and HMI_CONTRACT were updated (a stale contract paragraph removed). Historical change-log entries in this file (§17/§18) intentionally retain the old names — they record what the code was called at the time. 120 PLC + 20 Dart files pass; reference audit clean.

## 20. AAS / digital nameplate — verification & completion (2026-07-11)

Follow-up to the trends gap analysis (item 2). Found a prior session had already built most of it: §3.10.1 spec, `ST_Nameplate` (IDTA-02006-shaped), `SetNameplate` on `FB_ControlModuleBase` (inherits everywhere), HMI `Nameplate` domain + `NameplateCard` + sim data, and **Annex K** (AAS/IEC 63278 mapping, sibling of Annex J). This session verified and completed rather than duplicated:
- **Fixed compile-blocking literal `\n` bugs**: `SetNameplate`'s body (prior session) and `FB_ProbeUnitManual`'s `SetAir`/`_M_AppendInterlocks` (this conversation's own earlier edit) contained literal backslash-n instead of newlines — XML-valid, VAR-balanced, invisible to the structural gates, but not compilable ST. Fixed both files (8 occurrences); added a literal-`\n` scan to the gate run.
- **Example now honours the §3.10.1 'shall'**: `MAIN` publishes nameplates for both root Units at the instantiation site (per-serial identity, shared type data), demonstrating that identity belongs to the machine builder, not the type.
- **`Nameplate_roundtrip` test** added to `FB_Hmi_Tests` (nameplate is part of the HMI contract); first version referenced a nonexistent `_probe`, caught and corrected to `_p` before delivery.
- Audit extended to annex letters A–K; HMI_CONTRACT gained the nameplate section. 121 PLC files + Dart pass.

## 21. OEE + trend HMI — §8.5.1 (2026-07-11)

Trends gap item 3. OEE is a derivation from existing contracts (GoodCount/NokCount §8.11, ExecState §6.1, Blocking §8.3) — only time accounting added. Spec §8.5.1: run/down/idle buckets per scan (idle excluded from A — no demand ≠ downtime; buckets published so deployments re-derive); A×P×Q with per-factor validity, invalid factors OMITTED from the product (never 100%, O7); Performance only with a configured per-model ideal cycle (§3.8), capped at 1.0; bounded trend ring (60 × 1 min defaults), long-horizon = historian; ResetOee DATA_WRITE-gated + §8.3-audited.
Code: ST_Oee/ST_OeeSample; FB_UnitBase `_M_OeeUpdate` (F_Now deltas, UDINT-ms wrap-safe subtraction) split from pure `_M_OeeCompute` (testable without clock control), SetIdealCycle, ResetOee. Tests FB_Oee_Tests via probe driver: Q from counters, A from buckets, invalid-P omitted (OEE=A×Q proves no fake 100%), P cap at 1.0. Time *accumulation* is runtime-verified, stated in the suite header. 124 PLC files pass.
HMI: OeeSnapshot domain, OeeCard (exception colouring vs 0.85 target, per-factor bars, '—' for invalid, CustomPaint sparkline — zero packages), resetOee on all repos, act-or-explain reset via the release panel. Sim: quality live from counters, availability dips on the CylB fault, 24-sample trend. 20 Dart files pass.
Watch items for first compile: TIME_TO_UDINT (recurring), REAL comparisons in TcUnit (AssertEquals_REAL Delta signature).

## 22. Alarm shelving + rationalization — §8.9/§8.10 (2026-07-12)

Roadmap closer. Spec already governed shelving (§8.10); added the hard rule: **shelving suppresses annunciation, never control** (shelved blocking alarm still blocks; interlocks/release reports untouched; SAFETY never shelvable; unrationalized reasons not shelvable — rationalize first).
Code: E_GatedAction += ALARM_SHELVE=9 (ordinal-safe append; ST_AccessPolicy widened 0..9); ST_AlarmEvent += Shelved/ShelvedUntil (appended, mirror-safe); ST_AlarmMeta + FB_AlarmLog.RegisterMeta/Meta catalog; FB_AlarmLog.Shelve/Unshelve (SAFETY+meta checks, capped at MAX_SHELF_S, self-logging) + Cyclic auto-expiry countdown (F_Now deltas), ticked from FB_UnitBase; gated ShelveAlarm/UnshelveAlarm on the Unit. MAIN registers example rationalization (discrepancy non-shelvable, work-timeout shelvable). Tests FB_Shelve_Tests: unrationalized refused, SAFETY refused, **shelved-still-blocks (the O7 test)**; expiry timing runtime-verified.
**Collisions found & fixed while wiring:** (1) `CYL_BOTH_SENSORS` declared TWICE in PL_ModuleReasons (10103 + 10203) — duplicate-identifier compile error; production one renamed CYL_POS_IMPLAUSIBLE. (2) The basic-cylinder band 10201–10206 **squatted on the axis CM's registered band 10201–10204** (§8.8 registry = one number space) — renumbered to 10110–10116 inside the cylinder CM 100-block and registered. Audit extended: GVL duplicate scan + band-squat check now run every pass.
HMI: GatedAction.alarmShelve (ordinal 9 verified), AlarmEvent += reasonCode+shelved, AlarmMeta joined onto rows ('→ operator action'), shelved rows de-emphasized + banner-excluded (never hidden), shelve/unshelve buttons with act-or-explain. 126 PLC + 20 Dart pass.

## 23. Release implementation audit — hidden issues found & fixed (2026-07-12)

User-requested audit of §7.8 (PLC + HMI). Verified clean: FB_PermIntlk.AppendFailed member usage (_conds/.Defined/.Description/.Reason/.Bypassable, _bypass, Cond — all exist as used); AlarmLog.Raise call-site parameter names (Kind/Reason/Text/Source/Severity/Category/ResetClass match); E_Reason.NONE exists; module-detail Start/Stop are Unit-only; ReleaseReason ctor usage matches the domain.
Three real issues found and fixed:
1. **Sim query≠gate drift (O7 violation):** `releaseReportStart`'s mode reason was gated on `!_convWarn` — a ConveyorB flag unrelated to StationA — so a blocked-by-mode Start could report Released=TRUE. Also sim `start()` ignored mode entirely while the query reported a mode reason. Fixed both: reason condition is `_modeA != auto`; `start()` gate is now the same predicate the query reports.
2. **Stale release panel:** nothing re-ran the query while visible, so "stays while blocked / clears when released" and the panel's green 'Now released' state could never occur. Fixed: app-state stores the active query closure and re-runs it on every forest update (re-entrancy-guarded); clearRelease drops it. The panel is now live, matching §7.8's contract.
3. **ReleaseReportManual originally ignored its exact target and command:** the selected child's §7.6 conditions couldn't be appended, and a directional device could not distinguish extend from retract. The query and hook now carry `(TargetPath, Value, Report)`; the base preserves its Unit-level fallback while concrete Units may delegate to the selected child's pure release query.
Known remaining (unchanged, cosmetic): mode-bar Stop-while-running-without-access falls back to releaseReportStart. All gates pass.

## 24. Full-codebase semantic audit — both PLC and HMI (2026-07-12)

New checks beyond the structural gates: (1) named-parameter call sites vs actual METHOD signatures across all POUs; (2) every `PL_*.<CONST>` reference exists in its GVL; (3) every `E_*.<MEMBER>` reference exists in its enum (proper parser incl. single-line enums); (4) method calls on typed FB instances resolve through inheritance; (5) orphaned-public-method scan; (6) full HMI↔PLC enum-ordinal matrix (15 pairs); (7) both repositories implement all 20 contract methods; (8) all `app.<x>` UI references exist in app_state.

**Compile-blocking bugs found & fixed (root cause: `if X not in file` idempotency guards silently no-op'ing when an OLD artifact already carried the name):**
1. `FB_PermIntlk.AppendFailed` was still the OLD §7.6.0 list-based signature (`List/Count/Source`) — the §7.8 guard skipped writing the Report-based one; every current call site targeted a nonexistent signature. Replaced (verified single, Report-based).
2. Four `PL_Fraktal` constants never landed (`MAX_OEE_SAMPLES`, `OEE_SAMPLE_MS`, `MAX_ALARM_META`, `MAX_SHELF_S`): `MAX_RELEASE_REASONS` already existed at 24 (not the expected 16), so the OEE anchor missed and each later constant chained on the previous missing one — a silent cascade. All four added with post-verification.
3. Invalid event-kind members in `FB_Shelve_Tests` exposed a duplicate taxonomy. Alarm presentation now uses the single `E_Severity` axis.
4. Orphaned `_M_AppendModuleReasons` override in FB_ProbeUnitManual (base counterpart deleted in the rename turn) calling the old AppendFailed signature — deleted.
**HMI:** all contract enum ordinals match; repositories are complete and UI→state references are clean. Fixed `_Blink` running its ticker permanently (now animates only while active). `E_Severity` is mirrored as Dart `Severity`; event kind is no longer a second priority axis. Remaining orphan-scan hits are intentional HMI/OPC-UA entry points and adapter seams.
**Process change:** idempotency guards are retired in favour of anchored edits with post-assertions; the combined semantic gate (checks 1–4) joins the standard gate run.

## 25. TCP/IP device CMs — byte-transport seam + ASCII device base (2026-07-12)

Answering "do we have a base for TCP/IP devices (Keyence IV3, Datalogic Matrix 220)?": we had the *upper* half (FB_DeviceConnectorBase §3.15 link supervision, transport-agnostic) but no transport seam and no request/response CM base. Added, spec-first (Core §3.15.1a + TC3 §3.15):
- **`I_ByteChannel`** — THE porting seam (O4/O8): non-blocking Open/Close/Send/Poll/State/Tick, cyclic-poll semantics. TC3 binds via Tc2_TcpIp (TF6310); CODESYS SysSocket/NBS; Siemens TSEND_C — device CMs never name a socket API and port unmodified.
- **`FB_AsciiDeviceCM`** (CM base): configurable terminator framing, one-outstanding-request state machine, response timeout ⇒ fault, RX-overflow guard, bounded-backoff reconnect, LinkState published (Annex D facet — zero new HMI code). Reason band **10401–10406** (`PL_TcpDevReasons`, registered §8.8).
- **`FB_SimByteChannel`** — scripted channel: device CMs TcUnit-test end-to-end with no socket/hardware. `FB_TcpDev_Tests`: request→scripted reply→parse (terminator stripped, judgement set); SwallowNext→**10402 timeout** (cyclic test, runtime TON).
- **`FB_TcpChannelTc3`** skeleton naming FB_SocketConnect/Close/Send/Receive with TODO bodies — verify signatures/TF6310 license/TcpIpServer against InfoSys.
- **Profiles** `FB_Iv3VisionCM` / `FB_Matrix220CM` (`Fraktal_Modules`): publish 'Trigger' (§7.6.1), Execute path completes on parsed response, IV3 OK/NG judgement, Matrix decoded-code/NOREAD. **Protocol strings are Setup-visible parameters explicitly marked VERIFY-vs-vendor-manual — typical forms, not confirmed facts.**
132 PLC files pass the combined gate. Watch items: `TIME * INT` backoff doubling, `FIND/DELETE` string semantics, `'$R'` terminator escape — first-compile checks.

## 26. Device-category CMs — configure first, extend second (2026-07-12)

User correctly flagged a philosophy inconsistency in §25: the CM layer is function-first (`FB_ConfigurableCylinderCM`, not `FB_FestoCylinderCM`), yet the TCP layer jumped to vendor-model CMs. Restructured to match the standard's own philosophy:
- **`FB_TcpVisionCM`** and **`FB_TcpCodeReaderCM`** (new `DeviceCMs/` in the Core library, non-abstract): CATEGORY CMs directly usable for most devices via configuration alone — protocol strings are §3.8-able parameters (TriggerCmd, Ok/NgPrefix + ResultSep payload extraction; NoReadText + optional MatchCode verification). Both publish Trigger (§7.6.1), complete Execute on the parsed response, fault DEV_PROTOCOL on garbage.
- **Model FBs became thin presets**: FB_Iv3VisionCM / FB_Matrix220CM now EXTEND the category CMs and contain only preconfigured strings in Setup — demonstrating the extension seam ("override _M_OnResponse only for genuinely special formats"). Chain: preset → category → FB_AsciiDeviceCM → FB_ControlModuleBase.
- **Tests retargeted to the category level**: the vision CM is CONFIGURED (not subclassed) for an IV3-style dialect in the test itself — proving the configure-first claim; reader test covers decoded-code + NOREAD + match verification; timeout test unchanged.
- Spec §3.15.1a amended with the category layer and its honest boundary: covers ASCII request/response; binary/unsolicited-streaming protocols need a different base (deferred until demanded).
134 PLC files pass. Watch item added: MID(str, len, pos) argument order in the payload extraction.

## 27. Cross-runtime latent-defect audit (2026-07-12)

Confirmed defects fixed at their shared seams: the Unit pending diagnostic now overlays `Status` only after the common mirror refresh; OEE and shelf expiry use the monotonic `TIME()` clock rather than assigning wall-clock `DT`; alarm-slot reuse clears shelving state and zero-duration shelves are refused; manual commands validate the published catalog and enter the inherited PLCopen lifecycle; typed cylinder/clamp dispatch rejects unsupported command values with registered reason 2008; failed `SetModel` restores the prior published identity; Step/Hold writes are PLC-gated; terminal Unit runs can be released by `Stop`; common-base `OnInit` and edge-triggered `OnAbortInError` now cover every module tier, and Unit initialization no longer erases an injected access provider. The HMI access-policy mirror now covers all ten gated actions and fails closed on a stale short array, configuration writes use the repository instead of a placeholder snackbar, multi-root simulation keeps independent sessions, and duplicated detail controls no longer bypass the mode bar's switch policy. Regression coverage was added for the status overlay, automatic Unit fault capture, manual actuation, shelf reuse/zero duration, and HMI policy cardinality.

## 28. HMI connection bootstrap and execution roadmap (2026-07-12)

Added `Specification/Reports/IMPLEMENTATION_ROADMAP.md`, converting the objective/coherence review into ordered phases with explicit exit gates: executable root-Unit forest; inherited composite behavior; physical four-structure contract and transactional recipes; authoritative manual release; trustworthy diagnostics/KPIs; production HMI transport; generated interoperability projections; security and a second binding.

The HMI now starts behind `ConnectionBootstrap`. First use or an endpoint never proven `LIVE` opens a wizard; previously proven settings reconnect behind a full-screen interaction lock. `STALE`/`DOWN` removes the shell immediately, no writes are queued, and connection editing appears only after 30 seconds without `LIVE`. `everConnected` is persisted only after a repository reports `LIVE`. SDK-only persistence keeps the zero-package policy (native JSON file / Web local storage). Widget tests prove first-use, 30-second timeout, and live-link-loss behavior. The production OPC UA/gateway repository remains deployment work and therefore fails closed rather than presenting an empty interactive HMI.

## 29. Reusable-module library identity (2026-07-12)

Renamed the former example-oriented project to `Fraktal_Modules`. The project contains reusable shipping module types, simulation models, and configured device presets; calling it “Examples” understated its supported-library role and encouraged copy/paste use. The physical directory and `.plcproj`, TwinCAT project name/title/default namespace/placeholder, dependent test-library reference, documentation, and `PL_ModuleReasons` symbol now share one identity. Object and project GUIDs were deliberately preserved so the rename does not manufacture new TwinCAT objects.

## 30. Aggregate test-gate identity (2026-07-12)

Renamed the aggregate PLC test project to `Fraktal_Tests`. Its single TcUnit runner covers both `Fraktal_Core` framework behavior and `Fraktal_Modules` reusable types, so a Core-only name misrepresented the gate. The directory, `.plcproj`, TwinCAT name/title/default namespace, normative binding text, and working documentation now agree. It is an executable test application and therefore deliberately has no library placeholder metadata. Project and object GUIDs remain unchanged. If independent release trains later justify separate gates, split this aggregate into per-library Core and Modules test applications; until then, one aggregate name matches the existing one-gate architecture.

## 31. Contract vocabulary and ownership cleanup (2026-07-12)

Resolved the semantic conflicts found by the whole-standard review. A root Unit tree is one **station**; a PLC/cell scope may host a forest of stations. `FB_ModuleBase` now owns the common PLCopen lifecycle, `FB_CompositeModuleBase` owns recursive child behavior, and the CM/EM/Unit bases are tier wrappers—so Unit no longer inherits an Equipment-Module identity. CM and EM interfaces share `ExecuteCommand`/`AbortCommand`; the duplicate `ST_CmStatus` was removed.

Recipe lookup now uses `(ModelCode, RecipeKey)`, and Unit changeover prepares and validates the complete subtree before commit. The shipping Cylinder and Clamp modules publish physical `ParCfg`/`ParCmd`/`OutCmd`/`OutImm` structures. `FB_BasicCylinder` was renamed `FB_ConfigurableCylinderCM` to express capability and tier. Alarm priority now has one axis, `E_Severity`; the redundant event-kind axis was removed from PLC and HMI. `E_Mode` remains an append-only Core/HMI ordinal contract until a generated identifier mapping replaces ordinals.

The TcUnit runner was also corrected to instantiate every compiled suite; previously nine compiled suites were silently absent from execution. Source/XML/project-list and Flutter gates are rerun after this migration. TwinCAT compilation remains required before declaring the draft binding release-ready.

## 32. First pinned TwinCAT compiler feedback (2026-07-12)

The first build log from TwinCAT 3.1.4024 reduced 514 reported errors to a few parser root causes. Fixed across all projects: TwinCAT does not accept `VAR PROTECTED`; `VAR_TEMP` is not allowed in methods; keywords are case-insensitive and cannot be identifiers (`Action`, `Log`, `Min`, `Max`, `S`, `R`, `DT`); and an apostrophe inside a STRING uses `$'`, not doubled SQL-style quotes. Public timing fields are now `Minimum`/`Maximum`, access arguments use `Gate`, audit locals use `AuditSlot`, and elapsed-time locals use `CurrentTime`/`DeltaMs`. A reserved-keyword scan is now part of the structural gate.

The same log exposed packaging conflicts: the reusable `Fraktal_Modules` library contained `MAIN` and `PlcTask`, and `Fraktal_Tests` contained `PlcTask` while still carrying library placeholder metadata. TwinCAT correctly refused those runtime objects as library content. Demo application objects now live in `Fraktal_Demo`, and the placeholder was removed from the executable test project. The demo hosts two real `FB_ClampStationUnit` roots rather than presenting Equipment Modules as root Units. `Fraktal_Core` and `Fraktal_Modules` are libraries; `Fraktal_Demo` and `Fraktal_Tests` are applications.

## 33. Second pinned TwinCAT compiler feedback (2026-07-12)

The next 4024.12 compile removed the parser cascade and exposed binding-level assumptions. Beckhoff added optional method inputs only in 3.1.4026, so all default-valued method inputs were removed and every 4024 call now supplies every argument. TwinCAT also enforces IEC encapsulation: another POU can access only a function block's `VAR_INPUT`/`VAR_OUTPUT`, not its local `VAR`. The four-structure contract and common published data are now mapped accordingly; private lifecycle state remains local. Test-only mutation of Unit OEE internals was replaced by a probe method, and access-policy setup uses a bounded configuration method.

`I_Module` now extends `__System.IQueryInterface`, satisfying `__QUERYINTERFACE` for Unit capability cascade. `Fraktal_Demo` directly references `Tc3_Module`, resolving the generated task FB's `IecTaskModule`, `S_OK`, and `fb_init` dependencies. The test application remains non-library in the canonical project; any repeated “Object not added to library” message identifies a stale copied `.plcproj`.

## 34. Third pinned TwinCAT compiler feedback (2026-07-12)

The third 4024.12 compile reduced the binding to eleven test-only access errors. A child function block exposed through a parent's `VAR_OUTPUT` is readable, and its public methods are callable, but TwinCAT does not permit a caller to assign that nested child's `VAR_INPUT` through the parent output. Access tests now use `FB_AccessManager.RequestLogin`/`RequestLogout`; the EM and manual-command probes own their fault/abort injection methods. These seams preserve encapsulation and leave the OPC UA request-symbol contract unchanged. Login/logout request bits are now consumed directly and self-cleared; the former `R_TRIG` implementation cleared the bit only after sampling it, so the trigger never observed a low scan and could ignore a consecutive request.

The compile log still referenced a separate copied solution under `FraktalAutomation\FraktalAutomation`. The canonical `Fraktal_Tests.plcproj` has no library placeholder metadata; a repeated “Object not added to library” message for `PlcTask.TcTTO` therefore comes from the stale copied project and requires replacing or refreshing that project in the XAE solution.

## 35. Safety and control-power foundation (2026-07-13)

Added the optional Core §9.8 profile and `SAFETY_AND_CONTROL_POWER_PROFILE.md`. Every module now inherits hidden-by-default `Safety : ST_SafetyStatus` and `ControlPower : ST_ControlPowerStatus` facets. The records cover device kind/state, demand, reset, muting, keyed bridge, affected power groups, group request/feedback, safety permit, fieldbus health/reaction, and deliberate rearm. `POWER_CONTROL=10` was appended to the access-policy ordinal contract; existing ordinals are unchanged.

`FB_PowerGroupCM` is the first basic reusable implementation. It owns an ordinary functional-enable request, never a safety output; it withdraws that request when its safety permit drops or a configured fieldbus-loss reaction requires power removal, latches rearm, and never self-energizes when health returns. Its reserved reason band is 10500–10599. The HMI renders both facets generically and the simulation demonstrates a door, light curtain, safety valve, and two valve-island zones. Certified door locking, muting/override, bridge, FSoE safe output mapping, and risk validation remain in TwinSAFE by design.

The ownership model was corrected before coordinator implementation: safety/control power is an optional cell-scope **control domain**, not inherently Unit-owned. `ST_ControlDomainStatus` carries a stable ID, readiness, safety/power aggregates, and member root paths. `FB_UnitBase.ControlDomain` accepts zero or one domain; several Units may consume the same record. That application-fed input is explicitly excluded from OPC UA. `Start` gates only an assigned domain's `ReadyForStart`; `Present=FALSE` deliberately adds no gate. The Unit republishes read-only `Domain`, `Status.ControlDomainId`, and facet mirrors for discovery. The domain coordinator itself remains deployment/application infrastructure rather than a fourth module tier.

The HMI connection settings schema is now v2. After the endpoint reaches LIVE, the wizard requires a root-Unit assignment. `ScopedPlcRepository` filters discovery and rejects reads/writes outside the saved assignment; legacy v1 settings migrate to an incomplete selection and therefore reopen step 2. Missing paths fail closed. ADMIN can reopen the assignment editor after login.

## 36. Catalog-owned HMI language and module content (2026-07-13)

Operator-facing PLC strings were converted to stable `std.*`/`project.*` localization keys, including command catalogs, diagnostics, interlocks, release reports, steps, audits, hardware, and I/O descriptions. Structured identity/protocol data remains untranslated. `ST_CommandInfo.Label`, timing/step/condition labels, and hardware description fields were widened or added for keys. The HMI now owns runtime standard/project catalogs, first-run language selection, locale switching, validated CSV import/export, module descriptions, PDF upload/viewing, and per-module section access policies. `file_picker`, `pdfrx`, and the Flutter-published `cupertino_icons` asset are the reviewed package exceptions. Local content storage is the shipped commissioning implementation; the `ContentStore` seam is the production shared-store boundary. See `Specification/LOCALIZATION_AND_MODULE_CONTENT.md`.

## 37. Pneumatic press worked application and two contract repairs (2026-07-13)

Added `Fraktal_Press_Demo`, an executable one-root virtual-commissioning application, and reusable
`FB_PneumaticPressUnit` / `FB_TwoHandStartCM` types in `Fraktal_Modules`. Three ordinary cylinder CMs
implement ram, door, and part slide; `FB_PowerGroupCM` supplies the functional pneumatic request. AUTO,
HOME, MANUAL, transactional ALUMINUM/PLASTIC/STEEL recipes, collision prevention, localization keys,
nameplate, alarm rationalization, control-domain facets, and TcUnit coverage use the existing contracts.
The two-hand CM consumes a certified result and only produces a release-before-rearm functional edge;
it explicitly does not calculate simultaneity or anti-tie-down. `E_SafetyDeviceKind.TWO_HAND_CONTROL`
was appended without disturbing existing ordinals.

Building the example exposed two shared seams. First, the HMI already offered Control On/Off but the
PLC had no published write endpoint. `FB_UnitBase` now owns edge-consumed `ReqControlOn/ReqControlOff`,
applies `POWER_CONTROL`, gives Off priority, and publishes one-scan coordinator requests. Power groups
no longer publish equivalent MANUAL commands. Second, cylinder collision rules were previously either
application-only or a generic forced interlock. `FB_CylinderCM.SetDirectionalPermits` now applies exact
extend/retract conditions to typed and manual execution. The manual release query now includes the
command value and delegates to `AppendDirectionalRelease`, so act-or-explain evaluates the same
directional permit as dispatch instead of reporting only the target.

The simulation also moved safe-output filtering to final output authority. Ordinary Unit logic runs
first; simulated certified logic then removes all requests on power loss and independently removes
ram-down without guard plus evaluated two-hand permission. This fixes a one-scan overwrite hazard in
the first draft and documents the required TwinSAFE/FSoE replacement. See
`Specification/Reports/PNEUMATIC_PRESS_EXAMPLE.md`.

## 38. CX2030 training-station physical I/O binding (2026-07-13)

Integrated the supplied `TrainningStation_IOs_V2.xlsx` map into the press application without leaking
terminal details into reusable modules. `GVL_PressIO` declares wildcard process-image symbols for the
EL1809/EL2809 channels; `MAIN` alone maps them into the cylinder, two-hand, power, part-presence, and
air-pressure HALs. The physical feeder retracts inside and extends outside, so that application mapping
deliberately inverts the generic slide position names. AUTO now requires part presence plus the valid
high-air/low-air combination before accepting the evaluated two-hand edge.

Simulation remains the default and explicitly clears every mapped output. Physical mode is fail-closed:
`GVL_PressSafety` input aliases default false until linked to evaluated safety results, and the ambiguous
`SwitchControlOn`/`EnableControlOn` pair remains off until its electrical behavior is confirmed. The
worksheet lists the E-stop and two-hand buttons only on ordinary EL1809 inputs and provides no safe
guard, safe pneumatic output/feedback, or evaluated two-hand result; these channels are therefore raw
diagnostic mirrors, not a safety implementation. It also calls reserved output channel 9 `EL2810`
while the other outputs are `EL2809`, and lists no physical Control On/Off input buttons. These items
are tracked in `Specification/Reports/CX2030_PRESS_IO_MAPPING.md` rather than guessed in code.

## 39. Electrical-tag diagnostic join (2026-07-13)

`ST_Diagnostic` now carries optional `IoTag` and `IoAddress` structured identity. The cylinder CM can
be configured with application sensor/output tags without importing terminal knowledge into reusable
device behavior; its position timeout and sensor-conflict first-outs attach the exact approved tag.
`FB_AlarmLog.RaiseDiag` preserves both fields through the active alarm and closed-event lifecycle;
the ordinary `Raise` API remains source-compatible and supplies empty channel context.
`ST_IoChannel` now separates exact `Name`, localized `DescriptionKey`, physical `Address`, unique
force/audit `Path`, and owning `ModulePath`, plus fault-highlight fields.

The press application publishes its supplied EL1809/EL2809 list as a bounded OPC UA fieldbus table.
The HMI renders tags verbatim, descriptions in the active language, cross-navigates to the module, and
highlights a channel whose tag matches a live first-out. The application publisher currently consumes
the aggregate standard-I/O health alias; it is a label/value adapter, not a replacement for the
deployment-deferred EtherCAT scanner/master diagnostic integration required by Core §10.5.1.

## 40. I/O responsibility distribution made normative (2026-07-13)

The first press fieldbus implementation proved the data contract but placed project metadata, live
process-image copying, topology validation, health propagation, and diagnostic correlation in one
application FB while `MAIN` also performed raw channel mapping. That shape contradicted the intended
“basic reusable mechanism + thin composition” architecture even though it was functionally correct.

Core §10.2.1 now defines mandatory ownership. `FB_IoTopologyPublisher` is reusable infrastructure for
bounded registration, validation, health and exact-tag diagnostic joins over `ST_FieldbusTopology`.
`FB_PressIoCatalog` is static project engineering data and injects `ST_CylinderIoIdentity` role records.
`FB_PressIoDriver` alone accesses `GVL_PressIO`, maps semantic HALs, writes physical outputs and refreshes
live topology values. `FB_PressSimulationDriver`, `FB_PressControlDomain`, and
`FB_PressOutputAuthority` isolate simulation plant behavior, domain aggregation, and final functional
withdrawal respectively. `MAIN` selects paths and orders calls without individual channel assignments
or domain-device construction. The project-specific catalog remains intentionally explicit until
generated from the approved I/O workbook; reusable algorithms no longer live beside those rows.

## 41. Native OPC UA repository and acknowledged HMI mailbox (2026-07-13)

The original connection wizard exposed `opc.tcp` while its external repository
was a throwing placeholder. Windows now builds a native `fraktal_opcua` DLL from
pinned open62541 1.4.12 and Mbed TLS 3.6.6. Dart FFI calls run exclusively in a
worker isolate; a generic flat snapshot mapper discovers modules only through
`Status : ST_ModuleStatus`. Web compiles a client for the same snapshot/write
contract over the versioned Fraktal WebSocket gateway protocol.

The integration audit also exposed that several HMI operations existed only as
IEC methods, which OPC UA cannot call. `FB_UnitBase` now publishes
`ST_HmiRequest`/`ST_HmiResponse`: arguments first, changing Sequence last,
AckSequence last after processing. The base routes supported requests through
the existing gated methods and publishes property-only mode/running/stop state
as data. Type/project-specific configuration writes and fieldbus output force
remain fail-closed override hooks; identity-based alarm shelving is explicitly
refused until its slot-resolution adapter is supplied.

## 42. Explicit press mode sequences and discoverable recipes (2026-07-13)

Pinned TwinCAT feedback found an undefined `_airPressureOk` symbol in the press ram permit; the Unit
now consumes `AirPressureMonitor.OutImm.PressureOk` directly. The review also confirmed a visibility
problem: AUTO and HOME were step-number regions inside one large dispatcher, CHANGEOVER was not
supported, the project recipes were anonymous declarations in `MAIN`, and the native OPC UA mapper
did not project `CurrentStep` or `Decision`. The PLC contained behavior that the real HMI could not
show.

`FB_PneumaticPressUnit` now has a thin `_M_Dispatch` and separately reviewable
`_M_SequenceAuto`, `_M_SequenceHome`, and `_M_SequenceChangeover` methods. CHANGEOVER establishes the
load-safe position and waits for deliberate tooling/material confirmation. `FB_PressRecipeCatalog`
owns the ALUMINUM/PLASTIC/STEEL engineering records and feeds the generic local provider. Units may
publish a bounded available-model catalog; the HMI renders it as a selector, performs the
mode→transactional model→Start flow, and projects live step conditions and decision prompts over the
same generic OPC UA mapper. `_M_TakeDecision` now consumes and clears the answer, preventing a stale
answer from automatically satisfying a later prompt.

## 43. TF6100 filtered root publication fix (2026-07-14)

A live CX2030 trace separated transport failure from address-space failure: TCP port 4840 accepted
the connection, open62541 opened a SecureChannel and activated an anonymous session, TF6100 loaded
`Port_854.tmc` successfully (`loadSymbols ret=0`) and kept ADS health checks alive, but browsing
`Objects` returned only namespace-zero `Server`. The retained rotated importer logs begin midway
through the 18-second import, so they cannot prove whether the earlier direct root record was parsed.

The trace proves the immediate blocker is TF6100 authorization/publication rather than networking:
the anonymous identity is activated but cannot browse the configured PLC Data Access object. Both
executable examples now also mark every root Unit declaration in `MAIN`, making the intended forest
explicit in addition to the then-supported type-level inheritance. Part I, Part II, the transport guide,
and `AGENTS.md` record the rule. The HMI's empty-forest diagnostic names the instance marker, TMC
reload, and OPC UA namespace authorization as distinct checks. The endpoint hostname returned by
`FindServers` was not the cause—the redirected session reached `Activated` before the empty browse.

The audit also corrected an overstatement in `OPCUA_TRANSPORT.md`: username support exists in the
native ABI but is not yet surfaced by connection settings. The current wizard connects anonymously;
persisting a server password in its JSON or sending one over `SecurityPolicy=None` would be an unsafe
shortcut. Temporary anonymous namespace rights are therefore commissioning-only; certificate trust,
secure credential handling, and authenticated least-privilege writes remain the Phase 7 production
security exit gate.

Because the copied server trace was older than the next HMI attempt and the active TF6100 files live
only on the remote PLC, the native snapshot now also reads the standard OPC UA
`Server/NamespaceArray`. An empty-forest error reports those URIs beside `Objects` children: a PLC
namespace present there but absent from `Objects` proves identity permissions are filtering browse;
an absent PLC namespace proves the remote Data Access NodeManager/TMC was not loaded. This diagnostic
is read remotely and does not assume TF6100 is installed on the HMI PC.

The subsequent synchronized client/server capture made the authorization diagnosis conclusive. The
client read `urn:BeckhoffAutomation:Ua:PLC1` from `NamespaceArray`, while the matching TF6100 trace
accepted an `AnonymousIdentityToken` and printed `Roles assigned to session` with no following role
entries. The same session received only `Server` when it browsed `Objects`. The HMI now recognizes
this combination and reports an access-filtering error directly instead of also suggesting a missing
TMC or root publication marker. The remote TF6100 user/group mapping and recursive PLC1 browse/read
rights must be corrected; anonymous access remains commissioning-only.

## 44. Authorized large-tree browse and HMI mailbox starvation fix (2026-07-14)

After assigning the commissioning identity to TF6100's Users role, discovery
advanced to `LIVE` and the HMI rendered `PneumaticPress`. Mode controls still
appeared inert and the Dart debugger repeatedly reported that it was waiting for
the `fraktal-opcua` isolate. This separated a PLC mode/enum problem from a client
scheduling defect: the native snapshot recursively browsed and individually
read up to 20,000 nodes every 500 ms. The single worker isolate therefore spent
nearly all of its time in snapshot FFI; mailbox writes queued behind it, while a
concurrent repository refresh could return early and test stale acknowledgement
data. Depth-first discovery could also consume the cap inside an implementation
subtree before reaching shallow `HmiRequest` leaves.

The native bridge now discovers breadth-first in bounded multi-node Browse
services, caches path-to-NodeId discovery for the session, and reads cached
variables with bounded multi-node Read services. Snapshots report `truncated`.
The Dart repository shares an in-flight refresh instead of skipping it, so a
mailbox request observes fresh acknowledgement data. Request start, individual
write/commit failure, acknowledgement with PLC diagnostic, and timeout are
logged without transported secrets. The request-kind and mode ordinals already
matched the PLC DUTs; no wire-contract ordinal change was required.

The resulting bring-up lessons are consolidated in
`Specification/Guides/FIRST_PROJECT_AGENT_GUIDE.md`, referenced by `AGENTS.md`. Part I
now requires layer-specific client status and acknowledged command success;
Part II records the TF6100 host, authorization, namespace, root, and mailbox
acceptance ladder.

## 45. TF6100 reference aliases projected as duplicate stations (2026-07-14)

The first cached/batched live browse exposed three root projections named
`PneumaticPress`; Flutter's station dropdown correctly asserted because three
items carried the same Fraktal path. The PLC application declares only one root,
but several infrastructure FBs retain `UnitRef` references. TF6100 can expose
those reference/owner paths with the referenced Unit's `Status`, and the flat
mapper previously treated any parentless `Status : ST_ModuleStatus` Unit as a
deployed root.

The first correction compared a candidate's local browse segment with the whole
`Status.Name`. The next live run proved nested modules intentionally publish
qualified identities such as `PneumaticPress.PressRam`, so that comparison
removed every legitimate child while retaining the root. The final mapper
compares the local browse segment with the **final dotted identity segment**,
deduplicates every module by the full `Status.Name`, constructs parentage from
the dotted prefix, and chooses the shallowest OPC UA path for each identity.
`UnitRef`-shaped aliases are discarded; direct children remain. Discarded paths
are logged once per changed alias set. `AppState` also removes duplicate root
paths defensively so an invalid repository payload cannot crash a station
selector. Regression fixtures prove the direct root and qualified child survive
both alias forms. Part I §4.8 and the HMI/transport contracts now state the
local-browse versus qualified-identity distinction explicitly. No
station-specific UI rule was added.

## 46. Login-result feedback and release-query feedback loop (2026-07-14)

Live commissioning exposed two HMI contract errors. First, the Unit mailbox acknowledges LOGIN when
`FB_AccessManager.RequestLogin` queues the attempt; the access provider evaluates it later in the same
PLC scan. Treating `HmiResponse.Accepted` as authentication success therefore displayed a false
success for a bad PIN. The OPC UA repository now uses the post-attempt `Access.LoginFailed`,
`CurrentUser`, and `CurrentLevel` snapshot as the authoritative result. The login dialog remains open,
clears the PIN, and gives localized generic feedback on failure.

Second, `AppState` refreshed an open release panel on every forest snapshot. Each release mailbox query
causes a fresh snapshot, so one rejected Start created an unbounded RELEASE_START loop. The panel now
appears immediately in a checking state, performs one query, and uses a controlled non-overlapping
two-second refresh while open. Empty rejected reports render an explicit publication/contract message.
Regression tests cover mailbox-consumed versus authenticated login, inline failure feedback, immediate
release visibility, and absence of snapshot-driven request recursion. No PLC wire ordinal changed.

## 47. §6.1 reset provenance, post-dispatch stall views, first-connect backoff (2026-07-14)

Running the full TcUnit gate against the live build exposed five Core defects that the press
example depends on; all were fixed at the base so every module type inherits the corrections.

**Execute-drop reset (§6.1) ran after output mapping and consumed non-command faults.**
`FB_ModuleBase.Cyclic` reset a terminal state at the bottom of the scan, so the scan in which
`Execute` dropped still published stale `Done`/`Error`/`Aborted` (T1/T4 red), and any fault raised
OUTSIDE a command — the §3.8 migrate-or-fault at Setup, cyclic condition monitors — was silently
consumed one scan later because `Execute` was low (T5 red). The reset now runs at the TOP of the
scan and is gated on command provenance (`_cmdArmed`, armed at the accepted rising edge): a
command-produced terminal state resets before this scan's mapping; a non-command fault latches. A
fresh command edge may retry from a latched non-command ERROR — the edge clears the diagnostic and
re-runs validation, which re-faults immediately if the cause remains. HOME/AUTO therefore recover a
CM whose idle condition fault has cleared; a bad recipe stays visible until remedied.

**`Starved`/`Blocked` were derived in `OnCyclic`, one scan before dispatch updated the step.**
The §8.11.4(f)/§8.11.3 views are now derived in `FB_UnitBase._M_PublishStatus`, which the base
calls after `_M_Dispatch`, so the wait class reflects the step record set THIS scan.

**`FB_AsciiDeviceCM` delayed the FIRST connect by the retry backoff and rejected same-scan sends.**
The CLOSED branch armed the 500 ms backoff before the first `Open()`, so every request in the
first half-second faulted `DEV_NOT_CONNECTED` (10404) instead of reaching the device — the TcUnit
suites saw exactly that. Backoff now spaces RE-tries only; the first `Open()` is immediate, and
`SendRequest` checks the live channel state instead of the one-scan-old `LinkState` cache.

**`FB_ConfigurableCylinderCM_Tests` looped a TON-based sim inside one scan.** TwinCAT task time is
frozen within a scan, so 20 ms travel/30 ms settle could never elapse; the three time-based tests
now use the standard multi-scan TcUnit pattern (one iteration per cycle, assert + `TEST_FINISHED`
on the terminal state or a 100-scan budget). The sims stay time-based — they are shared with
virtual commissioning (§5.7); `Timeout_faults` (PT=0) was already scan-exact and is unchanged.

## 48. Press example feature completion: run styles, §3.16 traceability, rationalization, users (2026-07-14)

A spec-coverage review of the press example found four normative capabilities the Core already
promised but the example (and in one case the Core) did not exercise.

**Run styles (§3.4.2).** `FB_UnitBase` had the full pacing machinery (`StepRequest`, `SetHoldRun`,
`_M_StepGate`) but no shipped Unit ever declared support. `FB_PneumaticPressUnit` now advertises
SINGLE_STEP and HOLD_TO_RUN and passes every motion boundary in AUTO/HOME/CHANGEOVER through
`_M_StepGate(Steppable := TRUE)` — the step record is set first so the HMI shows where the sequence
is paused. Settle/dwell timers are process steps and are deliberately not gated. CONTINUOUS is the
default; existing tests are unaffected because the gate returns TRUE there.

**Traceability (§3.16).** The contract existed as types only (`I_PartCarrier`, `ST_PartContext`,
reasons 2020–2023) with no implementation, no Unit wiring, and no lifecycle events. Added: the four
`EVENT_PART_*` reason codes (2024–2027, MESSAGE ring entries via the instant come+gone pattern);
`FB_LocalPartCarrier` in `Connectivity/` (BY_POSITION serials from a configured prefix, bounded
produced-results ring — joins the local provider family); `FB_UnitBase` publishes
`Part : ST_PartContext` and gains `SetPartCarrier` plus the protected helpers `_M_PartReceived`,
`_M_PartStarted`, `_M_PartRecord`, `_M_PartProcessed`, `_M_PartAborted`. ERROR entry raises
PROCESSING_ABORTED automatically next to the §8.3 fault capture. The press AUTO chain raises all
four events and records the applied dwell; `MAIN` injects the carrier. With no carrier injected
every helper is a no-op, so traceability stays a selectable feature (§3.9). `FB_PartTrace_Tests`
proves the carrier scan-exactly. The HMI part facet (§3.16.4) is a follow-up — the data is now
published for the generic mapper.

**Rationalization (§8.9) and access (§7.7).** The press registers operator-action/consequence
metadata for its main reasons (interlock, air pressure, recipe, cylinder position timeouts) and a
commissioning user table (operator/tech/admin). `FB_LocalAccessProvider.Register` is now idempotent
by user name — the table is PERSISTENT, so per-boot registration previously duplicated entries.

Deliberately NOT added: CAPABILITY/ADJUSTMENT modes (§3.17 — no press process behind them yet),
signal tower mapping (§8.13 — the training station has no tower and the HMI has no facet), and a
scripted vision/reader child (§3.15.1a — worthwhile, but it needs its own review of the AUTO
chain's quality path: NOK counting, REWORK routing, and the §3.16 verdict source).

## 49. Nexeed reference comparison: sub-sequence extraction and §4.2 folders (2026-07-16)

A Bosch Nexeed reference export (`NexeedReferenceOnly/REF1_Plc.xml`, ~140k lines) was reviewed for
code grouping and distribution. Its architecture maps almost one-to-one onto Fraktal contracts
(the map is recorded in `AGENTS.md`), which validated two things Fraktal already prescribes and
exposed two places the reference implementation did not practice them.

**Adopted 1 — shared sub-sequences (Nexeed `SqS_*` ≈ new `_M_Seq<Name>` methods).** The press
triplicated the ram-up→door-open→slide-outside motion chain across HOME and CHANGEOVER. It is now
ONE reviewable `_M_SeqEstablishLoadPosition(BaseStepNo)` sub-sequence with a private `_seqStep`,
called from both mode chains; the `BaseStepNo` window keeps per-mode step identity for the §6.9 walk
and the §8.11.4 profiler, and the changeover's "repeat position" decision resets the sub-step. The
HOME/CHANGEOVER step labels merged into shared `project.step.pressSafePosition*` keys. Behavior,
scan counts (±1), and the press suite's assertions are unchanged.

**Adopted 2 — §4.2 folder tree in the press application.** The demo was flat; Nexeed's per-location
folders are exactly the spec's instance-tree layout. The project now ships `00_System/` (MAIN, raw
I/O + safety GVLs, hardware driver, domain coordinator, output authority, sim plant) and
`01_PneumaticPress/` (recipe catalog, approved I/O catalog, fieldbus publication GVL); the plcproj
includes were repointed. Library projects keep their artifact-type folders — §4.2 governs
applications, where the instance tree exists.

**Noted, not adopted:** Nexeed's `Unit`+`Extension` pairs and `*Addon` plugins are composition-over-
inheritance seams; Fraktal deliberately uses base-class inheritance + §3.14 hooks + `I_EventSink`
(§2.2 single-sourced lifecycle) — no change. Nexeed models TWO workpiece contexts per station
(`...Wp1/Wp2` part-event addons); Fraktal's Unit publishes one `Part : ST_PartContext`. Multi-
workpiece stations are recorded as an open Part I §3.16 consideration, not silently bolted on.

## 50. Native OPC UA online-change resilience (2026-07-16)

The native client did not survive a TwinCAT PLC online change. Two gaps, both in
`fraktal_opcua_bridge.cpp`:

The discovery cache was permanent — `discoveryComplete` was set once after the
first browse and never invalidated except on a full connect/disconnect. So an
online change that added/removed/renamed symbols or shifted NodeIds was never
re-read: new symbols stayed invisible, removed ones lingered, and writes could
land on stale NodeIds. Reads of gone NodeIds were silently dropped (filtered on
`status != GOOD`), hiding the structural change.

There was also no reconnect path. A PLC online change usually reloads the TF6100
namespace and tears the OPC UA session down, and open62541 only auto-reconnects
when its event loop is pumped — this client is driven by explicit service calls.
So a dropped session left the HMI in `STALE`/`DOWN` indefinitely.

Fix (fully native; the Dart repository already marks link `STALE`/`DOWN` on
snapshot failure and returns to `LIVE` when snapshots succeed again, so no Dart
change was needed): `connect` now caches the endpoint/credentials; a `reconnect`
helper re-establishes the session with them and always clears the NodeId map;
`ensureSession` checks the live `UA_Client_getState` (connect status + activated
session) before every snapshot and reconnects when it degraded — making session
loss transparent. Reads count NodeIds that no longer resolve
(`BadNodeIdUnknown`/`BadNodeIdInvalid`); a surge (>=20% of cached variables)
invalidates the cache so the next snapshot re-browses the fresh structure. Any
service-level read failure reconnects and returns no document rather than a
stale/empty tree. Writes during the reconnect window are rejected, not queued
(§14); reconnect attempts are self-throttled by the connect timeout and the
shared in-flight refresh. `OPCUA_TRANSPORT.md` documents the contract.

## 51. Mode-change default is immediate abort, not graceful (§3.14.4) (2026-07-16)

`Unit_mode_change_is_estop_by_default` was the last red gate (64/65). Root cause: `_M_InitModePolicy`
defaulted `E_ModeSwitchStyle` to GRACEFUL (loop default and AUTO), so a mode change requested while a
sequence ran set `_stopReq` and waited for the cycle to finish. A stalled cycle (the probe waiting on
SimA/SimB) never finishes, so the Unit stayed BUSY and the mode never committed — the opposite of the
test's premise and of spec §3.14.4: "By framework default, a mode change performs an immediate software
abort." GRACEFUL completion is the opt-in (a Unit overrides OnModeExit to stop-after-cycle, or station
config sets Style := GRACEFUL for a mode).

Fix: the framework default Style is now IMMEDIATE for every mode (the OnCyclic mode block then calls
OnAbort on a BUSY mode change, completing the abort→Execute-drop reset→commit sequence in three scans).
Shield defaults are unchanged (CONFIRM, with CHANGEOVER/CALIBRATION BLOCKED_WHILE_RUNNING and
HOME/MANUAL INTERRUPTIBLE). No test or Unit opted into GRACEFUL, so nothing else moved. This is purely
a framework-default alignment to the spec; a station that wants finish-before-switch still gets it via
ModePolicy station config (§3.8a) or an OnModeExit override.

## 52. §8.11 cycle-time capture completed + HMI cycle-time analysis charts (2026-07-16)

Audit verdict: §8.11.4(a)/(b)/(e)/(f) were fully implemented (command timing in the module base,
the step-fed profiler with time classes, fixed arrays, Starved/Blocked derivation); the HMI had a
waterfall and step Pareto. Missing: §8.11.1 throughput markers, §8.11.2 verdict-driven counts and
ReworkCount, §8.11.3 machine-state classification, §8.11.4(c) guard-vs-actual and command-timing
drill-through in the HMI, §8.11.4(d) degradation events, and any per-model ideal cycle in the press.

**Core.** `FB_CycleProfiler` now publishes `LastCycleTime`/`MinCycleTime` (§8.11.1) and a bounded
`History` ring of `ST_CycleSummary` (per-cycle work/wait-class totals — the data that EXPLAINS a
cycle-time increase), plus a WORK-time degradation watch: `BaselineWorkMs`/`DegradedBandPct` with a
one-shot `DegradedTrig` per excursion; `FB_UnitBase` turns the trigger into a Low maintenance event
(`CYCLE_TIME_DEGRADED`, §8.11.4(d)) via the new `_M_RaiseMaintenance`. `ST_StepTiming` carries the
step's declared `Expected` guard so the HMI can draw guard-vs-actual (§8.11.4(c)); `_M_SetStep`
forwards it. `FB_UnitBase` adds `ReworkCount`+`CountRework`, `NokReason`, and `MachineState`
(new `E_MachineState`, §8.11.3 classification each scan: DOWN > CHANGEOVER > BLOCKED/STARVED >
PRODUCING > STOPPED > IDLE). §8.11.2 counters now increment inside `_M_PartProcessed` from the part
verdict (single source; an NOK stores its first-out reason). The public Count* methods remain for
carrier-less applications.

**Press.** `ST_PneumaticPressParCfg` v2 adds `IdealCycleMs` (OEE Performance denominator, §8.5.1)
and `BaselineWorkMs`; `CommitRecipe` forwards both, so the references follow the model. The catalog
carries per-model design cycles (5.7–6.8 s). The AUTO finish step now counts through the part
verdict; direct `CountGood()` remains only as the no-carrier fallback.

**HMI (user-requested: extensive cycle-time cause analysis).** New `cycle_trend_view.dart`:
`CycleTrendView` — stacked per-cycle columns split by time class with the MinCycleTime dashed
reference, hover/tap tooltip, dimming, and a legend (a grown green share = the process slowed; a
grown wait share NAMES the external cause), and `CommandTimingView` — the §8.11.4(c) drill-through
table (Count/Last/Min/Avg/Max + bar with Max marker) rendered per child module. The waterfall now
draws the Expected guard tick and outlines overruns in the error color. Unit chips add machine
state, rework, and last/best cycle time. The mapper projects `Profiler/LastCycle|StepStats|History|
LastCycleTime|MinCycleTime`, module `Timing/Rows`, `MachineState`, `ReworkCount`. The analysis
chain reads: trend (why did it move) -> waterfall (which step) -> Pareto (which step, over time) ->
command timing (which module command). Time-class palette re-validated with the dataviz six-checks
(blocked purple -> #AD1457 magenta, external teal -> #0097A7); identity is never color-alone (direct
labels + tables). `flutter analyze`/`flutter test` green; sim repository extended so the demo shows
a work-drift plus one starved excursion.

`FB_Timing_Tests` extends to the new markers/ring and the published Expected guard.

## 53. Ownership/sequence/release refinement from the Nexeed comparison (2026-07-16)

The deeper review of `NexeedReferenceOnly/REF1_Plc.xml` separated reusable architecture ideas from
vendor-specific implementation form. Part I §4.2 now makes ownership primary and distinguishes an
application instance tree from a reusable type library. §6.7 defines three chain roles—Unit mode,
module command, and owner-private sub-sequence—with one owner/step writer, an acyclic call graph, a
promotion rule to EM, and a requirement that private-chain progress stay in the caller's step record.
§7.2.1/§7.8 preserve condition provenance through common + mode/function-specific layering and keep
future step waits out of the Start frontier. The non-normative decision record is
`Specification/Reports/NEXEED_REFERENCE_INSIGHTS.md`.

One Core defect became visible under that rule: `ReleaseReportStart()` appended a concrete Unit's
`_M_AppendInterlocks`, while `Start()` independently checked only framework state. A Unit could thus
tell the HMI it was blocked and still start. `Start()` now performs the audited access check and then
consumes the report's authoritative `Released` value. Core conformance row T10 and
`FB_Release_Tests.Start_gate_matches_release_report` lock that equivalence.
`ST_ReleaseReason` also now carries the qualified owning `SourcePath`; `FB_PermIntlk`, framework
reasons, and directional cylinder releases populate it, and the HMI shows the owner plus numeric
reason. Aggregated same-text child conditions are therefore no longer ambiguous.

The press demonstrates the result. Its operating-air condition is an owner-local `FB_PermIntlk`
mode-entry record, appended by `_M_AppendInterlocks`; low air is both reported and enforced. Part
presence/two-hand remain AUTO step-100 waits. AUTO's duplicated return-to-load-position steps were
replaced by the same `_M_SeqEstablishLoadPosition` already used by HOME/CHANGEOVER, preserving the
230–280 step window and traceability record. Application engineering data is further grouped into
`01_PneumaticPress/Recipes` and `01_PneumaticPress/Io`. Published PLC instance names and OPC UA paths
did not change.

Deliberately not adopted: Nexeed Unit+Extension duplication, per-step wrappers, opaque summed release
booleans, direct raw-global coupling, PLC-authored HMI visibility, and ordinary-PLC safety
bridge/muting authority. Those conflict with Fraktal O1/O3/O7 and remain owned by base hooks, condition
records, the generic HMI, and certified safety respectively.

## 54. Compile-driven profiler ownership and TF6100 pointer exclusion (2026-07-16)

The pinned 4024 compiler rejected `Profiler.BaselineWorkMs := ...` in
`FB_PneumaticPressUnit.CommitRecipe`: `BaselineWorkMs` is a published output of the child
`FB_CycleProfiler`, not an assignable input. This is the same nested-FB ownership rule recorded in
Part II §3.3. `FB_CycleProfiler.M_SetBaselineWork(WorkMs)` now owns the mutation and rearms the
degradation excursion latch; the press recipe commit calls that API. The press TcUnit suite gives
the fast/slow records distinct baselines and asserts that each transactional model commit updates
the published profiler reference.

TF6100 also reported `RecipeCatalog.Provider._ptr` as unsupported `UXINT`. Skipping the pointer leaf
did not break discovery, but publishing provider storage was unnecessary and noisy. The provider
instance and its `PVOID` array now explicitly opt out with `OPC.UA.DA := 0`; neither is HMI contract
data. `TwinCAT_SystemInfoVarList._AppInfo.TComSrvPtr` is Beckhoff-owned system metadata and remains a
benign skipped leaf if the server scans that namespace. Part II §3.10 and the commissioning guides
now distinguish an application-owned exclusion defect from that system diagnostic.

## 55. Pinned `0.1.0.1` build set after unresolved Modules cascade (2026-07-16)

A dependent-build report contained more than 500 errors in `Fraktal_Press_Demo` and
`Fraktal_Tests`, but no error row owned by `Fraktal_Core` or `Fraktal_Modules`. The first errors were
unknown `FB_PneumaticPressUnit`, `FB_CylinderCM`, `ST_CylinderHal`, and every other Modules-owned
type; all invalid members/calls and even "type X is not equal to type X" were downstream compiler
recovery noise. The applications were resolving a missing/stale Modules artifact through `*`.

All five projects now identify the source set as `0.1.0.1`. `Fraktal_Modules` pins
`Fraktal_Core, 0.1.0.1`; Demo, Press Demo, and Tests pin both Core and Modules `0.1.0.1`. This makes
the required install order explicit and prevents XAE from silently selecting an older local-library
revision. The recovery is: build/install Core, resolve/build/install Modules, reload application
placeholders, then build applications. No individual Press/Test POU change is justified until that
dependency gate is green.

This section records the then-current recovery. Section 58 supersedes the current pin for Modules
(`0.1.0.2`) and makes `FB_PressDemoUnit` application-owned rather than a Modules-owned type.

## 56. Runtime stack overflow: release reports changed to in-place fill (2026-07-16)

Activating `Fraktal_Tests` exposed a PLC task stack overflow. The first runtime fault named the Tests
application/`PlcTask`; TwinCAT's later PREOP→OP and ADS 1804 messages were fallout from the crashed
PLC server. The immediate regression was the T10 Start change: `Start()` held an
`ST_ReleaseReport`, called `ReleaseReportStart()` whose implementation held another report, and
received the roughly 12.5 KiB record by value. TwinCAT 4024 can materialize additional return and
assignment temporaries, exhausting a bounded task stack.

`ReleaseReportStart`, `ReleaseReportManual`, and `ReleaseReportAction` now fill caller-owned
`VAR_IN_OUT Report` storage and return only the `Released` Boolean. `Start()` builds directly into
the already-published `HmiResponse.Report`; the mailbox and TcUnit callers also use in-place fill.
This preserves the authoritative gate/report predicate and wire data while removing the large nested
stack copies. The TC3 binding and agent guide now prohibit large contract returns by value.

Separately, `Fraktal_Tests` is an executable validation application but not a deployable machine
application. It may run manually on an isolated test runtime or CI worker; Autostart Boot Project
shall remain disabled. If mistakenly booted, recover in Config mode and remove/disable the Tests boot
project before returning the actual machine application to Run.

## 57. Press mode chains converted from ST token ownership to native SFC+ST (2026-07-16)

The press already had explicit HOME, CHANGEOVER, and AUTO behavior, but all three mode tokens lived in
`CASE _step OF` ST chains. Core §5.5/§6.2/§6.8 permits that representation, yet names SFC as the
default/recommended representation for multi-step machine sequences. The reference application should
demonstrate the default, not only the permitted fallback.

`FB_PressDemoHomeSfc`, `FB_PressDemoChangeoverSfc`, and `FB_PressDemoAutoSfc` own native TwinCAT SFC tokens.
Their non-stored ST actions publish `ActiveStep`; `FB_PressDemoUnit._M_Sequence*` remains the ST
Fraktal action adapter that populates `_M_SetStep`/`_M_Await`, drives child PLCopen handshakes, records
traceability, and invokes inherited completion/fault handling. The Unit's `_step` now selects only the
base lifecycle reset/run phases, not individual production transitions. Each reset is asserted and the
chart is called once before `M_Run` clears `SFCReset`, avoiding a reset flag that is set and cleared
without ever being consumed by the SFC runtime.

The reused ram-up/door-open/slide-outside chain remains the single private ST
`_M_SeqEstablishLoadPosition` sub-sequence, invoked as one composite SFC step with a caller-supplied
step-number window. This preserves one implementation across HOME, CHANGEOVER, and AUTO while retaining
detailed HMI progress. `Examples/Fraktal_Press_Demo/01_PneumaticPress/Sequences/New-PressModeSfc.ps1`
deterministically regenerates the native TwinCAT
SFC XmlArchive files; static validation checks XML, archive IDs, step/action links, and project includes.
The next pinned-XAE build remains the authority for editor/compiler acceptance of the generated graphical
archives because this workstation does not have the TwinCAT XAE compiler installed.

## 58. Concrete Unit sequences and release policy moved to the application branch (2026-07-16)

The first SFC conversion incorrectly compiled the press Unit and its HOME/AUTO/CHANGEOVER charts into
`Fraktal_Modules`. That made station behavior look reusable and hid the normal project extension point.
The Nexeed reference and Core §4.2 both point to ownership-first application engineering instead.

`FB_PressDemoUnit`, its three native SFCs, their deterministic generator, and
`FB_PressDemoRelease` now live under `Examples/Fraktal_Press_Demo/01_PneumaticPress`. The Release component
contains the project cross-device collision rules, named mode-entry condition state, and Start/manual
report appenders. Reusable `FB_CylinderCM`, input, two-hand, pressure, and power-group mechanisms stay
in `Fraktal_Modules`; that library no longer compiles or exports the press Unit or its SFCs. The
aggregate test project links the deployed project sources rather than copying them.

Removing the application Unit from the reusable library is a breaking library-surface correction, so
`Fraktal_Modules` advances to `0.1.0.2`; application/test placeholders are pinned to that version.

## 59. Press physical XTI reconciled into declarative I/O links and HAL (2026-07-16)

The supplied `=000+S-A610-A1 (EtherCAT).xti` is preserved under the press application's
`00_System/Hardware` folder. It establishes the deployed order and names as EK1200-5000 coupler,
EL1809 inputs, EL2809 outputs, EL6001 RS232, and EL9011 end terminal. It also resolves the worksheet's
EL2810/EL2809 ambiguity: the installed output terminal is EL2809 and its channel 9 is Reserve.

Every one of the 23 active `GVL_PressIO` Boolean process-image symbols now carries a `TcLinkTo`
attribute with the exact XTI box, physical channel, and PDO-entry name. Wildcard `%I*`/`%Q*` storage
remains intentional; the declarative link, not a guessed byte offset, owns the physical association.
`FB_PressIoDriver` remains the sole process-image consumer and maps those raw values to the project HAL.
The fieldbus catalog now publishes all five EtherCAT boxes below the CX2030/master node and uses the
exact box/channel address for diagnostic joins. The EL6001 has no HAL consumer because no serial device
or protocol was supplied; inventing one would violate the project-HAL boundary.

The XTI contains System Manager hardware configuration, not PLC application configuration. A deployer
must import it under the XAE solution's I/O Devices tree, preserve the box names, build to resolve all
23 links, activate the configuration, and complete dry-I/O validation. The ordinary EL1809 E-stop and
two-hand signals remain diagnostic/function inputs only. The fail-closed `GVL_PressSafety` aliases still
require evaluated results from TwinSAFE or another validated safety system, and the two control-coil
outputs remain disabled until their electrical sequencing is independently confirmed. The application
version advances to `0.1.0.3` for this physical-deployment mapping.

## 60. Press SFC actions now own their actual step logic (2026-07-16)

Section 57's first SFC conversion made the chart the sole token owner but left every generated action as
only `ActiveStep := N`; `FB_PressDemoUnit._M_Sequence*` still selected and executed the whole chain through
`CASE ActiveStep OF`. That avoided two competing tokens but failed the more important reviewability intent
of the SFC default: an engineer opening a step could not see what that step actually did. This section
supersedes that distribution.

`FB_PressDemoHomeSfc`, `FB_PressDemoChangeoverSfc`, `FB_PressDemoAutoSfc`, and the shared
`FB_PressDemoLoadPositionSfc` now contain the real application behavior in each named action: Fraktal
step/condition records, child PLCopen command/wait,
timers, decisions, traceability/result work, and a step-local transition Boolean. Exit actions clear each
step's transition latch, preventing a completed predecessor from skipping a newly active step. The Unit's
three `_M_Sequence*` methods now contain only the inherited lifecycle's reset/run handshake and no
`ActiveStep` selector or production-state `CASE`.

The project-private `I_PressDemoSequenceHost` bridges only protected Unit services that a separate SFC POU
cannot call directly. The SFCs receive owner-bound references to the child FBs and contract records during
`Setup`, so their actions visibly issue the child commands without illegally writing through the parent's
published child output. Those aliases and the SFC instances opt out of TF6100 publication. The coherent
ram-up/door-open/slide-outside operation is now the shared `FB_PressDemoLoadPositionSfc`, invoked as an
explicit composite parent step. Its own named actions contain the three child command/wait pairs, and its
caller-supplied step-number window projects detailed progress through the normal Fraktal step record. No
project mode or shared motion chain remains an ST state machine; the generator deterministically emits the
complete step-owned SFC set.

Core §5.5/§6.8, Part II TC3 §3.5, the Nexeed insight note, the press documentation, and `AGENTS.md` now
state that a token-only SFC plus external `CASE ActiveStep` is not a conforming claimed SFC implementation.
The press application advances to `0.1.0.4`; the aggregate Tests project advances to `0.1.0.3` because it
links the changed application sequence interface and charts.

## 61. Core FB_SequenceBase: the provided step-chain base + shared transition result (2026-07-17)

Section 60 made every press SFC action own its real step logic, but each generated chart still carried
its own host-interface copy, eleven per-step transition Booleans, per-step exit actions, and one
`I_PressDemoSequenceHost` that existed only because the framework had no sequence base. The Nexeed
reference does this once in `OpconSfcChain` (`_retVal := OK` + `ExecuteUnit(...)`), and Part I §6.8(a)
already PROMISED a provided shared step-chain base. This section delivers it.

Core additions: `E_StepResult` (NONE/ADVANCE/JUMP1..3 — the Fraktal spelling of Nexeed's OK/JUMPx,
integrated with §6.10 branch rules), `I_SequenceHost` (the once-per-framework bridge to protected Unit
services; `FB_UnitBase` implements it, replacing the press-private interface verbatim, plus
`M_SequenceStopPending`/`M_SequenceStopNow`), and `FB_SequenceBase`: `M_Attach`, `M_Step` (step record +
ActiveStep mirror), `M_Await`, `M_Gate`, `M_TryIssue` (one-shot gated issue latch — the §6.1 issue/await
pair collapses into ONE reviewable step; the child's typed Command/Execute stays visible in the action),
`M_Delay` (declared process waits), part/decision/completion/fault forwards, and the shared
`_retVal : E_StepResult` transition with `M_ClearTransition()` as the single shared exit action.
Charts now declare zero transition variables and one transition expression
(`_retVal = E_StepResult.ADVANCE`); a completed predecessor cannot skip a fresh step because the exit
action clears the shared result (same guarantee §60's per-step Booleans provided, at 1/N the state).

Stop honesty fix: AUTO's between-cycles wait previously rode out a full phantom cycle when Stop arrived
while waiting for a part. The wait step now polls `M_StopPending()` and calls `M_StopNow()`, which
abandons the OPEN profiler cycle via the new `FB_CycleProfiler.CycleAbandon()` (a wait-only fragment
is not a production cycle — it would poison MinCycleTime and the trend) and completes the chain.

The press generator now emits charts that EXTEND the base: issue+await merged into single drive steps
(LoadPosition 7→4 steps, AUTO 17→12), the private host interface deleted from the project and the
aggregate tests, and the Unit's Setup passes `THIS^` as `I_SequenceHost`. Generator self-checks verify
`EXTENDS FB_SequenceBase`, genuine step logic, and the `M_ClearTransition` exit per step. Step numbers
keep their §6.5 spacing; step-name keys unchanged except the merged drive steps
(`pressRamUp`/`pressDoorOpen`/`pressSlideInside`/`pressDoorClose`/`pressRamDown`).

Declined from Nexeed, deliberately: raw `BinIo` access inside sequence actions (violates §10.2.1 —
Fraktal actions still drive children only through the §6.1 handshake), `OpconSetTimeout/CheckTimeout`
step pairs (Fraktal timeouts live in the module's ParCfg per §6.1, and stall detection is the §6.9
walk), and per-step `IndexInfoLine` enum juggling (the step record + condition records already name the
wait for the HMI, localized).

Fraktal_Core advances to 0.1.0.2 (new public base + interface + enum; UnitBase implements
I_SequenceHost). The press application and aggregate tests re-pin accordingly.

## 62. Aggregate test manifest moved to the PLC common ancestor (2026-07-17)

The `0.1.0.4` aggregate project linked the deployed Press Demo Unit, release evaluator, and four SFCs
from a sibling directory with raw `Compile Include="..\Fraktal_Press_Demo\..."` paths. Although each
entry supplied a valid virtual `Link`, TwinCAT XAE's **PLC → Add Existing Item** importer inspected the
raw path first, attempted to create a project-tree folder named `..`, and stopped with
"'..' is not a valid folder name." The XML was valid MSBuild but not importable by TwinCAT.

`Fraktal_Tests.plcproj` lives at the nearest common ancestor of
`Tests/Fraktal_Tests/` and `Examples/Fraktal_Press_Demo/` (currently `TwinCAT/`). All compiled objects use downward repository-relative
paths; the Press sources remain single-source links and are not copied into the test directory. The
nested `Fraktal_Tests/Fraktal_Tests.plcproj` is removed so there is only one selectable manifest.
The aggregate test application advances to `0.1.0.5`; no PLC runtime contract changed.

During the same import audit, `FB_SequenceBase.M_TryIssue` was found with a default-valued method input.
That optional-input syntax is a TwinCAT 3.1.4026+ feature and violates the pinned 4024 binding rule.
The default was removed; every generated press action already supplies `Steppable := TRUE` explicitly,
so behavior and the effective call contract are unchanged.

## 63. Generated SFC charts: arity + optional-input fixes; IecSfc is NOT a dependency (2026-07-17)

The first pinned-XAE compile of the externally generated press charts produced 254 primary
`Unknown type: 'SFCStepType'` messages followed by hundreds of `.x`/`._x`/`.t`/`._t`, assignment, and
transition-BOOL errors. An interim change (from an external agent) added an
`IecSfc, 3.4.2.0 (System)` placeholder to the Press Demo and aggregate Tests manifests on the theory
that the SFC system library was missing. **That diagnosis was wrong and the reference was removed.**
Native TwinCAT SFC support is provided by the compiler for any POU whose implementation is an `<SFC>`
body; it needs no `.plcproj` library reference. The `IecSfc` string that appears in a generated chart
is the SFC `ObjectProperties` **title block** every chart carries — object structure, not a project
dependency. An `SFCStepType` cascade on a generated chart means that POU's SFC
`ObjectProperties`/`XmlArchive` block is malformed (regenerate it); it is not a missing library. The SFC
layer is Fraktal Core's own `FB_SequenceBase` plus native chart bodies — there is no external SFC base.

Two errors in that build were real and their fixes are kept:
- `FB_PressDemoLoadPositionSfc.M_Reset` requires `BaseStepNo`, while the shared generated restart branch
  called it with no inputs. The generator now preserves and passes `_baseStepNo` on that branch; the
  other three charts keep their zero-input reset.
- `FB_SequenceBase.M_TryIssue` had a default-valued method input (`Steppable : BOOL := TRUE`). Optional
  method inputs are a TwinCAT 3.1.4026+ feature and violate the pinned 4024 binding rule. The default was
  removed; every generated press action already passes `Steppable := TRUE` explicitly, so the call
  contract is unchanged.

The same build reported duplicate GUID warnings for Core interface methods. Those arise when a solution
loads the Core source project while an application in that solution also consumes the installed Core
library. Source object GUIDs shall not be randomized to hide the duplicate. Build/install libraries in
a library solution, then unload/remove those source projects (or use a separate application solution)
before compiling consumers.

## 64. Press sequences converted from unparseable native-SFC XML to the ST skeleton (2026-07-18)

Sections 57-63 rebuilt the press mode sequences as "native TwinCAT SFC" via a PowerShell generator that
hand-emitted the SFC `XmlArchive`. That was the wrong call: TwinCAT's SFC serialization is a proprietary
format whose step/transition WIRING (connection graph + layout) the compiler needs to synthesize the
implicit `SFCStepType` and its `.x`/`._x`/`.t` members. The generator emitted step and transition
ELEMENTS but zero connection elements, so a pinned-XAE build produced hundreds of
`Unknown type: 'SFCStepType'` + `'Nxxx._t' is no valid assignment target` errors. This is not fixable by
editing the blob (the format is not documented or reliably hand-authorable), and it was never an `IecSfc`
library problem (see §63 — that reference was a wrong diagnosis and was removed).

Resolution, per Core §6.8 (an ST `CASE StepNo OF` skeleton is a first-class equivalent to native SFC with
identical diagnostics): the four sequences are now plain ST on the SAME `FB_SequenceBase`. Everything the
base contributes is retained — `M_Step`, `M_Await`, `M_Gate`, one-shot `M_TryIssue`, `M_Delay`, the
part/decision/completion forwards, `I_SequenceHost` (still implemented once in `FB_UnitBase`), the shared
`_retVal : E_StepResult`, `CycleAbandon`, and the between-cycles `M_StopNow`. Two base additions make the
pure-ST body work: the `_step` token moved into the base, and `M_Advance(OnAdvance, OnJump1..3)` commits
`_retVal` at the end of each `CASE` branch — advancing to the mapped step and clearing the step-scoped
latches (the guarantee the SFC exit action gave). The generator, the four `*Sfc.TcPOU` files, and the
`SFCReset` two-scan reset handshake are gone; the files are `FB_PressDemoAuto/Home/Changeover/LoadPosition`
and the Unit adapters do a plain reset-then-run. HOME/CHANGEOVER Setup signatures narrowed to the children
they actually use. `M_TryIssue`'s `Steppable` input carries no default (4024 rule). Both manifests and all
four POUs parse; every `M_*` call resolves against the base.

Native graphical SFC remains a permitted §6.8 option, but only when drawn in the XAE SFC editor — a
machine-generated chart is prohibited. Part I §6.8, Part II TC3 §3.5, AGENTS.md, and the press README now
say the shipped reference is the ST skeleton on `FB_SequenceBase`, not a generated chart.

## 65. Headless Windows/Linux Web gateway delivered (2026-07-21)

The browser client and `fraktal.opcua.gateway.v1` contract existed, but the
gateway process itself was deployment-deferred. A standalone Dart AOT service
now owns one isolate-backed native OPC UA session and serves the exact snapshot
and typed-write protocol over WebSocket. It validates protocol/id/type/value
shape and request size, enforces browser origin policy, and restricts writes to
configured root Unit `HmiRequest` subtrees (read-only by default, with an
explicit all-root commissioning override). It globally serializes writes and
never retries them. Socket tests use an injected fake OPC
UA session and prove snapshot parity, serialization, scope refusal, version
refusal, and origin enforcement.

The OPC UA client moved into a local headless Dart package shared by the Flutter
HMI and gateway. This keeps Flutter/PDF plugin build hooks out of the service
AOT artifact. The native bridge is now a portable CMake subproject: Windows
produces `fraktal_opcua.dll`; Linux produces `libfraktal_opcua.so`, both from
the same pinned open62541/Mbed TLS sources. One cross-platform build tool emits
the matching executable, native library, launch helper, and Linux systemd
template.

The service deliberately binds only to loopback. Same-host Chrome is the local
commissioning profile. Remote Web HMI traffic shall pass through an
authenticated TLS reverse proxy on the gateway host; exact Origin checking is
retained as a second boundary and is not treated as authentication. This avoids
persisting a parallel gateway secret in browser settings. The OPC UA
commissioning endpoint observed here still selects anonymous
`SecurityPolicy=None`; production certificate trust and authenticated encrypted
TF6100 remain the existing Phase 7 exit gate.

## 66. Explicit OPC UA security profiles and native gateway transport (2026-07-21)

Section 65 delivered the transport but left its production OPC UA identity as
an exit gate. The shared C ABI now accepts an explicit security profile,
security-policy URI, certificate/private-key pair, client ApplicationURI,
optional encrypted-key password, server/CA trust list, and optional CRLs.
Secure profiles configure open62541 for
`SignAndEncrypt`; session recovery reuses the same configuration and never
downgrades. Production additionally requires a dedicated TF6100 username and
password supplied through the service environment. Private-key input bytes and
cached passwords are cleared when their lifetime ends.

The gateway defines four auditable profiles: `production` (the fail-closed
default), `secure-anonymous`, time-limited `commissioning-anonymous`, and
explicit permanent `isolated-anonymous`. The last profile exists for a single
physically isolated/unrouted old-school PLC/HMI cell; it is not considered
equivalent to production security. Both None/Anonymous profiles print a loud
startup warning, and the commissioning form auto-stops after a bounded TTL.
There is no automatic fallback between profiles.

The HMI's native platform adapter now implements the same `ws`/`wss` gateway
protocol as Web, using the platform TLS trust store. Thus a Windows/Linux/Android
HMI can use the secured gateway path without packaging the OPC UA private key or
PLC credential into the operator application. A device may authenticate to the
WSS reverse proxy with an environment-provisioned mTLS identity or bearer token;
these are accepted only over WSS and are not stored in HMI settings. Direct Windows `opc.tcp` remains
as a logged Anonymous/None commissioning/troubleshooting/isolated exception.
The Windows wrapper and hardened Linux systemd template default to production
and accept provisioned security material; remote WSS authentication remains the
same-host reverse proxy's deployment responsibility.

## 67. TF6100 publication-root and bounded-topology repair (2026-07-21)

A live local TF6100 snapshot reached the native 20,000-node guardrail with
`truncated=true`: 6,876 scalar values were below `_unit` aliases and 75 below
`_hal` aliases. This was finite breadth-first expansion, not an IEC recursive
datatype or an infinite client loop. Definition-level `DA=1` markers made every
instance eligible for publication, while persistent implementation references
allowed TF6100 to project the same Unit/HAL graph through infrastructure paths.

Publication now starts only at explicit deployed root Unit instances and
standalone data variables. Core/Modules FB type markers were removed; every
persistent pointer, interface, and `REFERENCE TO` implementation field carries
an immediate `DA=0`. The Press topology marker moved from the GVL header to the
`Topology` variable itself, matching TF6100 attribute placement. Core is
`0.1.0.4`, Modules is `0.1.0.3`, and downstream applications are repinned. The
source audit `PLC/TwinCAT/Tests/tools/Test-OpcUaPublication.ps1` prevents reintroduction.

The fieldbus contract remains a bounded flat IEC table, but a naive OPC UA walk
would expand all 64 x 16 fixed slots. Native discovery now reads `NodeCount` and
each active `ChannelCount` before enqueueing array elements, so unused slots do
not consume the snapshot budget. The HMI repository and Web gateway share a
fail-closed completeness validator: a truncated snapshot is never mapped or
reported ready, and gateway `/readyz` remains degraded. Increasing the node cap
alone is explicitly not an acceptance fix.

## 68. Config manifest: activation-static data obscured from OPC UA, served via QUERY_CONFIG (2026-07-22)

A live browse of the deployed press demo measured ~33.7k published value nodes,
~two-thirds of them activation-static identity (fieldbus tags/wiring, command
catalogs, model lists, mode policy, nameplate, alarm rationalization) re-read by
every client refresh and each costing the server an ADS handle
(`GetHandlesByNameViaSumReq ... 0x710` floods during handle-pool growth). Core
now excludes those members from the cyclic tree with `OPC.UA.DA := '0'` and
serves them on demand through the existing request mailbox (Core §3.10.2):

- `E_HmiRequestKind.QUERY_CONFIG := 23` (append-only ordinal contract);
  `ST_HmiResponse.ConfigPage : ST_ConfigPage` — a bounded window of
  `{Scope, Item, ValueText}` entries (`PL_Fraktal.MAX_CONFIG_PAGE := 16`).
- `I_ConfigSource.M_AppendConfig(Pager)` — implemented once in `FB_ModuleBase`
  (catalog), recursed over children by `FB_CompositeModuleBase` via
  `__QUERYINTERFACE`, extended by `FB_UnitBase` (models, mode policy). Projects
  append project-owned data: `FB_PressDemoUnit` exports
  `GVL_PressFieldbus.Topology` identity via the reusable
  `F_AppendTopologyConfig`. `FB_ConfigPager` counts the deterministic walk and
  stores only the requested window — no full manifest buffer exists in PLC
  memory; the walk order alone defines the paging.
- `FB_UnitBase.ConfigRev : UDINT` is seeded `DT_TO_UDINT(F_Now())` in `OnInit`
  (a plain counter would repeat after reboot and leave an HMI holding a stale
  manifest undetected) and incremented on accepted `WRITE_CONFIG`, `SetModel`,
  and `RegisterAvailableModel`.
- Obscured members: `FB_ModuleBase` Nameplate/Catalog/CatalogCount;
  `FB_UnitBase` AvailableModels(+Count)/ModePolicy/StallTime; `FB_AlarmLog`
  Meta/MetaCount; `ST_BusNode` and `ST_IoChannel` identity members (live
  State/LinkOk/values/Forced/Quality/FaultActive/Diagnostic stay published).
  Deliberately NOT obscured: `Status/*` (the HMI discovers modules by browsing
  `Status/Name`), `ParCfg`/`StationCfg` (config-editor field discovery and
  custom-tab bindings; small), `SupportedModes/RunStylesPublished` (mode bar).
- HMI: the OPC UA repository fetches all pages when the `ConfigRev` signature
  is new, synthesizes the exact flat browse-path keys (the server's
  `Member/Member[i]` array naming), and overlays them under the live snapshot
  before mapping — mapper/facets/views unchanged, works identically over the
  Web gateway. No published `ConfigRev` = pre-manifest library = fully
  published, never queried.

Verification pending a pinned XAE compile: attribute filtering on struct
members in TMC-Filtered mode, `DT_TO_UDINT`, and `TO_STRING` arity are the
watch items. After deploy, re-measure the live tree (expect roughly 33.7k →
low-20k value nodes for the press demo; the remaining bulk is the 64x16 empty
topology-slot LIVE members, addressed separately by right-sizing
`MAX_BUS_NODES`/`MAX_NODE_CHANNELS` per deployment).

## 69. Regressed defaulted method inputs on FB_SequenceBase broke the 4024 build (2026-07-23)

A 4024.x XAE compile of `Fraktal_Press_Demo` reported ~30 `Function 'M_Advance'
requires exactly '4' inputs` errors across all four ST sequence POUs
(`FB_PressDemoAuto/Changeover/Home/LoadPosition`). Cause: `FB_SequenceBase.
M_Advance(OnAdvance, OnJump1..3)` had been reintroduced with defaulted jump
inputs (`OnJump1..3 : INT := -1`), and every caller passed only `OnAdvance`.
Optional/defaulted method inputs are a TwinCAT 3.1.4026+ feature and violate the
pinned-4024 binding rule already established for `M_TryIssue` (§62) and
`M_ResetBase` (§64): **every method input must be explicit on 4024**. The same
audit found `M_ResetBase(FirstStep : INT := 0)` still carrying a default,
though all four callers already passed `FirstStep := 0`.

Fix (the §62/§64 pattern): the defaults were removed from both `M_Advance` and
`M_ResetBase`, and all 22 `M_Advance` call sites now pass every argument —
unused jumps are `-1` (`M_Advance(OnAdvance := N, OnJump1 := -1, OnJump2 := -1,
OnJump3 := -1)`); the one changeover retry keeps `OnJump1 := 810`. The effective
call contract and runtime behavior are unchanged (a caller that omitted a jump
was already relying on the `-1 = not used` default). The installed `Fraktal_Core`
library already exports `M_Advance` with four inputs, so the corrected sources
compile against it directly; the canonical `Fraktal_Core` source is updated to
match for the next library rebuild. A defaulted-method-input scan over every
`VAR_INPUT` block is now the enforcement gate — this is exactly the drift a
pinned-build CI compile (§1.5) would have caught at commit time.

## 70. Hardware Control-On adapter for a relay-safety machine (no TwinSAFE) (2026-07-23)

The physical press deployment turned out to have **no safety controller**: safety
is a hardwired Bosch/Nexeed N54 D2 "Control On" relay chain (Pilz-style). But
`FB_PressIoDriver.M_ReadInputs` read the six safety-status values straight from
the `GVL_PressSafety` `AT %I*` aliases, which were designed to be **linked to
evaluated TwinSAFE results**. With no TwinSAFE to write them, they stayed FALSE,
and the fail-closed cascade faulted *every* device on the HMI the moment
`UseSimulation := FALSE` (StandardIoHealthy FALSE → bad input quality; the safety
permits FALSE → all interlocks drop). Simulation had hidden this because
`FB_PressSimulationDriver` *derived* the six signals from ordinary inputs; the
real driver did not.

Fix: `FB_PressControlOnCircuit` (new, in `00_System`) reconstructs the six
read-only status mirrors from the **raw relay/sensor process image** —
`_000K910A` E-stop mirror, `_101B201A` door-closed, `_101S101/102` two-hand,
and crucially `_000K911_Y32` (the relay-chain **Control On feedback**) as the
`SafePneumaticPermit`. Per N54 D2, the Main/Safety-Valve and Safety-Door add-ons
already reset `EnableControlOn` on air/guard errors, so K911_Y32 subsumes air +
guard monitoring; the adapter only ANDs in the E-stop mirror + bus-valid for
defense in depth. `FB_PressIoDriver` owns the adapter (it remains the sole
`GVL_PressIO` consumer) and gained a `BusOk` input; `MAIN` supplies it from a new
`RealBusOk` flag (link to the EtherCAT master DevState/WcState; **default FALSE**
= fail-closed until linked, forced TRUE only on a validated isolated bench).

This is explicitly **not** a safety function: the relay chain remains the safety
authority, matching §9's "read-only aliases to results produced outside the
standard PLC" — here the external source is the relay circuit, not TwinSAFE. The
functional `EnableControlOn`/`SwitchControlOn` outputs are unchanged and still
gated by `ControlCircuitMappingConfirmed`. `GVL_PressSafety` is retained (unused)
as the documented TwinSAFE alternative for a machine that does have a safety
controller. Synced to both the canonical and `x32` build trees; 4024-clean (no
defaulted method inputs).

## 71. Fieldbus node state reads the real EtherCAT master; bus detection moved into the library (2026-07-24)

Two problems, per user report + objectives: (a) the HMI marked every fieldbus
node FAULT while XAE showed them OPERATIONAL, because node state was driven by
`FB_IoTopologyPublisher.M_SetAllHealth(StandardIoHealthy)` — an all-or-nothing
verdict tied to Control-On (via `RealBusOk`/the §70 adapter); (b) `RealBusOk` and
bus-validity were declared/wired in the *project*, violating the objective that
the **library detect the most it can from hardware with the least project wiring**.

New library FB **`FB_EcBusHealth`** (`Framework/Fraktal_Core/Connectivity`) reads the REAL,
live EtherCAT slave states directly from the master via `Tc2_EtherCAT.
FB_EcGetAllSlaveStates` (+ `FB_EcGetMasterState`), maps each device-state nibble
(`EC_DEVICE_STATE_INIT/PREOP/SAFEOP/OP/ERROR`) to the neutral `E_NodeState`, and
publishes it per node through the new `FB_IoTopologyPublisher.M_SetNodeState`
(node `State`/`LinkOk` + channel `Quality`). It also exposes `M_BusOk` (all mapped
slaves OP) — the **library-detected** replacement for the project's `RealBusOk`.
A non-blocking `CASE`/timer refresh keeps the async ADS reads off the task; a
master read error marks the segment OFFLINE (fail-visible, not silently OP).

Project wiring now minimal: `FB_PressIoDriver` owns one `FB_EcBusHealth`, calls
`Setup(MasterNetId := '', FirstSlaveNode := 2, SlaveCount := 5, MasterNodeIndex
:= 1)` (the ONLY project input — how its 6 catalog nodes line up with the
master's slave scan order) and `M_Refresh()` each scan; `MAIN.RealBusOk` and the
`BusOk`/`StandardIoHealthy` args to the fieldbus refresh are **removed** — the
Control-On adapter's `busOk` now comes from `FB_EcBusHealth.M_BusOk()`. Node state
is therefore **decoupled from Control-On**: fieldbus reflects the real bus.

`M_SetAllHealth` is retained as a documented legacy/fallback (transports/projects
with no fieldbus master). `Tc2_EtherCAT` added as a `PlaceholderReference` to
`Fraktal_Core.plcproj`; `FB_EcBusHealth.TcPOU` added to the Connectivity compile
list. The pre-existing `FB_EcFieldbusScanner` (an *unimplemented* `I_FieldbusScanner`
skeleton, not used by the press demo) remains the future full-auto-discovery path;
`FB_EcBusHealth` is the focused, working state-refresh now.

**Build/verify (cannot compile in this environment — pin-and-verify):**
- The split `FraktalPressDemo.sln`/`.tsproj` now builds the **canonical**
  `Fraktal_Press_Demo.plcproj` directly (the old `x32` duplicate tree is gone —
  no more two-tree sync). The press demo consumes `Fraktal_Core` as an **installed
  library** (`PlaceholderReference Fraktal_Core, *`), so `FB_EcBusHealth` +
  `M_SetNodeState` must be picked up by **rebuilding and reinstalling the
  Fraktal_Core library** before the press demo will resolve them.
- Verify against the pinned `Tc2_EtherCAT`: `FB_EcGetAllSlaveStates` I/O names
  (`sNetId`/`nSlave`/`pStateBuf`/`cbBufLen`/`bExecute`/`bBusy`/`bError`),
  `ST_EcSlaveState` layout (`nState`,`nLinkState` bytes), and the
  `EC_DEVICE_STATE_*`/`EC_LINK_STATE_OK`/`EC_DEVICE_STATE_MASK` constants (all
  confirmed present in the installed 3.6.3/3.7.x library on this machine).
- Verify the node↔slave mapping after an XAE I/O scan: master AmsNetId (`''` =
  local), that catalog node 1 = master, nodes 2..6 = the 5 slaves in scan order.
4024-clean (no defaulted method inputs).

**First XAE compile fixes (2026-07-24):**
- 13 parser errors cascaded from ONE reserved-keyword collision: a local
  `st : E_NodeState;` in `M_Refresh` — **`ST` is reserved** (Structured Text /
  the CDATA `<ST>` tag), so the declaration desynced the parser for the whole
  POU (the "Unknown type '_stateBuf[i].nState'" etc. were all downstream noise).
  Renamed `st`→`mapped` and `link`→`linkOk`. This is the same reserved-identifier
  class as §37 (`S`,`R`,`DT`,`Log`,`Min`,`Max`,`Action`); scan new locals against it.
- Dropped the `FB_EcGetMasterState` read (its `Get`-FB output member name is
  version-sensitive and unverifiable from the compiled library): the master
  topology node's state is now **inferred from the slave-states read outcome**
  (it answered ADS ⇒ OPERATIONAL; read error ⇒ OFFLINE with the segment). One
  fewer version-sensitive surface; `FB_EcGetAllSlaveStates` is the only
  Tc2_EtherCAT FB called.

## 72. TwinCAT 4024 becomes a guarded legacy profile, not the ceiling (2026-07-26)

**Policy inversion.** The library previously held every developer to 3.1.4024's
restrictions, so the *default* experience paid for the *legacy* target — most
visibly at `FB_SequenceBase.M_Advance`, whose 21 of 22 call sites had to repeat
`OnJump1 := -1, OnJump2 := -1, OnJump3 := -1`. That trade is now reversed:
**modern TwinCAT (>= 3.1.4026) is the default target and 4024 is a supported
legacy profile**, selected by one compiler define, `FRAKTAL_TC3_4024`, with
modern-only constructs wrapped in a conditional pragma:

```
{IF defined (FRAKTAL_TC3_4024)}
FirstStep : INT;          // legacy: caller must pass it
{ELSE}
FirstStep : INT := 0;     // modern: defaulted
{END_IF}
```

**Two Beckhoff facts made this safe** (InfoSys, *Conditional pragmas*):
conditional pragmas are valid in the **declaration part from 3.1.4024 onward**,
so the guard mechanism itself compiles on the legacy target; and there is **no
built-in compiler/TwinCAT version symbol** — `defined()`/`hasvalue()` only test
user-defined defines — so the switch has to be an explicit define rather than an
inferred version test.

**Changed**
- `Params/PL_FraktalCompat.TcGVL` (new) — the authoritative statement of the
  policy: what is guarded, how to build legacy, and the rule for adding the next
  guarded feature. Exposes `LEGACY_TC3_4024 : BOOL` and
  `COMPAT_PROFILE : STRING` so a deployed binary self-identifies without
  inspecting project settings.
- `FB_SequenceBase.M_Advance` — `OnJump1..3` default to `-1`;
  `.M_ResetBase` — `FirstStep` defaults to `0` (all four call sites passed `0`).
- 25 call sites simplified: `M_Advance(OnAdvance := 100)` and `M_ResetBase()`.
  The one real jump site keeps only what it uses:
  `M_Advance(OnAdvance := 999, OnJump1 := 810)`.

**Enforcement replaces remembering.** This defect class regressed four times
(§62, §64, §69, and once more found by the lint itself), so it is now checked
rather than recalled. `tools/plc_lint.py` rule C1: a defaulted METHOD input is
allowed **only** inside the `{ELSE}` of the legacy guard; `--profile 4024`
additionally rejects any *unguarded* modern construct. CI runs both profiles as a
matrix, so breaking the legacy build fails the gate. Self-tested against a
planted unguarded default and a planted wrongly-guarded one; 233 files clean in
both profiles.

**Caveat:** the define must be added to **every** PLC project in the solution
(library *and* application) — a conditional pragma is evaluated per compiled
project, so defining it only on the application would leave the library compiled
in modern form. Not compile-verified here (no XAE in this environment); the
source-level rules are gated, the pinned compile is still §1.5 pending work.

## 73. §5.7 tier conformance rows filled for the EM and Unit types (2026-07-26)

**What the audit had wrong.** A first read of §5.7 counted "eight rows missing"
for the Unit tier. §5.7 actually says the opposite for most of them: **T1/T4 and
the T2/T6/T7/T10 *mechanisms* are proven once in the framework base suite** and a
type **"shall not re-test inherited rows"** — verification is paid at the level
that owns the behaviour (O1), exactly like the code. `FB_Base_Tests` already
proves T1/T2/T4/T6. So the real shortfall was narrower: a type owes its
applicable rows re-proven with **its own** reasons, paths, modes and actions.

**Added — EM tier** (`FB_ClampEM_Tests`, 1 → 3 tests)
- **T3**: a dropped permissive on `CylA` must withhold the physical output and
  surface `INTERLOCK_DROPPED` through the EM naming `ClampIntlk.CylA`. The
  base-suite mechanism test cannot assert this: the value under test is the
  *composite tier's* path/reason pairing.
- **T5**: a stored `ST_ClampParCfg` with `SchemaVersion := 2` against an expected
  1 must fault `RECIPE_INVALID` at `Setup`, **and** a subsequent command must not
  drive the actuator ("never mis-runs", §3.8) — the second assertion is the one
  that matters, since faulting alone would still permit a mis-run.

**Added — Unit tier** (`FB_ClampStationUnit_Tests`, 1 → 4 tests)
- **T8**: the type does not override `_M_Supports`, so its set is the baseline
  AUTO+MANUAL. `SetMode(CALIBRATION)` must return FALSE, leave `ModeActive`
  unchanged, and **not** raise an error — a rejected request is not a fault
  (§3.7). Also asserts a supported mode still commits afterwards, so the
  rejection cannot have wedged the mode machine.
- **T10**: `Start()` accepts **iff** `ReleaseReportStart` reports `Released`,
  asserted in *both* directions. One direction would let the report drift from
  the gate it is supposed to describe (§7.8).
- **T6+T9**: the root adopts the deepest child's first-out **verbatim across two
  tiers** (`Stall.Station.Clamp.CylB`), and must not name itself. The two-hop walk
  is precisely what the Unit adds over the EM's single hop.

**Wiring**: both suites were already instantiated in `PRG_TcUnitRunner` and
registered in `Fraktal_Tests.plcproj`, so the new cases run with no further
plumbing. Totals 67 → 72 tests across 24 suites.

**Also corrected**: Annex H claimed T4/T5 were "left as the reader's exercise".
Stale — `FB_CylinderCM_Tests` covers T1–T5. Fixed there and in the audit.

**Status honesty**: these tests are written against the real APIs (every
identifier, member and visibility checked statically — `ModeActive` is a PROPERTY,
`CylA`/`CylB` are `VAR_OUTPUT`, `Start`/`Stop`/`SetMode` are public) but are **not
compiled or run** — no XAE here. They become a conformance *claim* only once green
in a run, which is the pending §1.5 CI compile.

## 74. Command-start lifecycle closes the mode-adapter reset gap (2026-07-27)

The Press Unit's `_M_SequenceHome`, `_M_SequenceChangeover`, and
`_M_SequenceAuto` methods still contained identical two-state reset/run machines.
That made an adapter look like a second sequence and tied the Unit's inherited
`_step` token to plumbing that belongs to the lifecycle. Moving reset only to
`OnModeChanged` would be incorrect: a finite HOME or CHANGEOVER command can be
started again without another mode change.

`FB_ModuleBase` now calls the additive protected `OnCommandStart` hook exactly
once for every accepted `Execute` edge, after the one-shot `OnInit` callback and
before `OnCyclic`/`_M_Dispatch`. This is the single command-local reset/latch
extension point; it does not replace the sequence's N000 process initialization
or N999 completion. `FB_Base_Tests` observes the hook across held Execute,
Execute-drop reset, and a second command edge.

`FB_UnitBase`'s existing transition hooks now match the normative signatures:
`OnModeChanged(NewMode, OldMode)` receives the committed transition and
`OnModeExit(FirstCall, RequestedMode)` receives a one-shot entry marker plus the
pending target. Repeated `SetMode` calls for the same pending target do not
re-arm `FirstCall`. The Press Unit implements `OnInit`, `OnCommandStart`,
`OnModeChanged`, `OnAbort`, and `OnAbortInError`; all reset/safe-withdraw wiring
is centralized in protected helpers. `OnCommandStart` resets only the chains:
it deliberately preserves a physical start pulse latched by `OnCyclic` on the
scan before the inherited Execute edge is consumed. Init, mode entry, and both
abort paths also clear that cross-mode input state. Its three sequence adapters are now
one-line `M_Run()` calls, while the application behavior remains solely in the
three `FB_SequenceBase` POUs. A Press TcUnit case starts HOME twice in the same
mode to guard the finite-chain restart behavior.

This is the deliberate Fraktal distillation of the useful Nexeed transition
idea, not an import of `Unit+Extension`, `OnInitHierarchy`, or a second
mode-release Boolean. Composition stays in `Setup`, first-scan work stays in
`OnInit`, mode release remains the authoritative `ST_ReleaseReport`, and mode
entry/exit remain the inherited Unit hooks.

Versioning: Core advances to `0.1.0.5`; Modules is rebuilt and repinned as
`0.1.0.4`; Demo advances to `0.1.0.3`; Press Demo and aggregate Tests advance to
`0.1.0.9`. Source/XML/lint validation is run here; the pinned XAE compile and
TcUnit execution remain required before release.

## 74. Fieldbus: fail-open on unreported slaves, and §10.5.1 demand gating (2026-07-26)

**Reported symptom:** the HMI showed K010B1/K010C1 in INIT while XAE showed OP.

**The HMI was not at fault.** Probing the PLC directly showed it *publishing*
`State = 1` for those nodes, so the tree rendered faithfully. Two real defects
sat underneath, both in this library.

**(a) Fail-open decode of unreported slaves.** `FB_EcGetAllSlaveStates` fills only
the first `nSlaves` buffer entries; the rest keep their previous/zero content. The
decode looped over the *declared* `_slaveCount` regardless, and a zeroed entry has
`linkState = 0`, which the nibble test reads as **link OK**. Live evidence:
`SlavesReported = 3` against 5 declared, and nodes 5/6 published
`State = OFFLINE` **with `LinkOk = TRUE`** — a slave that is not on the bus was
reported as healthy. Fixed: decode only the first `nSlaves` entries; publish the
surplus as `OFFLINE` + `LinkOk = FALSE` (fail-closed); `M_BusOk()` now also
returns FALSE when the master reports fewer slaves than the topology declares —
missing declared hardware is not a valid bus. New `CountMismatch` output makes the
"master reports N, project declares M" case visible instead of inferable, per
§10.5.1 ("unmatched mappings are commissioning errors, never silently guessed").

**(b) The bus was polled continuously.** §10.5.1 defines the topology as a
**diagnostic** surface, and the HMI already demand-gates *reading* it (read tiers,
`fieldbusScope`). The PLC nevertheless scanned the master every 250 ms forever, so
half the saving was fictional: ADS traffic and PLC time were spent maintaining
data nobody was reading. Added `FB_EcBusHealth.M_RequestScan(Active)`;
`M_RefreshFieldbus(BusViewActive)` and `MAIN.FieldbusViewActive` thread it, and
`OpcUaRepository.setFieldbusViewActive` now writes that flag so the gate is
end-to-end. Deliberate details: the **first** scan after Setup always runs (so
`M_BusOk()`, which feeds control logic rather than a view, is never based on
unread hardware); a rising request re-arms the poll timer immediately so opening
the view does not wait out the 250 ms; released gating **holds** the last states
rather than invalidating them (a stale-but-true picture beats a fabricated one);
and the HMI write is best-effort — a PLC without the flag keeps its own cadence.

**Not a defect — the INIT states are real.** The dev runtime's EtherCAT master is
bound to a **Null Adapter** in a usermode runtime ("running in the user mode
runtime" in the TCOM log) and the downloaded boot config contains *only* the
master (`=000+S-A610`), with zero mentions of EK1200/EL1809/EL2809/EL6001/EL9011.
With no NIC there are no EtherCAT frames, so slaves cannot leave INIT. XAE showing
OP is XAE's own configuration view, not the runtime's AL state. To see OP at
runtime, bind the real NIC (clear `SimulationMode`) and re-activate so the
terminals are actually downloaded.

## 75. Windows installer owns a secure remote-Web adapter (2026-07-28)

The loopback-only gateway boundary from §65 remains unchanged. Remote Windows
browser access is now a concrete installer option rather than only a deployment
instruction: `FraktalSetup.exe` bundles Caddy 2.11.4 from its official Windows
amd64 release, verifies the pinned SHA-512 before packaging, and ships its
Apache-2.0 license/readme. The gateway tray starts, stops, and restart-supervises
both the Dart gateway and Caddy; Caddy is present but inert unless a site
`proxy/Caddyfile` exists.

The wizard collects one exact `https://<host>[:port]` public origin, a constrained
username, and a minimum-12-character password. The password moves to the child
only through its process environment and is piped to `caddy hash-password`; only
the Argon2id hash enters the Caddyfile. Caddy terminates TLS, authenticates both
the static HMI and WebSocket upgrade, actively checks loopback `/livez`, keeps
WebSocket streams through reload churn, and proxies only to
`127.0.0.1:8080`. Its admin endpoint and config persistence are disabled. The
generated internal CA uses a site-owned persistent storage directory; only its
public root is copied to the obvious client-distribution path. The private CA
key is never exported.

Installation now treats `--port`, `--web-root`, the selected
`--plc-endpoint`, and the selected `--allow-origin` as structured
option/value pairs. Duplicate installer-owned options collapse to one value, and
`--port` is always normalized to `8080`; this repairs the observed deployed
`8080\` value that made Dart fail with `Invalid radix-10 number` before binding.
The optional elevated firewall helper permits only the Caddy program/HTTPS port
from `LocalSubnet` on Domain/Private profiles; port 8080 remains unreachable
remotely by construction.

Upgrades replace Caddy but preserve an existing validated Caddyfile, password
hash, CA, origin, and firewall rule when no new password is supplied. Supplying
a new password is the explicit reconfiguration edge and publishes the new file
only after Caddy formats and validates an atomic `.next` candidate. Linux/site
SSO and managed mTLS proxy policies remain deployment adapters; the bundled
Windows profile is the plug-and-produce LAN/basic-auth option, not a universal
identity provider.

## 76. The fault hard-lock: reset that recovers, and HELD for a lost permissive (2026-07-29)

An AUTO cycle on the CX2030 press reached N200 (`ram down`) and the operator
released the two-hand button mid-stroke. The machine hard-locked: no action at the
panel cleared it, and HOME — the sequence that exists to recover the machine — was
blocked by the fault it would have recovered from.

Read off the live PLC (`ads://5.132.128.188.1.1:851`) before changing anything:

```
PneumaticPress/Execute       = true        <- run command STILL asserted
PneumaticPress/Status/State  = 3 (ERROR)   Busy = false
PressRam/Execute             = true        <- child command STILL asserted
PressRam/Status/State        = 3 (ERROR)   ErrorID = 2003
CurrentStep/StepNo           = 200         awaiting PressRam.EXTEND
AlarmLog/Active[1]           = ACTIVE, MANUAL_RESET, 2003
AlarmLog/Blocking            = true        ControlDomain/ReadyForStart = true
Safety Devices[1..4]/State   = 2 (healthy) — nothing was actually unsafe
```

Three defects compounded, and the decisive one was **not** in the alarm log.

**(a) Stranded `Execute` latches.** `FB_ModuleBase.Cyclic`'s Execute-drop reset is
the only exit from a latched terminal state and it requires `Execute` low. A Unit
that is not `BUSY` never calls `_M_Dispatch` again, so the §6.8 step holding
`PressRam.Execute := TRUE` could never run to clear it, and nothing else in the
system owns that variable. The next HOME then re-issued an already-TRUE input: no
rising edge, so the ram never restarted, and the Unit re-adopted its fault through
the §8.2 rollup the moment it went BUSY. Even the `Stop` -> reset -> `Start`
sequence that `FB_AlarmLog_Tests` proves could not recover the *machine*, only the
event. `OnAbortInError` was the one path that dropped child commands, and it is
unreachable from an HMI: `E_HmiRequestKind` has no `ABORT`.

`OperatorReset` therefore now performs the control-state half of a reset
(`FB_UnitBase._M_RecoverState`): the new §3.14 `OnOperatorReset` hook, then
`_M_ReleaseChildCommands()`, then release of its own run command. `M_ReleaseCommand`
is new on `I_Module`/`FB_ModuleBase` (recursive in `FB_CompositeModuleBase`) and
cancels a command still `BUSY` through `AbortCommand()` before dropping `Execute` —
`BUSY` is not terminal, so un-asserting alone would leave the module unable to
accept any later edge. It deliberately never writes `_exec`: `Cyclic` keeps that
ownership (§47), so a live cause re-faults on the next edge instead of vanishing.

**(b) `OperatorReset` skipped `ACTIVE`.** It closed only `WAIT_RESET`, while
`Blocking` counts `ACTIVE` too — a guaranteed no-op for exactly the events that
block restart. Reaching `WAIT_RESET` needs the condition re-established, and
"two-hand held during a stroke" can only be re-established by starting, which the
event forbids. It now closes a `MANUAL_RESET` event from `ACTIVE` as well, stamping
`GoneAt`/`Duration` for one that never received a `Gone` so the ring entry keeps a
real duration. **Core §8.3(b) was amended** rather than diverged from: its two
`shall`s (never self-close; `Start` refused while `ACTIVE`/`WAIT_RESET`) are both
intact — an operator reset is not a self-close — but its lifecycle prose described
reset only from `WAIT_RESET`. The amendment also makes the control-state release and
the reachability of recovery modes normative.

**(c) A lost permissive was classified as a fault.** Releasing two-hand is expected
operator behaviour; ABORTED/STOPPED has one exit (Reset -> IDLE) and that exit was
the circle above. `FB_ModuleBase` gained `_M_Hold`/`_M_HoldDiag` and a published
`Held` flag (ISA-88 HELD, new Core §6.1 clause): `BUSY`, outputs withdrawn, reason
published at `LOW`, no alarm, and resolution is **level-based** — the base clears the
hold as soon as a scan stops re-asserting it, so no type can forget to. `Held` is
**not** an `E_ExecState` ordinal: that enum is transport contract and the HMI mirrors
its ordinals. `FB_CylinderCM` holds instead of faulting on a lost interlock and
rewinds to N010, so the resume re-energizes the direction output and re-arms
`MoveTimeout` with a full window instead of silently consuming travel time it was
not moving for. `FB_CompositeModuleBase._M_RollupHold` is the hold analogue of
`_M_RollupFault`, used by `FB_ClampEM` and by `FB_UnitBase`'s hold branch.

**(c′) The Unit's hold rollup was documented but never wired.** This paragraph used
to claim `_M_RollupHold` was "used by `FB_ClampEM` and by `FB_UnitBase`'s
awaited-module branch". `FB_ClampEM` did call it; `FB_UnitBase` never did — its
awaited branch called `_M_HoldDiag(_awaits.GetFaultSummary())` directly, so
`_M_RollupHold` had exactly one call site repository-wide and the Unit could only
report a hold on the module a step happened to name in `Awaits`. Press AUTO `N200`
passes `Awaits := 0` on purpose (§6.9: the step owns the ram's *not-reached*
disposition so the chain can offer scrap/return), and the two facts combined into a
silent defect: with the ram correctly `Held`, the Unit stayed `BUSY` with `Held`
FALSE and an empty `Status.Diagnostic`, which is what
`Two_hand_release_mid_stroke_holds_the_ram` had been failing on. It is pre-existing —
both the `Awaits := 0` and the missing call are unchanged since `4e47f37`.

The fix is in `FB_UnitBase.OnCyclic`, not in the project (§1.1 O1 — forgetting a call
must not be able to produce a wrong result). The hold branch now prefers the awaited
module when a step named one and otherwise falls back to `_M_RollupHold()` over the
registered children, so a hold rolls up whether or not the step awaits the child.
`Awaits := 0` scopes **fault** disposition only: a hold is recoverable information
that clears itself level-based and never blocks a restart, so there is nothing for a
step to "own" by staying silent about it. The two calls are deliberately exclusive
rather than OR-ed — TwinCAT does not short-circuit, so evaluating both would let a
second held child overwrite the named one.

The **fault** rollup stays explicit and is not made automatic here. That asymmetry is
the point of §6.9: adopting an awaited child's Error sets `_exec := ERROR` and
`_step := 0` before `_M_Dispatch` runs, so an automatic fault rollup would remove the
chain's ability to disposition a failure at all — `N200`'s scrap/return decision, and
`FB_ProbeUnitRaise`, both depend on it not firing.

Nothing was weakened to achieve this. The output is still withheld in the same
place by the same permit; the reset clears the **latch**, never the **condition**;
and `FB_FaultRecovery_Tests.Reset_never_bypasses_a_live_condition` pins that by
resetting with the air still missing and asserting `Start` stays refused, the live
condition is still named, and no output is restored. The press safety authority
remains the hardwired Bosch/Nexeed N54 D2 relay chain (§9.8,
`SAFETY_AND_CONTROL_POWER_PROFILE.md`); the standard PLC is not a safety function.

Deliberate non-changes, recorded so they are not "fixed" blindly:

- `ReleaseReportStart` still adds `std.release.unitNotReady` for a non-`READY`
  Unit. Letting `Start` run over a latched ERROR would be the symptom-hiding fix;
  the defect was that no operator action could make `_exec` leave ERROR. After one
  reset the Unit is `READY` and HOME starts (proven in the suite).
- `E_MachineState` gained no `HELD` member and `_M_OeeUpdate` still books a held
  Unit as run time, exactly as it already does for `BLOCKED`/`STARVED` waits. Both
  are transport/§8.5.1 contracts and neither was needed for recoverability.
- `ST_ModuleStatus` gained no member, so `HMI_CONTRACT.md` is unchanged. The
  operator sees a hold through `Status.Diagnostic`, which the HMI already renders.
- A hold has no upper time bound. It is visible (`Held`, the LOW first-out, the
  §6.9 pending walk) but it is not escalated to a fault after N seconds; that would
  be site alarm policy (§8.9), and on this press it would re-fault the machine for
  the ordinary act of pausing with the button released.

**Two-hand release inside the dwell (N220)** needed one project-level addition. The
press force during the dwell is the valve latched by the EXTEND that N200 already
completed, so withdrawing it leaves nothing to re-energize on resume:
`FB_CylinderCM.RestoreOutputs` is the symmetric counterpart to `WithdrawOutputs`
and re-asserts only the last commanded direction and only while that direction's own
permit holds — the caller asks, the module still decides.

**Universal fault clear.** `FB_UnitBase.RequestLocalReset` is an application seam for
an ordinary hardwired reset/acknowledge pushbutton, mirroring `RequestLocalControl`
(§9.8): a method rather than OPC UA data, so remote clients still go through the
access-gated `OPERATOR_RESET` request. A cabinet button is its own authorization
(physical presence), so it carries no §7.7 session check, but it is audited as a §8.3
event and recovers exactly the same state — never more. It is deliberately **per
Unit**: the composition root calls it once per root Unit a given input should clear,
so one physical button can serve one Unit or several without the framework choosing.
No press input was wired to it — `GVL_PressIO` channels 1..15 are fully assigned and
inventing an electrical tag is not an agent's call (§10.2.1) — so the seam ships
unwired on this project. The HMI half is `ui/global_reset_button.dart`, a fixed
corner control that fans out to the roots **this HMI shows**: §3.1a is a forest of
peers with no shared super-root, so there is nothing to "reset globally" in the PLC
and the fan-out belongs to the client. `ScopedPlcRepository` re-clamps every call to
the assigned scope and the PLC re-checks §7.7 per root.

Not verified here: **nothing was compiled.** There is no TwinCAT compiler in this
environment, so `plc_lint.py` (both profiles) plus XML well-formedness are the only
machine checks that ran on the ST; first real verification is the XAE build,
`Fraktal_Tests` run, and download. At the time of this change Core was `0.1.0.6`
and Modules `0.1.0.5` (additive `I_Module` growth: `M_ReleaseCommand`,
`HoldActive`). Section 77 supersedes those pins after the wider contract audit.

## 77. PLC-authoritative permissions and objective conformance audit (2026-07-31)

The permissions audit closed several authority splits rather than adding HMI-side
exceptions. `FB_UnitBase` remains the single remote mutation entry: access-policy
and session-timeout changes, control-power requests, decisions, configuration
writes, shelving and fieldbus force now use the acknowledged mailbox and are
checked by the PLC. Invalid access ordinals, corrupt policy values, invalid gates,
out-of-range timeouts and ambiguous alarm identities fail closed. Accepted
authenticated mutations rearm the idle timer and write an audit record containing
request kind, user and target; polling, release queries and denied attempts do not
keep a session alive. Source PIN literals were replaced with persistent,
OPC-UA-hidden, deployment-owned commissioning values; an empty value registers no
account.

Fieldbus force is now an explicit capability. `ST_IoChannel.Forceable` is
append-only and defaults `FALSE`; the topology/config projection carries it to the
HMI, which requires exact `ModulePath` ownership and does not render a force action
without that PLC capability. The Core route and the application resolver both
default to rejection. This deliberately leaves all current production channels
non-forceable until a mapped output and resolver have been individually reviewed.

The audit also restored the four-structure physical contract on the passive
digital-input and air-pressure CMs. Their `ParCfg` records begin with
`SchemaVersion`; air-switch conflict qualification moved into configuration with
the existing 500 ms default. The existing Modules test suite gained model-preset
coverage for IV3 and Matrix220. Three normative mismatches were resolved in favor
of the objectives: defensive coding now requires a semantic fail-safe path rather
than meaningless empty `ELSE` branches; the decision contract uses one active slot
per root (matching one step-state writer), with overlap rejection instead of a
mandatory queue; and §7.1 now makes immediate output withdrawal invariant while
§6.1 classifies the stopped command as HELD or fault. The decision slot still
needs its timeout/default/resolution implementation and tests.

Core and Modules are now `0.2.0.0`, and all downstream placeholders are pinned to
those versions. This is a minor-version change because the observable access,
force and recovery contracts grew; the TwinCAT fourth component remains reserved
for contract-neutral rebuilds as required by Part II.

The complete objective scorecard, open findings and ordered gap-closing program
are in `Specification/Reports/OBJECTIVES_AUDIT.md`. Highest priority is a licensed XAE
build plus TcUnit/CI evidence, followed by decision lifecycle completion, a typed
capability-driven write manifest, stronger conformance lint, controller/time
health and a reusable signal-tower contract. A capability-driven/generated design
is preferred: the PLC publishes a reviewed capability, one owning handler enforces
it, the HMI derives its control, and CI derives parity checks from the same source.

No TwinCAT compile or TcUnit execution was possible in this environment. The
Press Demo is an internal framework acceptance fixture, so its cabinet/electrical
state is not a Core/Modules conformance finding. If that fixture is ever deployed
to real equipment, the commissioning guide still applies; this change did not set
or clear `CONTROL_CIRCUIT_MAPPING_CONFIRMED`.

## 78. Decision resolver and capability-driven configuration writes (2026-07-31)

The two P1 authority gaps from §77 are now source-complete. `FB_UnitBase` owns the
entire §6.11 one-slot decision lifecycle: repeated identical requests are
idempotent; a different overlapping request is rejected and logged once; request
shape/default are validated before publication; operator input wins a same-scan
race with the monotonic timeout; timeout applies only a validated safe default;
operator/timeout/withdrawal/rejection events are distinct; and consumption clears
the whole slot atomically. `FB_Decision_Tests` covers operator, timeout, overlap,
invalid-default and withdrawal behavior. This supersedes §77's statement that the
resolver remained open.

Configuration editing no longer infers authority from a browse path. The
append-only `ST_ConfigEntry` tail publishes `WriteKey`, `WriteRevision`,
`E_ConfigKind`, `E_ConfigValueType`, `Writable`, `RequiresReady`, bounds,
engineering unit/label, and an exact enum domain. `FB_ConfigPager.M_Append` clears
that tail on every ordinary read-only entry so a reused page slot cannot retain
authority; `M_AppendCapability` is the only framework helper that populates it.
The HMI rejects missing, malformed and duplicate capabilities, maps them separately
from read-value hydration, re-resolves the current key/revision before every write,
and sends it through the same acknowledged mailbox. Custom inputs must match the
capability's full `Item`; manufacturing a key from a scalar tag is gone.

The first framework-owned typed handler is Unit `ModePolicy`: stable keys
`unit.modePolicy.<ordinal>.shield|style`, capability revision 1, exact enum
domains, root-owner check, and `READY`-only mutation. Unknown keys, stale revisions,
foreign targets and out-of-domain values reject without mutation. Project/type
handlers remain an extension seam but must append and recheck their own capability;
the framework-owned handler is separate so an override cannot hide it. HMI manifest
and repository tests prove fail-closed mapping and exact key/revision transport;
`FB_Unit_Tests` contains the corresponding PLC source assertions.

The mode-policy authority is persistent, not merely a mutable output mirror.
`_modePolicyVersion` and `_modePolicyStored[]` are `VAR PERSISTENT`; an unknown
version initializes the safe defaults once, subsequent activations restore the
stored records, and every accepted typed write updates both the public record and
its persistent backing before `ConfigRev` advances. The first activation after
this schema addition intentionally initializes version 1 rather than guessing at
an older memory layout.

Because the observable Core manifest contract grew, Core advances to `0.3.0.0`.
Modules remains `0.2.0.0` and is repinned to Core `0.3.0.0`; Demo, Press Demo and
Tests pin that same pair. The new `PLC/TwinCAT/{Framework,Tests,Examples}`
layout is retained, documentation paths are updated, and generated-directory
ignore rules now work at any depth. A licensed XAE build/TcUnit run and regenerated
TMC remain mandatory before this source can be called release-proven.

## 79. System health, time quality, signal tower, and live-facet closure (2026-07-31)

Core §2.7/§8.12 now has a concrete bounded implementation. `ST_TimeQuality`
separates availability, synchronization, source, offset and observation stamps;
`GVL_FraktalTime.Current` is the hidden PLC-wide quality authority and
`F_TimeSynchronized()` stamps quality beside diagnostics, alarm lifecycle edges,
part results and cycle/step wall-clock records. `FB_TcSystemHealthProbe` owns the
monotonic task-cycle/jitter measurement and accepts target metrics explicitly.
`FB_SystemHealthPublisher` owns validation, the small public status copy, and
Low/System/AUTO_RESET come/gone edges for task, controller, IPC, fieldbus/DC and
clock failures. Unsupported target metrics remain unavailable rather than healthy
zero. The Press fixture supplies honest synthetic values only in simulation; its
real profile stays conspicuously unavailable until target APIs and a documented
sync source are wired.

Core §8.13 is implemented once by `FB_SignalTower`. The Unit base derives it from
`MachineState`, the maximum severity in the authoritative active-alarm table, and
the active decision slot; it publishes semantic outputs only. Site choices are
schema-first `ST_SignalTowerParCfg`. Mailbox kind `LAMP_TEST := 26` is append-only,
MANUAL-gated, refused while BUSY, audited, acknowledged, clamped to 30 seconds and
self-clearing. No physical Press output was invented: the acceptance fixture tests
and publishes the semantic mapping, while a reviewed project Hardware Driver must
own any future electrical map.

The re-audit also found that several static/live HMI facets existed in types but
were not transported end to end. `M_AppendConfig` now actually exports hidden
nameplate, stall-time, model/catalog, mode-policy and alarm-rationalization fields;
manifest typing includes meta counts/reasons/shelvability. The generic snapshot
mapper now hydrates sparse active alarms, newest-first closed history, timestamp
quality, rationalization records, OEE/trend, part results, nameplate, safety and
control-power facets. It also corrected the cycle/OEE ring traversal to produce
oldest-to-newest trends. Mapper tests cover the real named-array shape and both
TwinCAT-DT and OPC-UA time normalization paths.

`tools/plc_lint.py` now checks the previously promised structural rules: the
four-record/schema-first contract, enum parity, inheritance/body/hook-super
invariants, semantic `CASE ELSE`, sequence ownership, EM-to-Unit containment,
reason collisions, project compile coverage, and deployed-root publication. Its
fixture suite is committed, but Python is absent from this workstation, so neither
the linter nor its fixture suite ran here. XML parsing, Dart analysis and focused
Flutter tests did run; a licensed XAE build and TcUnit remain the P0 release gate.

## 80. Shared-session Web read tiers (2026-07-31)

The Web gateway now implements the direct-client scalability contract instead of
relaying the complete published surface every cycle. `discoverPaths` returns one
revisioned path vector; `setReadTiers` carries compact indices into that vector;
and `readValues` accepts bounded batches which the Web/native gateway clients
chunk and merge. The repository remains the only tier classifier. After tier
installation, cyclic snapshots omit the static path vector and the native PLC
session excludes view-gated rings/topology until their owning view requests them.

The gateway deliberately does not let one browser mutate the shared native read
profile independently. It applies the intersection of all connected profiles:
a path becomes slow or excluded only when every browser agrees, and an
unconfigured/new client temporarily restores the full surface. Discovery changes
invalidate all profiles. This is the conservative multi-client rule that keeps
one HMI from starving another while retaining single-client O4 scaling.

Optional repeatable `--read-root` scopes are enforced consistently over snapshot
values/DataValues, discovery, tier indices and targeted reads. With no configured
read root, the upstream OPC UA/ADS identity remains the browse boundary for
backward-compatible commissioning; write authority remains separately fail-closed
behind `--write-root` and the PLC mailbox policy. Static analysis and focused
gateway/reconnect/repository tests passed; representative packaged large-forest
traffic and latency remain release acceptance evidence, not a source claim.

## 81. Generated reason text and rearranged aggregate manifest (2026-07-31)

`HMI/tool/generate_reason_catalog.dart` now derives the §8.8 code-to-message
projection from the authoritative Core `E_Reason` definition plus the registered
Core/Modules type-reason parameter lists. It rejects duplicate numbers and
symbols, emits deterministic Dart localization keys and English fallback text,
and has a CI `--check` gate. Snapshot hydration prefers that catalog for registered
diagnostic, alarm, part-result and control-power codes; an unknown external or
application reason preserves the PLC diagnostic text. Release-report descriptions
remain condition-specific rather than being replaced by a generic reason sentence,
which preserves §7.8 act-or-explain detail. This closes the §8.8 projection, not
§8.9's remaining generated rationalization-metadata work.

Moving the aggregate test sources into their dedicated owner folder initially
changed the `.plcproj`'s relative base and left 40 unresolved compile items.
Merely resolving those paths through sibling parent-relative Press references was insufficient: TwinCAT PLC
Control rejects `..` lexically before evaluating `Link` metadata (see §62). The
manifest therefore remains at `TwinCAT/`, with all `Tests/` and `Examples/`
includes expressed as downward paths from that common ancestor.
The repository-wide check resolves every compile item and the manifest stays
importable through **PLC → Add Existing Item**.

## 82. Generated rationalization and fixed host events (2026-07-31)

The §8.8 text generator now joins the numeric authorities (`E_Reason` plus the
registered Core/Modules type bands) to
`Specification/reason_rationalization.json`, which is keyed by symbol and
therefore does not duplicate reason numbers. It rejects incomplete/unknown
coverage, duplicate symbols/numbers, shelvable events, and shelvable Safety
records. One run derives four artifacts: the Dart localization/metadata lookup,
`PL_ReasonCatalog`, `F_ReasonMetaByIndex`, and `F_ReasonMeta`. CI `--check`
therefore covers PLC and HMI projections together. The shipped registry currently
contains 51 complete records, including the formerly missed final enum member
`TEST_FAULT`.

`FB_AlarmLog` now enforces the generated priority/category/shelvability for every
standard reason, so a caller cannot reclassify one alarm on one surface. The Unit
configuration manifest pages the complete generated catalog and any validated
external/application records. `RegisterMetaFull` is the extension seam for those
nonstandard bands; it rejects standard overrides, event-only alarm records, and
shelvable Safety records. `F_RationalizeDiagnostic` applies the same generated
priority/category at the first-out source, so `Status.Diagnostic`, the Unit alarm
log, HMI, and injected sinks cannot disagree for a standard reason. The HMI
hydrates the same fields and uses its generated copy as a deterministic fallback
during a partial server rollout. Events with no operator action stay logged but
do not render a blank action prompt.

Core §11.6 is projected by `FB_HostEventPublisher` and `ST_HostEvent`: each root
publishes a bounded 32-record read-only ring with sequence, fixed kind, station
path, optional part/subject/value, timestamp quality, verdict, reason, and an
explicit wrap flag. `FB_UnitBase` is the single producer for part lifecycle,
NOK, mode, and changeover events; `CHANGEOVER_STARTED` is tied to the accepted
CHANGEOVER Start edge and `CHANGEOVER_DONE` to successful sequence completion,
not merely mode selection or recipe commit. Named methods cover project-owned
tool/material changes. Optional push delivery is injected through
`I_HostEventSink`; its implementation storage is hidden from OPC UA and the ring
remains authoritative when no adapter exists.

The closing audit found one carrier-optional edge in that projection: the legacy
`CountNok()` counter could be called without emitting an attributed host event.
Core `0.4.0.0` now requires `CountNok(Reason)` with a non-`NONE` reason and makes
the counter increment plus fixed `NOK` event one operation. `_M_PartProcessed`
uses that same path, while a no-carrier sequence publishes an empty `PartUid`.
An unattributed reject is refused before carrier write and raises
`RESULT_RECORD_REJECTED` rather than creating unanalysable scrap data.

The HMI enum/domain/mapper mirrors the append-only event vocabulary and hydrates
the ring newest-first on demand. PLC source suites cover invalid events, all ten
fixed kinds, required fields, bounded wrapping, base mode emission, and generated
metadata authority. Core advances to `0.4.0.0`; Modules advances to `0.3.0.0` and
all downstream placeholders are repinned. These are source-level changes until a
licensed XAE build, aggregate TcUnit run, and regenerated TMC prove the binding.

## 83. Aggregate manifest repair after the TwinCAT tree rearrangement (2026-08-01)

The rearrangement accidentally moved `Fraktal_Tests.plcproj` inside its source
folder and converted the six Press fixture links to `..\Fraktal_Press_Demo\...`.
That made every file resolvable to ordinary filesystem tooling but reintroduced
the exact TwinCAT PLC Control import failure documented in §62: `..` is parsed as
an invalid PLC folder before `Link` metadata is evaluated. The manifest is again
at the `TwinCAT/` common ancestor, all 41 compile inputs are downward paths, the
tracked XAE project reference follows it, and the source-owned TMC remains under
`Tests/Fraktal_Tests/`.

P1 lint ownership now recognizes the same-named source directory beside a
common-ancestor aggregate manifest. It still resolves every explicit linked
input, while sibling applications remain accountable to their own manifests;
it also rejects any raw `..` compile segment before filesystem resolution can
mask the TwinCAT incompatibility. Regression fixtures cover both arrangements;
the suite now contains 18 tests.

## 84. Press and aggregate tests separated by GUID ownership (2026-08-01)

`PressDemoX32.tsproj` loaded both `Fraktal_Press_Demo.plcproj` and the aggregate
`Fraktal_Tests.plcproj`. Because the aggregate links the deployed Press Unit,
release evaluator, and four sequence POUs, PLC Control saw each physical object
twice in one XAE solution. A load produced 1,029 duplicate-object warnings and
repeatedly rewrote every shared POU/method GUID plus line-ID metadata. The six
files' declarations and implementations were verified identical to Git before
their original metadata was restored.

The Press system project now contains only the deployable Press application.
Aggregate tests run from a separate XAE solution/ADS port as §5.7 requires. P1
lint now resolves the PLC projects referenced by each `.tsproj` and rejects any
physical source intersection, preventing the same GUID churn from returning.
The linter suite contains 21 tests.

## 85. Compiler-cascade and Press system-project repair (2026-08-01)

The first licensed 4026 compile exposed three independent source defects whose
parser fallout appeared as a much longer error list. `FB_UnitBase` used a
TwinCAT-invalid `CASE` over `HmiRequest.TextValue`; it now uses `IF`/`ELSIF`
string comparisons. `FB_AlarmLog._M_Raise` declared local `meta` beside the
published `Meta[]` member; TwinCAT identifiers are case-insensitive, so the local
shadow made `Meta[i].ReasonCode` parse as a type expression. The local is now
`generatedMeta`. Finally, `E_ConfigValueType.TIME` used the reserved IEC type
keyword; the TC3 binding spells ordinal 3 `DURATION` while Core/HMI retain the
portable `time` vocabulary. No ordinal or observable schema changed.

The rearranged `PressDemo.tsproj` also contained only the PLC instance: its
EtherCAT device and all symbolic mappings were absent. Those were restored from
the existing Press system authority. EL1809 channels 9 and 13 were still named
`Reserve` in the XTI while the approved PLC tags were `_000BS901` and
`_000BS902`; the XTI names now match those exact electrical tags. A subsequent
XAE load resolved every mapping without the former `not linked` warnings.
`CONTROL_CIRCUIT_MAPPING_CONFIRMED` and `USE_SIMULATION` were not changed.

The corrected draft libraries were built and installed in dependency order:
Core `0.4.0.0`, then Modules `0.3.0.0`, followed by a fresh Press application
reload. Direct nested XAE builds for all three returned `LastBuildInfo=0` with an
empty Error List under `Debug|TwinCAT OS (ARMV7-A)`. The full system-project CLI
build still stops at `Check config` while the saved remote target is unavailable;
that is a target/configuration checkpoint, not a PLC compiler failure. The builds
regenerated Core, Modules, and Press TMC files; TcUnit, live TMC/OPC UA import,
and target acceptance remain open release evidence.

Lint now rejects reserved enum members (C2) and quoted/string `CASE` labels (C6)
so these two parser defects cannot recur silently. The suite contains 21 tests
and the real tree passes both modern and legacy-4024 profiles.

The aggregate test application now has its own 4026 wrapper,
`Tests/FraktalTests.slnx` / `FraktalTests.tsproj`, on ADS port 854.
It references the common-ancestor `Fraktal_Tests.plcproj` and loads without the
Press project, so the two applications cannot present the linked Press sources
to XAE twice. No target route is stored in this test wrapper by design. Its full
system build therefore stops at `Check config` until an isolated test runtime is
selected; aggregate test compilation and TcUnit execution remain open evidence.

## 86. Aggregate-test first compile reconciliation (2026-08-01)

The first interactive aggregate compile exposed an incomplete reserved-word
binding migration. Core already used `TimeClass` because TwinCAT reserves
`CLASS`, but four `FB_ClampStationUnit` calls, the Unit probe, and the profiler
tests still used the old named input/member `Class`. All PLC callers and test
assertions now use `TimeClass`. `HMI_CONTRACT.md` binds the deployed
`TimeClass` symbol, while the generic mapper accepts both `TimeClass` and the
legacy draft `Class` path during migration. C2 now reserves `CLASS` and its
existing parameterized regression fixture exercises both `TIME` and `CLASS`.

The moved aggregate manifest also linked `FB_PressDemoUnit` without its
application-owned `GVL_PressFieldbus`; that GVL and its owner-local `Io` folder
are now explicit downward links. The isolated `FraktalTests.tsproj` contains no
EtherCAT device and keeps ADS port 854; test execution cannot address the Press
hardware mapping accidentally.

Modules rebuilt with `LastBuildInfo=0` and zero errors, then the corrected
`0.3.0.0` library was installed. TwinCAT `CheckAllObjects` on the reloaded
aggregate project reported zero Error List entries. A full system-project build
still stops at `Check config` until an isolated test target is selected; TcUnit
execution remains the next acceptance checkpoint.

## 87. Connector completion of the extended I_Module contract (2026-08-01)

The next interactive aggregate build exposed a separate interface-completeness
gap. `FB_DeviceConnectorBase` implements `I_DeviceConnector` directly, and
`I_DeviceConnector` extends `I_Module`; unlike the three ordinary module tiers,
the connector deliberately does not inherit `FB_ModuleBase`. When `I_Module`
gained `M_ReleaseCommand` and `HoldActive`, the direct connector implementation
was not updated. The abstract Core type could still be packaged, but the
aggregate project's concrete `FB_ProbeConnector` correctly failed with the two
missing-implementation diagnostics.

The connector now implements both members at the correct ownership boundary.
`M_ReleaseCommand()` is a successful bounded no-op because a connector owns no
PLCopen `Execute` latch; the fronting Control Module owns and releases the
dependent command. Calling `Disconnect()` here would be wrong because Core
§3.15.2 requires the connector to retain bounded automatic reconnect. Likewise,
`HoldActive` is always `FALSE`: the connector publishes link state and its
diagnostic, while the fronting Control Module interprets `Reaction := HOLD` and
owns ISA-88 HELD lifecycle state. `FB_Connector_Tests` now exercises both
members on the concrete probe, so future interface drift reaches the aggregate
compiler seam.

Core `0.4.0.0` and Modules `0.3.0.0` were rebuilt and installed in dependency
order under `Debug|TwinCAT OS (x64)`; both returned `LastBuildInfo=0` with zero
Error List entries. The reloaded aggregate wrapper and its direct nested-project
build command also returned `LastBuildInfo=0`/zero errors, and `CheckAllObjects`
reported zero errors. The aggregate TMC/compile-info timestamp did not advance in
headless automation, so this evidence closes the reported source/compiler gap
but does not replace the still-open isolated-runtime TcUnit execution and fresh
test-TMC acceptance gate.

## 88. Runtime-test contract corrections after the first aggregate execution (2026-08-01)

The first isolated-runtime execution after the PLC-folder migration compiled and
ran all 27 suites, then exposed five failing test cases. A clause-by-clause audit
found no reason to relax production behavior:

- `FB_CycleProfiler` correctly derives elapsed time from `TIME()`. The profiler
  test opened and completed both cycles within one PLC scan, so its own measured
  minimum was legitimately zero. The test now keeps each cycle open across a
  task scan before asserting the Core §8.11 throughput markers.
- Core §3.10.2 defines the configuration manifest as a bounded page window. The
  Unit test assumed a stable write key remained on page zero after new base and
  generated entries were added. It now follows the advertised `PageCount` and
  searches every page while preserving the exact typed-write assertions.
- Core §6.1 maps `Error` from the owning lifecycle during `Cyclic()`. The invalid
  decision test faulted the private execution state through a protected probe
  and read the public output before that mapping pass. It now performs the next
  cyclic call before asserting the public fault and non-publication contract.
- The Press release policy is intentionally fail-safe. Child modules tick before
  the application-owned Unit release policy reevaluates their permits, so a
  restored two-hand input needs one scan to refresh the condition and one scan
  for the ram to consume it. Both restore assertions now observe that bounded
  propagation instead of requiring same-scan re-energization.
- The shared Press fixture tried to escape an open 500 ms AUTO dwell by issuing
  `Stop()` and several function-block calls inside one task scan. Those calls do
  not advance a TON, and stop-after-cycle correctly left the chain at N220. The
  cleanup now requests interruptible HOME, lets the normal Core §3.14.4 immediate
  mode-exit/Execute-drop handshake settle, homes the simulated devices, releases
  the terminal command, and commits AUTO before the next case.

The runtime warning that old persistent symbols such as `MAIN.AccessUsers` could
not be restored is independent: it is stale retained-runtime metadata after the
symbol rearrangement, not a command/release/test failure. Clearing or migrating
that retained data is a commissioning choice and was deliberately not automated.

The four changed TcUnit POUs parse as TwinCAT XML, `git diff --check` is clean,
the isolated wrapper build returns `LastBuildInfo=0` with an empty Error List,
and the nested `Fraktal_Tests Project` `CheckAllObjects()` call returns `TRUE`
with zero diagnostics. That compiler pass refreshed the aggregate wrapper's
common-ancestor `Fraktal_Tests.tmc`; no runtime configuration was activated or
downloaded. The acceptance gate remains a fresh isolated-runtime TcUnit run of
these sources.
That commissioning pass shall also clear **Autostart Boot Project** on the selected
test target: the XAE automation view reported it enabled, while §5.7 requires the
aggregate to remain non-autostart. Beckhoff defines this as a target-transferred
setting, so it was not guessed into the repository `.tsproj` or changed remotely
during a source audit.

## 89. Repeatable access-policy mailbox fixture (2026-08-01)

The next isolated-runtime run proved 91 of 92 tests, including every timing,
configuration-paging, decision, and Press recovery correction from §88. Its only
failure was `Mailbox_policy_is_self_gated_and_power_ack_is_authoritative`: the
fixture expected the `ACCESS_POLICY` threshold to begin at `NONE`, but TwinCAT
correctly restored `ADMIN` from the preceding successful run.

This is required production behavior, not a policy defect. Core §7.7(b) makes the
per-root policy persistent station configuration; “shipped default fully open”
describes a new/uncommissioned deployment, not a value to overwrite at every
restart. The test itself raises `ACCESS_POLICY` to `ADMIN` while authenticated,
so assuming that value disappears on the next execution contradicted the
contract it was testing.

`FB_Hmi_Tests` now commissions `ACCESS_POLICY` and `DATA_WRITE` to `NONE` through
the existing `ConfigureRequired` startup seam when its policy fixture initializes,
then sets `POWER_CONTROL` to `ADMIN` as before. The runtime mailbox remains the
only self-gated edit path under test; no production authorization or persistence
logic changed. The POU parses as TwinCAT XML, `git diff --check` is clean, and the
nested aggregate `CheckAllObjects()` returns `TRUE` with zero errors and warnings.
A fresh isolated-runtime execution remains the final acceptance step.

## 90. Tests and examples directory split (2026-08-01)

The former combined container mixed acceptance infrastructure,
generated test-runtime artifacts, reusable examples, and the physical Press
fixture in one ownership boundary. It is now split into `Tests/` and
`Examples/`: the aggregate TcUnit sources, test wrapper, dependencies, audit
tooling, and test-runtime artifacts live under `Tests/`; the generic demo,
Press demo, application wrappers, I/O configuration, and example runtime
artifacts live under `Examples/`.

`Fraktal_Tests.plcproj` deliberately remains directly under `TwinCAT/`, the
common ancestor of both branches. TwinCAT rejects parent-relative source links
in a PLC manifest, so the aggregate now uses only downward
`Tests\Fraktal_Tests\...` and `Examples\Fraktal_Press_Demo\...` compile paths.
The test XAE wrapper may reference that manifest as
`..\Fraktal_Tests.plcproj`; the no-parent rule applies to the PLC manifest's
compiled source links, not to the wrapper's project reference. The OPC UA
publication audit now defaults to the `TwinCAT/` root and resolves the Press
topology through `Examples/`.

Migration validation parsed 284 authored TwinCAT XML files, resolved all 270
compile includes across five PLC manifests, found no missing or
parent-relative compile source, and found no remaining authored reference to
the combined folder name. The publication audit passed. Isolated XAE loads of
`Tests/FraktalTests.tsproj` and `Examples/PressDemo.tsproj` each returned
`CheckAllObjects=TRUE` with zero real diagnostics; neither project was
activated or downloaded. This structural/compiler check does not replace the
separate isolated-runtime TcUnit acceptance gate described in §5.7.

## 91. Aggregate gate split in two; test manifest returned to `Tests/` (2026-08-01)

§62 hoisted `Fraktal_Tests.plcproj` to the `TwinCAT/` common ancestor so it could
link both `Tests/Fraktal_Tests/` and the Press example with downward-only paths.
That satisfied the `..` constraint but put a project manifest in the binding root —
the directory that has to stay free for further platform projects — and it proved
fragile: two folder re-layouts in succession left the manifest orphaned from its
sources, the second time with all 44 links dead and `FB_PressDemoUnit` undefined
across ~200 cascading compiler errors.

The manifest now lives at `Tests/Fraktal_Tests.plcproj` and owns only
`Tests/Fraktal_Tests/`. The two press-dependent suites — `FB_PressDemoUnit_Tests`
and `FB_FaultRecovery_Tests` — moved to a new
`Examples/PressDemo/PressTests.plcproj` (own solution, own `PRG_PressTestRunner`),
which reaches `Fraktal_Press_Demo/01_PneumaticPress/...` downward. Both gates must
be run; neither is a subset of the other. The press objects are still **linked, not
copied**, so that gate exercises the objects that deploy. `PressTests` must never
share a solution with `Fraktal_Press_Demo` (same source objects, duplicate GUIDs —
P1 rejects it). Only 2 of 34 suites were press-dependent, and both were
self-contained, so the split cost no shared fixtures.

Two rules learned the hard way, now enforced and documented:

- **`<Folder Include>` must mirror the `Compile Include` directories, never the
  `<Link>` paths.** XAE materializes those entries as real directories on disk
  relative to the manifest. Deriving the list from `<Link>` created phantom
  `Tests/Tests/`, `Tests/Examples/` and `Tests/PressDemo/{Io,Release,Sequences}`
  folders and left the source tree nested a level deeper.
- **`plc_lint.py` P1 must locate a project's ownership root, not assume a depth.**
  It computed `<manifest dir>/<stem>`; with the manifest one level up from
  `Tests/Fraktal_Tests/` that missed, fell back to the manifest's own directory,
  and claimed every sibling source in the tree — 226 false violations, with the
  fixture that described the correct behaviour already present and failing. The
  rule now searches for the same-named source directory beneath the manifest.

Not verified here: no TwinCAT compiler in this environment. Structural checks only
— every include resolves, no `..` segments, all project XML well-formed, both lint
profiles clean over 265 files, 21 linter fixtures green, and all 28 suites wired
into a runner. The next XAE build remains the authority.

## 92. Post-split compiler/runtime evidence and fieldbus profile reconciliation (2026-08-01)

The post-split authority checks are now real rather than inferred. A fresh local
TcUnit run of `Tests/Fraktal_Tests.plcproj` reports **84 successful, 0 failed, 84
total tests across 26 suites**. The two Press-owned suites are intentionally absent
from that result: `Examples/PressDemo/PressTests.plcproj` owns the remaining 8 tests
across 2 suites and still requires its own isolated-runtime run. The deployed Press
Demo remained running during all source/compiler work; no test configuration was
activated or downloaded.

The licensed CI placeholder was replaced with `tools/Invoke-TwinCatBuild.ps1`.
It opens each solution in a separate hidden Visual Studio/TwinCAT process, selects
`Debug|TwinCAT OS (x64)`, locates the hidden IEC project, and calls
`CheckAllObjects()` directly so an unavailable saved target cannot turn a PLC
compiler result into a system-level `Check config failed`. Both `FraktalTests` and
`PressTests` returned `TRUE`. `tools/tcunit_to_junit.py` validates all five TcUnit
summary fields, expected counts, zero failures, and total consistency before
emitting JUnit; its fixture tests and the supplied 84-test log are green. Hosted
runtime execution remains runner-owned because target selection/activation must be
isolated from any machine runtime.

XAE inspection also corrected §88's assumption that boot autostart could not be
represented in source. Both test `.tsproj` files now serialize
`BootProjectAutostart="false"`; XAE reload reports `False`, and the compiler gate
fails if either wrapper enables it. This is source configuration only and does not
alter an already activated target; the operator must still confirm the selected
test runtime before download.

The objective audit's former G4 was an over-specified mechanism, not a missing
diagnostic outcome. The normative base profile now matches the working ownership
split: `FB_EcBusHealth` supplies master-reported slave count/order/state/link and
configured-identity mismatch flags; the project I/O catalog supplies approved
tags, addresses, scaling and module ownership; the sole Hardware Driver supplies
live HAL/process-image values; and `FB_IoTopologyPublisher` validates/publishes the
join. Generic live CoE/PDO inference cannot author approved electrical identity or
Fraktal ownership, so `I_FieldbusScanner`/`FB_EcFieldbusScanner` remain an optional
fail-closed extension rather than a base-conformance requirement. `NodeCount` and
per-node `ChannelCount` already provide the compact active-length representation.

Finally, the gateway suite now includes a deterministic 4,000-path/four-WebSocket-
client acceptance case. After one-time discovery, each client's cyclic reply
contains only 120 consumed values and no repeated path vector; shared upstream
exclusions use the conservative client intersection, and a 600-value drill-down is
split into requests of at most 512. This closes the algorithmic scalability gap;
packaged real ADS/OPC-UA traffic/latency remains release evidence for the chosen
IPC and transport.

## 93. Runtime gate identity is runner plus count (2026-08-02)

An isolated Windows 10 x64 VM run supplied as the next test deployment completed
cleanly with 84 tests across 26 suites, but every reported suite was rooted at
`PRG_TcUnitRunner`. It therefore repeated the Core/Modules gate rather than
executing the intended two-suite Press gate, whose task calls
`PRG_PressTestRunner` and whose expected summary is 8 tests across 2 suites.

The discrepancy is deployment identity, not a test-source defect: the committed
`PressTests/PlcTask.TcTTO` calls `PRG_PressTestRunner`, and its manifest owns only
the two Press suites. The operating rule now requires matching both runner path
and expected counts before accepting runtime evidence. If a Press deployment
reports the Core runner, inspect the selected solution/application and stale boot
data on that isolated target. `BootProjectAutostart="false"` in the source wrapper
prevents a new autostart choice; it cannot erase a boot application previously
created on the runtime. The JUnit converter now requires `--expected-runner` and
fails on missing, mixed, or unexpected runner paths in addition to count/summary
failures. The VM result is archived as an independent Core/Modules repeat, while
the 8-test Press gate remains open.

The same check found post-rearrangement source drift in the Core wrapper:
`Tests/FraktalTests.tsproj` no longer serialized `BootProjectAutostart="false"`,
although the Press wrapper still did. The explicit false value is restored. This
protects future activations but still does not remove boot data already written
to the VM.

## 94. Complete split runtime gate and Press fixture boundary (2026-08-02)

The correctly selected `PRG_PressTestRunner` subsequently completed on the
isolated Windows 10 x64 VM: 8 successful, 0 failed, 8 total tests across the two
intended suites (`PressDemoTests` and `FaultRecoveryTests`). The fail-closed
runner/count validator accepted the archived raw output. Together with the
Core/Modules result, the split program is 92/92 tests across 28 suites. Evidence
and source/TMC hashes are recorded in
`Specification/Evidence/2026-08-02_Press_TcUnit.md`.

The preceding `PRG_TcUnitRunner.*` persistent-symbol restoration warning is stale
test-runtime metadata after replacing the Core application on ADS port 851, not
a Press failure. The old symbols were skipped and the correct Press runner then
completed. The VM USB-support warning is likewise non-blocking for this simulated
fixture.

Press Demo's scope is now stated without ambiguity: it is an internal Fraktal
feature-testing bench, not a real machine project, production reference,
conformance target, SAT, or safety-validation artifact. Its sequences, release
policy, simulated plant, illustrative I/O data, and 8-test gate exercise framework
integration. Any real project must own its engineering and independently satisfy
the deployment, electrical, risk-assessment, and certified-safety gates.

## 92. Short-circuit guard defects and lint rule C7 (2026-08-02)

A deep hunt across the PLC and HMI trees before publishing found two real PLC
defects, both of the same class and both on ordinary not-found paths — which is
why a green 92/92 TcUnit run could not have caught either.

IEC 61131-3 does not mandate short-circuit evaluation of `AND`/`OR`, and
TwinCAT's compile option for it is off by default. The protected operand of a
guard is therefore evaluated regardless:

- `FB_AsciiDeviceCM.SendRequest` used
  `IF _chan = 0 OR (_chan.State() <> OPEN)`, calling a method on a **null
  interface** whenever no channel is injected — a runtime fault, not a bad value.
  `OnCyclic` in the same file already guarded correctly with a separate
  statement, which is what identifies this as an oversight rather than a choice.
- `FB_LocalRecipeProvider.Load` used
  `IF (hit = 0) OR ... OR (_size[hit] <> Size)`, reading `_size[0]` of an
  `ARRAY[1..MAX_RECIPES]` whenever a recipe key is not found. The branch outcome
  is still correct, so it is silent today and becomes a bounds violation the
  moment a project enables the implicit `CheckBounds` POU.

Both are now separate statements; behavior is unchanged.

`plc_lint` gains **C7**: a guard may not dereference or index the symbol it is
testing against 0 within the same condition. Three fixtures cover the null-call
form, the 1-based-index form, and the split guard that must stay clean. The rule
was validated against the **real pre-fix sources from HEAD**, not only its own
fixtures — it reports exactly those two files at the right lines and nothing
else. That check exists because an earlier rule (D1) had been validated only
against fixtures and encoded the wrong invariant (see `OBJECTIVES_AUDIT_REVIEW.md`
§R0).

Swept and found clean in the same pass: ring-index math in every publisher (all
use the correct `(x MOD n) + 1` for 1-based arrays), sentinel-index guards in
`FB_AlarmLog`/`FB_CycleProfiler`/`FB_PermIntlk` (early-`RETURN` guarded),
division by a named operand in shipped sources (none), HMI ordinal-to-enum
conversions from PLC data (all range-checked or via the bounds-checked
`_enumAt`), the fieldbus topology recursion (a single `parent` field makes any
cycle unreachable from the `parent = 0` roots), and null assertions in the
PLC-facing Dart layer.

Not verified here: no TwinCAT compiler in this environment. Both edits are
structural only; the next XAE build remains the authority.

## 93. `_retVal` is a one-scan signal; `M_BeginScan` for chart languages (2026-08-03)

Building the SFC rendition of the AUTO chart surfaced a real gap: `M_Advance`
clears `_retVal` as part of committing the transition, which is correct when
`M_Advance` *is* the transition (ST), but leaves nothing to clear it when the
SFC/LD/FBD runtime owns the transition. The Nexeed reference drives its charts
exactly this way — step actions assign `_retVal := OK` / `JUMP1` /
`CheckUnitDone(...)`, and transitions are expressions such as `_retVal = OK` and
`(_retVal = OK) AND (_retVal2 = OK)`.

`FB_SequenceBase` gains **`M_BeginScan()`**, which clears `_retVal` and nothing
else. The owner calls it once per PLC cycle immediately before executing the
chart. Clearing at the top of a scan is equivalent to clearing after the previous
scan's transitions, and it additionally forces every step action to re-assert its
own result each scan — which is what makes a stale `ADVANCE` impossible rather
than merely unlikely.

The method deliberately does **not** touch `_driveIssued` or `_delay`. Those are
step-scoped: resetting them every scan would make `M_TryIssue` re-issue a child
command every cycle and stop `M_Delay` ever elapsing. They re-arm on step change
through `M_ClearTransition`, whose role is now documented as the shared *step
exit* action — the SFC exit action runs after the transition was evaluated, so a
chart may use it instead of `M_BeginScan`. `M_Advance` is unchanged, so the four
shipped ST charts and the 92-test runtime result are unaffected.

Two linter defects were found in the same pass, both of the "rule silently does
not apply" class:

- `POU_DECL` tolerated only the `ABSTRACT` qualifier, so
  `FUNCTION_BLOCK INTERNAL FB_SFC_PressDemoAuto EXTENDS FB_SequenceBase` parsed
  as name `INTERNAL` with no base. The object was registered under the wrong name
  and **every inheritance-keyed rule (D1/H1/A1/S1) skipped it**. The regex now
  accepts any combination of FB qualifiers, and `abstract` is derived from the
  qualifier list rather than from "was there a qualifier". Verified by reverting
  the fix: the new fixture fails with `'S1' not found in set()`.
- **S1 demanded the ST skeleton of every** `FB_SequenceBase` descendant. A chart
  body has no `CASE _step OF` and no `M_Advance`, so a legitimate SFC chart could
  only pass by pretending to be ST. S1 now recognises `<SFC>`/`<LD>`/`<FBD>`
  bodies and applies the chart contract instead: carry `_retVal`, record steps via
  `M_Step(`, and clear the result once per scan via `M_BeginScan(` or
  `M_ClearTransition(`.

`Sequences/AlterLanguages/` is declared **not built** (`NOT_BUILT_PARTS`): it holds
alternative-language renditions kept beside the shipped chart for comparison. Such
files are still linted for source rules but are neither conformance targets (S1)
nor compile-list omissions (P1). Before this, the in-progress SFC chart tripped P1
for being absent from every `.plcproj` — correctly, but for a file that is not
meant to be in one.

Not verified here: no TwinCAT compiler in this environment. The new method is
three lines of ST and the rest is tooling; the next XAE build remains the
authority.

## 94. SFC AUTO chart moved into the project and given the ST chart's behavior (2026-08-03)

`FB_SFC_PressDemoAuto` moved from `Sequences/AlterLanguages/` to `Sequences/` and
is now a compile input of `Fraktal_Press_Demo.plcproj`. Its declaration matches
`FB_PressDemoAuto` (same child references, `Setup`, `M_Reset`), and each
`CASE _step OF` branch of the ST chart became one ST method:

    A000_Initialize   A100_AwaitTwoHand  A110_RamUp      A130_DoorOpen
    A150_SlideInside  A170_TransferSettle A180_DoorClose A200_RamDown
    A220_PressDwell   A230_RecordResult  A240_ReturnToLoadPosition
    A999_CycleComplete

Each body is the ST branch verbatim with the trailing `M_Advance(...)` removed:
in a chart language the runtime owns the transition, so a step action only
produces `_retVal`. The N220 dwell keeps its hold-not-fault behavior (§ hard-lock
fix) unchanged.

**The chart graph itself is not generated.** A TwinCAT SFC body is a serialized
object graph (`SFCImplementationObject` → `SFCSegment` → typed nodes with
`Id`/`IdParent` identities and attribute GUIDs), and the only example available
in this repository contains one step, one transition, one jump and **zero**
`SFCAction` objects — there is no `<Action>` element anywhere in the tree either.
Synthesising twelve action-bearing steps from that would mean inventing the
majority of the schema with no compiler available to check it, and a malformed
archive is worse than none because it looks finished. The graph is therefore
drawn in XAE, where the work is mechanical: each step's action is one call
(`A200_RamDown();`) and each transition is `_retVal = E_StepResult.ADVANCE`. The
`N999 → N100` loop is the chart's back edge.

The owner must call `M_BeginScan()` once per PLC cycle before executing the chart
(§6.8). `FB_PressDemoUnit` still drives the ST twin; switching modes over is a
deliberate separate change, not a side effect of adding the chart.

S1's chart branch was relaxed to require only what a chart object can prove about
itself — `_retVal` and `M_Step(`. The per-scan clear is the owner's call or an
editor-wired exit action, neither visible in the chart file, so demanding the
token there produced a false positive on a correct chart.

The `NOT_BUILT_PARTS` / `AlterLanguages` exemption added in §93 was removed: the
folder no longer exists, and an unused, fixture-free exemption inside a gate is a
hole rather than a policy. Restoring it is six lines if language variants return.

## 95. The per-scan chain reset moved into FB_UnitBase (O1) (2026-08-03)

§93 introduced `M_BeginScan()` and §6.8 made calling it the *owner's* obligation.
That was the wrong side of the line for O1: a project adding an SFC chart would
have had to remember one call, and forgetting it produces an intermittent fault —
a transition firing on a result its step never produced — which is exactly the
class of defect the framework exists to make impossible.

The reset is now framework-driven and costs a project nothing:

- new `I_Sequence` interface exposes `M_BeginScan()` — the sliver of a chain its
  owner needs, the reverse of the `I_SequenceHost` bridge the chain receives;
- `FB_SequenceBase IMPLEMENTS I_Sequence` and announces itself from `M_Attach`,
  which every chain already calls at `Setup`;
- `I_SequenceHost` gains `M_SequenceRegister`; `FB_UnitBase` keeps a bounded
  `ARRAY[1..PL_Fraktal.MAX_SEQUENCES] OF I_Sequence` with idempotent registration
  (Setup may run more than once) and refuses rather than silently drops on
  overflow;
- `FB_UnitBase.OnCyclic` calls `_M_BeginSequenceScan()` immediately after
  `SUPER^.OnCyclic()`. `FB_ModuleBase.Cyclic` runs `OnCyclic()` before
  `_M_Dispatch()`, so the reset is guaranteed to land before any step action of
  the same scan.

Sizing: the press Unit attaches seven chains — three top-level plus the shared
`FB_PressDemoLoadPosition` nested in each of Home, Changeover, Auto and the SFC
Auto — so a bound of 16 leaves headroom. The null check before
`_sequences[i].M_BeginScan()` is a separate statement, per rule C7.

Project-side effect: **none required**. `FB_PressDemoUnit` is unchanged and
`FB_SFC_PressDemoAuto` needs no wiring; both simply inherit the guarantee. Core
§6.8 was corrected to state that the framework performs the reset rather than the
owner.

Not verified here: no TwinCAT compiler in this environment.

## 96. Composite sub-chains: M_RunSub, and the O1 trimming rule (2026-08-03)

Four charts repeated the same eight lines to run a sub-chain as one step — a
`_running` latch, a reset carrying the composite step number, the run call, a
`Done` test clearing the latch. `FB_SequenceBase` now owns all of it:

    _retVal := M_RunSub(Sub := _loadPosition, BaseStepNo := 240);

- `M_ChainRun` is a virtual no-op on the base. An ST sub-chain overrides it (this
  is the old `M_Run`); a chart-language POU leaves it alone, because its body *is*
  the chart and the runtime executes it. Only a chain used compositely overrides.
- `M_ChainReset(BaseStepNo)` is concrete on the base: `_baseStepNo` moved there,
  since offsetting a sub-chain's step records by its composite step number (§6.5)
  is a framework concept, not an application one. `OnChainReset` is the virtual
  hook for application state and is empty by default.
- `_subRunning` joins `_driveIssued` and `_delay` as step-scoped state cleared by
  `M_ClearTransition`.

That last point removed a real hazard rather than just lines. The Changeover
chart's `JUMP1` back to its composite step used to need an explicit
`_loadPositionRunning := FALSE;` to make the sub-chain restart; miss it and the
chain silently never runs again. A jump is a step change, so the base now clears
the latch on the framework's own path and the manual reset is gone.

Project code: **10 insertions, 73 deletions** across the five sequence files, and
`FB_PressDemoLoadPosition` lost its `_baseStepNo` and its whole `M_Reset`.

Core §1.1 gained the **O1 trimming rule** normatively, and AGENTS.md §3 leads with
it: repetition in more than one project object is a framework defect to absorb, a
project shall never be required to remember a call for correctness, and the
threshold is measured (more than once) rather than judged. §95's per-scan reset
and this change are its two worked examples.

Not verified here: no TwinCAT compiler in this environment. Note for the first
build — an ST chart used as a composite sub-chain must now override `M_ChainRun`
rather than `M_Run`; `FB_PressDemoLoadPosition` is the only such chain today and
has been renamed. Top-level chains keep `M_Run`, called by the Unit's adapters.

## 97. `Sub` is reserved; C2's word list completed (2026-08-03)

`M_RunSub`'s input was named `Sub`. `SUB` is the IEC 61131-3 subtraction
function, so the declaration parsed as an operator and the compiler emitted about
forty cascading syntax errors pointing at innocent lines — the exact failure mode
rule C2 exists to prevent. The input is now `Chain`.

C2 did not catch it because its word list was incomplete and inconsistently so:
`MOD`, `MAX` and `MIN` were present while `ADD`, `SUB` and `DIV` were not. The 43
missing IEC standard functions and operators are now listed.

They live in a **separate** `RESERVED_FUNCTIONS` set applied to variable
identifiers only, not to enumeration members. The shipped `E_CylinderPosition`
has a member `MID` and compiles: `{attribute 'qualified_only'}` keeps a member
clear of the `MID()` string function, so folding these words into the keyword set
would have produced a false positive on correct, working code. Both directions
now have fixtures — the four-keyword rejection and the qualified-enum acceptance.

One test-harness note worth recording: the suite's `_rules()` helper calls
`lint_repository`, which runs repository-scope rules only. Per-file rules (C1-C7)
must be asserted through `lint_file`, as the pre-existing C2 enum test already
did. `main()` runs both passes, so the CLI and CI were never affected — but a
fixture written against `_rules()` for a per-file rule silently passes nothing.

Not verified here: no TwinCAT compiler in this environment. The rename is
mechanical and lint-clean; the user's build is the authority.

## 98. SFC steps bound to their step bodies (2026-08-03)

The chart was drawn in XAE — twelve steps `A000`..`A999`, twelve transitions all
reading `_retVal = E_StepResult.ADVANCE`, and the `A999 -> A100` jump — leaving
only the step-to-body binding.

§94 declined to synthesise the SFC graph because the archive had no example of an
action-bearing step. With the drawn chart in hand that guesswork disappeared: the
archive carries its **own descriptor table**, mapping each attribute GUID to an
identifier and a description. It states outright that
`{700a583f-b4d4-43e4-8c14-629c7cd3bec8}` is `MainAction`, *"Name of the action to
be called if the step is active"*, alongside `EntryAction`, `ExitAction`,
`MinTime`, `MaxTime`, `InitStep` and the rest. Every step's ten attributes were
resolved from that table rather than inferred from position.

Two consequences decided the implementation:

- **MainAction, not EntryAction.** The bodies poll child `Done` flags and timers,
  so they must run every scan the step is active. An entry action runs once on
  activation and the chain would stall forever at the first step — a failure that
  looks like a hung machine, not a wiring mistake. Picking the wrong empty string
  attribute out of the five was the single real risk here, and the descriptor
  table removed it.
- **Actions, not methods.** `MainAction` resolves to an ACTION of the POU. The
  twelve generated METHODs are therefore now ACTIONs of the same names; each body
  is unchanged, with the documentation comment moved into the action body since an
  action has no declaration. `Setup` and `M_Reset` remain methods.

Verified structurally: XML parses, twelve `<Action>` objects exist, and every one
of the twelve steps names an action that is defined in the file. 267 files clean
in both profiles, 36 fixtures green.

Not verified here: no TwinCAT compiler in this environment. First build should
confirm that XAE resolves each `MainAction` name to its action and that the chart
advances past `A000` — if it stalls on the first step, the binding landed on the
wrong attribute despite the descriptor table.

## 99. Press-not-reached disposition path — a worked §6.10 jump (2026-08-03)

`FB_PressDemoAuto` gains a branch for the ram failing to reach the extended
position, as the reference example of a §6.10 jump:

    N200 --JUMP1--> N250 (operator confirms the failure)
                 -> N260 (part dispositioned NOK)
                 -> N240 (rejoin the existing return-to-start-position step)

**N200 no longer awaits the ram, and that is the whole design.** An *awaited*
child fault is adopted by `FB_UnitBase.OnCyclic`
(`IF (_awaits <> 0) AND_THEN _awaits.FaultActive THEN _M_FaultDiag(...)`), and
`_M_FaultDiag` sets `_exec := ERROR` and `_step := 0`. `FB_ModuleBase.Cyclic`
runs `OnCyclic()` before `_M_Dispatch()`, so the Unit is already in ERROR in the
same scan and the chain never gets a dispatch in which to offer the operator
anything. A chart that wants to own a child's failure must therefore stop handing
that child to the §6.9 auto-rollup; the wait stays named through `M_Await`
(§6.9(b)) and the cylinder still raises its own `CYL_NOT_EXTENDED` alarm, so
nothing is lost from the operator's view.

The trade is explicit and worth stating: during N200 the Unit will no longer
adopt a ram fault automatically. That is the point — the chain dispositions the
part instead of stopping — but it means any *other* ram failure in that step is
also the chart's responsibility now.

Two smaller decisions:

- N250 publishes the decision every scan. §6.11 specifies an idempotent active
  request, so ask-and-await collapse into the one step the operator sees, rather
  than the Changeover chart's split ask/await pair.
- `Default := 0` and `Timeout := T#0S`: scrapping a part is deliberate, so there
  is no silent timeout disposition.
- N999 checks `_partDispositioned` so a part already scrapped at N260 is not also
  counted good. `M_Reset` clears the flag.

The SFC twin gains `A250_ConfirmPressFailure` and `A260_ScrapPart`, and
`A200_RamDown`/`A999_CycleComplete` were refreshed from the ST bodies. The chart's
step and jump structure is drawn in XAE by hand; the JUMP1 branch out of `A200`
is the transition `_retVal = E_StepResult.JUMP1`.

Not verified here: no TwinCAT compiler in this environment.

## 100. Two-hand release during door close; failure branch renumbered (2026-08-03)

**Renumbered** the press-not-reached branch from N250/N260 to **N210/N215** to
match the steps drawn in the SFC (`A210`, `A215`). The numbers now follow process
position rather than insertion order, and the ST `CASE` was reassembled in numeric
order — §99 had left 250/260 sitting between 220 and 230, which read as if the
branch belonged there.

**New two-hand abort path.** Releasing a two-hand button while the door is closing
is operator intent, not a fault, so N180 gains a second jump:

    N180 --JUMP1--> N185 (door back up) -> N190 (slide out) -> N100 (two-hand wait)

- Completion wins the race: `IF _door.Done` is tested before the release, so a
  door that finished in the same scan the button was released still advances.
- The release is a named wait (§6.9(b)), so the stall walk can say *why* the step
  left, and `_door.Execute := FALSE` releases the close through the §6.1
  Execute-drop reset rather than aborting the child.
- N190 drops `_startLatched`, so the cycle cannot resume without a fresh two-hand
  press — returning to N100 alone would otherwise re-arm on the stale latch.

The SFC twin gains `A185_DoorReopen` and `A190_SlideOutsideAfterAbort`, and
`A180_DoorClose`/`A200_RamDown`/`A210`/`A215` were re-synced from the renumbered ST
branches. All fourteen drawn steps are bound to a defined action; `A185`/`A190`
are waiting on their steps.

**Open question for the next pass, deliberately not decided here:** the abort path
leaves the part lifecycle open. N100 called `M_PartReceived` and N150 called
`M_PartStarted`, but the abort returns to N100 without a `M_PartProcessed`, so the
part is neither dispositioned nor re-received cleanly. Whether an aborted part
should be scrapped, re-received, or tracked as the same part is a process
decision, not a framework one.

Not verified here: no TwinCAT compiler in this environment.

## 101. The two-hand abort keeps the same part; M_Reset actually clears now (2026-08-03)

Closing §100's open question, per the process decision: an aborted part is the
**same part**, because nothing was processed. N100 therefore receives a physical
part **once**:

    IF NOT _partInMachine THEN
        _traceAccepted := M_PartReceived();
        _partInMachine := TRUE;
    END_IF

`_partInMachine` is released where the part actually leaves — N215 on scrap and
N999 on completion — so the abort path can return to N100 as many times as the
operator likes without opening a duplicate §3.16.3 record for one physical part.

`M_PartStarted` (N150) is deliberately **not** guarded. Each pass is a genuine
processing attempt on that part, and collapsing them would hide a part that was
attempted three times before it succeeded.

**A defect this uncovered.** `M_Reset` never cleared `_partDispositioned` either —
the edit in §99 silently did nothing, because a `.TcPOU` method keeps its
declaration and implementation in *separate* CDATA blocks and the replacement was
written against the two concatenated. `M_Reset` was still just `M_ResetBase(0);`.
Left alone, a chart reset after a scrap would have carried `_partDispositioned =
TRUE` into the next cycle and skipped counting a good part. Both trackers are now
cleared there, in both charts.

The general lesson is worth stating because it will recur: text edits against
`.TcPOU` files must target one CDATA section. Matching across the boundary
produces a silent no-op, not an error — the same failure shape as a lint rule that
does not apply.

Not verified here: no TwinCAT compiler in this environment.

## 102. SFC abort branch bound; the two charts are at parity (2026-08-03)

`A185` and `A190` were drawn and are now bound to `A185_DoorReopen` and
`A190_SlideOutsideAfterAbort`. The chart is complete: **16 steps, 18 transitions,
2 jumps, every step bound to a defined action and no orphan actions.**

The two renditions are at parity. Both carry the same step numbers —
0, 100, 110, 130, 150, 170, 180, 185, 190, 200, 210, 215, 220, 230, 240, 999 —
and the same two branch points:

    N180 --JUMP1--> N185   (advance -> N200)
    N200 --JUMP1--> N210   (advance -> N220)

N240 is the one step with no `M_Step` call of its own: it delegates to the
sub-chain through `M_RunSub(Chain := _loadPosition, BaseStepNo := 240)`, which
offsets the sub-chain's own step records by 240 so the stall walk still reports
one continuous chain (§6.5). A parity check that greps for `M_Step(StepNo :=` will
therefore always show 240 as missing from the chart side; that is correct, not a
gap.

Not verified here: no TwinCAT compiler in this environment. The chart now has two
jump branches to exercise on the first run — release a two-hand button mid
door-close, and let the ram time out extending.

## 103. Sequence-language guide: ST vs SFC vs LD (2026-08-03)

`README.md` gains § "Writing a sequence: ST, SFC or LD" and AGENTS.md §3 gains the
operational form, so the SFC work is repeatable instead of folklore.

The organising idea is that only **who evaluates the transition** differs — ST's
`M_Advance`, the SFC runtime, or LD's rungs — and everything else follows: whether
the step body calls `M_Advance`, what a transition condition looks like, whether
`M_ChainRun` is overridden, and who clears `_retVal`.

Recorded because each cost real time to learn:

- The archive carries its **own descriptor table**. A step has ten attributes and
  five are empty strings; `MainAction` is
  `{700a583f-b4d4-43e4-8c14-629c7cd3bec8}` and the full GUID table is in the
  README. Binding `EntryAction` by mistake stalls the chain at its first step
  forever — a failure that reads as a hung machine.
- `MainAction` resolves to an **ACTION**, never a method.
- A `.TcPOU` edit must target **one** CDATA section; matching across the
  declaration/implementation boundary is a silent no-op that reports success.
- To own a child's failure a step must stop awaiting it, because the awaited-fault
  rollup runs before `_M_Dispatch`.
- The `FB_SFC_` prefix is **not a convention** — it exists only so two renditions
  of one chain can coexist in the demo. This is now stated in both documents.

**LD is specified but not yet implemented.** The README describes the
integer-state-machine form — one rung per state, `[EQ(_step, N)]──(A<N>_Action)`,
with the action keeping its `M_Advance` because the rungs do not evaluate
transitions. `FB_LD_PressDemoAuto` is not created here: an `<LD>` body is a
serialized object graph and there is **no LD example anywhere** to derive it from —
none in this repository and none in the Nexeed reference, which is entirely ST and
SFC. Synthesising one would be inventing a whole schema with no compiler to check
it. The SFC arrived the same way: the empty chart shell was created in XAE first,
after which filling and binding it was mechanical.

## 104. Ladder rendition: FB_LD_PressDemoAuto, and S1's `<LADDER>` blind spot (2026-08-03)

`FB_LD_PressDemoAuto` now carries its declaration, `Setup`/`M_Reset` and all
sixteen rung actions over the empty network TwinCAT created. Each action is the ST
branch **including** its `M_Advance` call: ladder rungs dispatch on `_step` but do
not evaluate transitions, so the action still commits its own result and the
`OnJump1..3` mapping keeps both jump branches declarative. The rung table is in
the README; every rung has the same shape, `[EQ(_step, N)]──(A<N>_Action)`.

**A ladder body is nothing like an SFC body.** Where SFC is a serialized object
graph, ladder is a single `ModelJson` attribute holding a JSON document:

    <o t="LadderImplementationObject">
      <v n="ModelJson">"{ "$type": "LadderDataModel", "Networks": [ … ] }"</v>

That is far more amenable to generation — `$type`-discriminated JSON rather than
`Id`/`IdParent` object identities. The remaining unknown is only the element
vocabulary (contact, box, connection), which **one drawn rung would supply**; the
other fifteen are then mechanical.

**S1 had a blind spot.** Its chart-body detection matched `<SFC>`, `<LD>` and
`<FBD>`, but TwinCAT writes a ladder body as **`<LADDER>`** — so the moment a real
ladder POU appeared, S1 demanded the ST skeleton of it and reported five missing
tokens. The rule applied, but to the wrong contract, which is the same failure
shape as a rule that does not apply at all. It now recognises
`<SFC>`/`<LADDER>`/`<LD>`/`<FBD>`/`<CFC>`, and distinguishes them: a `<LADDER>`
chain must carry `M_Advance(` because its rungs do not transition, while an
`<SFC>` chart must not need it. Two fixtures cover both directions.

Not verified here: no TwinCAT compiler in this environment. The rungs are not
drawn, so the POU compiles as a chain whose body does nothing until they exist —
the actions themselves are complete.

## 105. The ladder face is a base class: FB_SequenceBaseLd (2026-08-03)

§104 was wrong about how a ladder chain calls the framework. A rung has no
statement context — a box runs because **power reaches it** — so a method cannot
simply be "called from a rung"; it needs a boolean input to wire that power to.
The user's `FB_SequenceBaseLd` establishes the pattern: re-expose the step
vocabulary with `Run : BOOL` as the FIRST input and delegate to `SUPER^` when it
is TRUE. Nineteen further methods now follow those two, so the whole vocabulary is
wireable: awaits, gate/issue, delay, part lifecycle, decisions, stop/end-of-cycle,
fault, sub-chain and the shared exit action. A call with `Run = FALSE` is a no-op
and a value-returning one yields its fail-closed default.

The worked rung (N000) shows the shape: `EQ(_step, 0)` gates the rung, and the
boxes chain left to right through `InputItems` so power flows
`MOVE(_retVal := ADVANCE)` → `M_Step` → `M_Advance`, with a `BoxTreeAssign`
writing the three `_outCmd` flags. Rungs dispatch but do not evaluate transitions,
so each still ends in `M_Advance`.

**S1 had three blind spots, all found by this one file:**

- **`<NWL>`.** A ladder body is a *network list* — the `<LADDER>`/`ModelJson`
  form seen in the empty shell is not what TwinCAT writes once the POU has
  content. §104's fix matched `<LADDER>` and missed the real thing.
- **Direct-inheritance test.** S1 compared the base name for equality, so every
  chain behind `FB_SequenceBaseLd` was skipped entirely — the ladder POU was never
  checked. It now walks the chain with `derives()`.
- **ABSTRACT bases.** With the chain walk in place, `FB_SequenceBaseLd` itself was
  flagged for lacking `_retVal`. A base is scaffolding, not a chain.

Also: in a network list a call appears as a `BoxType` string (`"M_Step"`), never
the ST call syntax, so the token check matches names rather than `M_Step(`. Three
fixtures cover the chain walk, the abstract skip and an `<NWL>` body.

**Open risk, deliberately not resolved here.** Re-declaring an inherited method
with an extra input is not a signature-compatible override in IEC 61131-3. The
pattern is the user's and is followed consistently, but the first compile is the
authority; if it is rejected the fix is distinct names (`M_StepLd`, …) with the
same delegation bodies.

**Remaining rungs not generated.** The `<NWL>` graph is replicable from an
example, but N000 is unconditional — an `EQ` gate plus a straight box chain. Every
other step branches (`IF _pressRam.Done`, `IF M_TryIssue`, `IF/ELSIF`), and the
contact/branch vocabulary for that appears nowhere in this file. Generating them
would mean inventing that part of the graph with no compiler to check it, on a
file that has already been rebuilt twice. One conditional rung — N110 ram-up is
the smallest — supplies the missing vocabulary, after which the remaining rungs
are mechanical.

## 106. Sequence flow-chart contract (PLC half) (2026-08-03)

The HMI wants a per-module tab drawing the whole chain: every step, the active one
highlighted with its elapsed time, red when it outruns its guard, and click-through
from a step to the module it commands. Today only `CurrentStep` is published, so
the PLC half had to come first.

**The inventory is discovered, not authored.** `_M_SetStep` is the single funnel
every step of every chain already passes through, so `_M_RecordSequenceStep`
registers each step there the first time it is seen, matched by `StepNo` and
bounded by `MAX_SEQUENCE_STEPS` (32). A chain author writes **nothing** — the §1.1
O1 trimming rule applied to a new feature rather than retrofitted afterwards. A
step not yet reached is simply absent, which is honest: the chart shows what the
chain has actually done.

New/changed contract:

- `ST_SequenceStep` — StepNo, StepName, AwaitingLabel, **AwaitsPath**, TimeClass,
  ExpectedTime, Visited, LastDuration.
- `FB_UnitBase`: `SequenceSteps` + `SequenceStepCount`, `CurrentStepElapsed`,
  `CurrentStepTimedOut` (the same `_tStall` watchdog §6.9 stalls on).
- `FB_ModuleBase`: `SequenceViewEnabled` — every module can enable or suppress its
  own tab, so a type too simple to be worth drawing leaves it FALSE. `FB_UnitBase`
  defaults it TRUE in `OnInit`, and a concrete Unit may vary it per mode.

**`AwaitsPath` is the "direct wiring".** The drill-down target is the module the
step *declares* through `Awaits`, read once in `_M_SetStep` — no `IF`/`CASE` chose
it, so the link is unambiguous by construction. This gives the rule its teeth: a
step that wants to be click-through **shall** pass a constant module reference to
`Awaits` and command that module unconditionally in the same step.

Two consequences worth stating plainly:

- A step that passes `Awaits := 0` publishes an empty `AwaitsPath` and is therefore
  **not** click-through. Press AUTO `N200` is exactly this case — it dropped its
  await deliberately to own the ram's failure (§99), so it trades drill-down for
  disposition. That is a real trade the chart now makes visible.
- H1 caught this work in the act: the first version set `SequenceViewEnabled`
  before `SUPER^.OnInit()`. The gate was right and the line moved.

**Not done here: the HMI half.** The Flutter side needs the domain model, the
snapshot mapper rows, a `ModuleTabKind.sequence` tab rendering the chart, the
click-through into `AwaitsPath`, and the step-detail panel for a step with no
failure state. The contract above is what it will bind to.

Not verified here: no TwinCAT compiler in this environment.

## 107. Raising a step error the framework cannot see (2026-08-04)

§106 left a hole it named honestly: a step whose command sits behind an `IF`/`CASE`
cannot hand its child to `Awaits`, so nothing rolls the child's fault up and the step
waits until the stall guard with no link to what broke. `N200` chose that trade
deliberately, but it had to be a **choice**, not the only option.

Two calls on `FB_SequenceBase` close it, and the reaction is fixed rather than
per-step:

- `M_RaiseFromChild(Source : I_Module) : BOOL` — adopts the child's own first-out
  verbatim (`GetFaultSummary()`), with the child's path as the §3.13 drill-down link.
  Returns FALSE when the child is not faulted, so it is safe every scan.
- `M_RaiseCustom(Reason, DescriptionKey, Severity, Category, LinkPath) : BOOL` — a
  message the step defines itself, for a rule no module reports.

Both route through the new `I_SequenceHost.M_SequenceRaise(Diag, LinkPath)`, which
stamps `ErrorActive`/`ErrorSourcePath` on the **active** flow-chart row *before*
`_M_FaultDiag` adopts the diagnostic. Order matters: `_M_FaultDiag` sets `_step := 0`
on the Unit, and the row index has to be read while it still points at the raising
step.

**Stop is free; resume is the part that needed designing.** `_M_Dispatch` only runs
while `_exec = BUSY`, so the fault stops the chain by itself, frozen *on* the step —
its own `_step` is untouched (the Unit's `_step := 0` is a different variable). The
hazard is what happens after the operator clears it: the step would resume with
`M_TryIssue`'s one-shot already spent, `M_Delay`'s timer half-run and `M_RunSub`'s
latch set — i.e. still believing a handshake that failed. So `FB_UnitBase` now edge-
detects the *end* of ERROR (`_errClr : R_TRIG` on `_exec <> E_ExecState.ERROR`),
clears the row marks and calls `M_ResumeAfterError()` on every registered chain,
which calls `M_ClearTransition()`. The step re-issues and re-tests. Whether the chain
continues there or restarts from the top stays the project's call in `OnCommandStart`
— `FB_ProbeUnitRaise` exposes both through `RestartOnCommand`.

`Severity`/`Category` on `M_RaiseCustom` are a **proposal**, not the last word:
`_M_FaultDiag` runs `F_RationalizeDiagnostic`, so a reason in the §8.8 registry takes
the registry's priority and category and the inputs are ignored. They survive for a
project band code (10000+) — which is precisely where a message of a deliberately
different level belongs. The first draft of the doc comment claimed the caller always
won; reading `F_RationalizeDiagnostic` corrected it.

**The worked example is a test, not a demo edit.** `FB_ProbeRaiseChain` +
`FB_ProbeUnitRaise` + `FB_SequenceRaise_Tests` prove the three promises (stop, link,
re-evaluate). The probe unit registers its child and ticks it but deliberately does
**not** call `_M_RollupFault()` — that omission *is* the scenario. The press demo was
left alone: `N200` still owns the ram's failure, which the user confirmed needs no
raise, and inventing a use for it in a chain that runs on real hardware would have
been a behavioural change nobody asked for.

HMI half: `SequenceStep.errorActive`/`errorSourcePath`, and `linkPath` resolving
`errorSourcePath` **before** `awaitsPath` — the operator wants the module that
failed, not the one the step nominally commands. An errored row blinks red whether or
not it is still active (a timeout only ever marks the running step), and the step
detail lists the raiser.

No compiler here: structurally verified only — both lint profiles clean on 273 files,
every touched `.TcPOU` re-parsed as XML, 172 HMI tests and `flutter analyze` clean.
The TcUnit suite's first real run is the XAE download.

## 108. Messages that inform without stopping — §6.9(e) (2026-08-04)

§107 gave a step one reaction: stop. That is wrong for the two conditions the press
demo actually has, and both were asked for by name.

**N180 — two-hand released while the door closes.** Designed operator behaviour: the
door goes back up, the part slides out, the cycle returns to N100. Faulting there
would charge downtime for someone letting go of a button. But a cycle *was* abandoned
with the part still in the machine, so it belongs in the shift log.

**N200 — the ram did not reach.** The chain already owns this: confirm with the
operator, scrap the part, go home. It passes `Awaits := 0` precisely so the framework
does **not** adopt the fault (§99). The cost was that the failure existed only on the
ram module — the Unit said nothing. "Passed and displayed on the HMI, but it shouldn't
stop the sequence" is exactly the missing third option.

Three calls on `FB_SequenceBase`, none of which touch `_exec`:

- `M_RaiseWarning(Reason, DescriptionKey, Severity, Category)` — the step states the
  rule itself.
- `M_ReportFromChild(Source)` — the child's own first-out, published verbatim
  (`GetFaultSummary()`) but **not adopted**. The counterpart of `M_RaiseFromChild`.
- Both route through `I_SequenceHost.M_SequenceWarn(Diag)` → `FB_UnitBase`, which
  raises an **AUTO_RESET come+gone** ring entry (§8.3(c)) and stamps the active
  §3.13 row.

Three details that make it correct rather than merely present:

1. **AUTO_RESET is not cosmetic.** `_M_UpdateBlocking` only goes blocking on a
   `MANUAL_RESET` entry, so a message provably cannot gate the next `Start`. The test
   asserts `ResetClass` and `Blocking` rather than trusting the comment.
2. **Once per visit.** The step body calls it unguarded every scan; `_warnRaised` is
   step-scoped and `M_ClearTransition` re-arms it on commit. Without this the ring
   would fill with one entry per cycle of the task — the O1 rule again: a project
   shall never have to remember an edge latch for correctness. The test asserts
   `RingHead` moved by exactly one across three scans.
3. **`WarningSourcePath` is what makes N200 visible.** The row link is the *message's*
   subject, so a step that reports a child is click-through to that child even with
   `Awaits := 0` — the trade §106 made visible is now paid back. Precedence in the
   HMI is error → reported → declared `Awaits`, most specific first.

The mark is cleared when the step is **entered again**, not when the chain moves on:
an amber row means "this is what happened on the last pass", which is the useful
statement for a looping cycle.

New: `PL_PressReasons` (project band 12000-12999, `PRESS_TWO_HAND_RELEASED := 12001`).
A project code sits outside the shipped §8.8 registry, so `F_RationalizeDiagnostic`
leaves the step's chosen severity alone — which is what makes "a message of a
different level" actually possible rather than nominal.

Two sequencing defects in my own §107 tests surfaced while writing this and are
fixed: the first test asserted `SequenceStepCount = 3` when only two steps had been
reached (the inventory is honest about that — the assertion was not), and the
custom-message test ran on a chain that had already advanced past step 30, so it
would have exercised the completion step instead. It now uses its own Unit instance.

Structural verification only, as before: 274 files clean in both lint profiles, all
touched `.TcPOU`/`.TcGVL`/`.plcproj` re-parsed as XML, 175 HMI tests and
`flutter analyze` clean. The five-test TcUnit suite has never executed — the XAE
download is its first run.

## 109. Concurrent branches — §6.12 (2026-08-04)

A parallel branch was drawn into `FB_SFC_PressDemoAuto` (A250 on the main line,
A300/A310 on a second leg) with `_conRetVal : ARRAY[1..MAX_PARALLEL_BRANCHES]` added
to the base — a per-leg transition result, which is exactly the right first move: two
legs cannot share one `_retVal`. Finishing it turned up more that could not be shared.

**Every step-scoped latch had to become per-branch.** `_driveIssued`, `_delay`,
`_subRunning` and the §6.9(e) message latch are singular per chain. With two legs live
in the same POU, leg A's `M_TryIssue` consumed leg B's one-shot, so only one leg could
ever command a child — and `M_ClearTransition` cleared *all* of `_conRetVal`, so leg A
committing a step wiped leg B's result mid-motion. They are now
`ARRAY[0..MAX_PARALLEL_BRANCHES]`, indexed by a scan-scoped cursor. Index 0 is the
main line, which is every step of every chain that has no parallel branch — so
nothing existing changed.

**A latent bug fell out of it.** The re-arm of those latches lived in
`M_ClearTransition`, which ST reaches through `M_Advance` on commit. A chart language
never calls it — its engine owns the transition, so there is no commit point — and
nothing else re-armed anything. `M_TryIssue` therefore fired once per chart **RUN**
instead of once per step: the SFC rendition would have commanded its first cylinder
and then silently nothing. It never bit because `FB_SFC_PressDemoAuto` is compiled but
not instantiated. The re-arm now lives in `M_Step`, the one call every step of every
language makes, keyed by step number and branch.

**What stays singular is a decision, not an omission.** `CurrentStep`, the §6.9 stall
walk and the §8.11.4 profiler follow the **main line** only. A first-out has to name
one step; letting whichever leg ran last write them would make the walk report at
random. So a leg is timed and guarded on its own §3.13 row instead — `Active`,
`Elapsed`, `TimedOut` per row — which is also what the HMI needs to draw several live
steps at once. `_M_SetStep` keeps the signature every inline chain already calls; the
leg routing sits in the host bridge (`M_SequenceSetStep`), so no project call site
moved (§1.1 O1).

**The ST answer is not an array — it is a chain.** `M_RunPar(Chain, BaseStepNo,
Branch)` per leg plus `_retVal := M_ParJoin();` gives a leg its own instance, hence its
own step pointer, `_retVal` and latches by construction: the collisions above cannot
arise. It reads as §1.1 O4 applied to sequences — a work position is a *thing*, so make
it a type and instantiate it rather than duplicating its steps in a drawing — and it is
the only form that nests, is reusable, and works in ST. The leg list is the `M_RunPar`
calls themselves, so there is nothing to register and nothing to forget when a leg is
added (O1). It is documented as the preferred form; the native divergence stays
supported because a chart is often the clearest way to *show* two short legs.

**HMI.** Liveness moved from "the row whose StepNo matches CurrentStep" to the row's own
`Active` flag, with a documented fallback to the old rule when **no** row reports Active
— so the tab does not go blank against an older runtime. The rule is a named type
(`SequenceRowState.of`) rather than inline build logic, which is what made it testable
without standing up an AppState. Leg rows are indented and badged `∥n`, and a leg blinks
on its **own** guard.

The press demo's leg commands nothing on purpose: the press has one work position, and
inventing a second would change what the machine does. The steps are real (`M_Step`
with `Branch := 1`, records that reach the chart), so the pattern is live and visible —
the place a real second position would go is marked.

**Follow-up: the cursor is set by `M_Step`, not by a call before it.** The first cut
had a separate `M_Branch(Index := n)`. Folding it into `M_Step` as a defaulted input
removed a method from the base and a line from every leg step, and — the part that
matters more — made two mistakes unrepresentable: declaring a leg without recording a
step, and recording a step under the wrong leg because the declaration was forgotten.
The default is "this chain's own leg", which is the main line for a top-level chain and
the fork-assigned index for a chain running as a leg, so a main-line step and a
sub-chain leg both stay silent about branches. The cost is one [TC3] wrinkle: defaulted
method inputs are 4026+, so the declaration is pragma-guarded (rule C1) and a legacy
`FRAKTAL_TC3_4024` build must write `Branch := 0` at every `M_Step` call — the same
tax that profile already pays on `M_ResetBase` and `M_Advance`.

Structural verification only: 278 files clean in both lint profiles, every touched
archive re-parsed as XML, the SFC graph re-walked to confirm the branch is parallel
(legs open with a step, not a transition), 177 HMI tests and `flutter analyze` clean.
The two new TcUnit suites have never executed — the XAE download is their first run.

## 110. Derived state flags — §3.12 (2026-08-04)

Reading the Nexeed reference next to the press demo turned up a real modelling error
in ours. `OutCmd.Homed` was set by the HOME sequence and by CHANGEOVER, and cleared at
the start of AUTO. That is a **latch**, and a latch only a sequence can clear: jog an
axis off the reference position in MANUAL and the Unit goes on reporting `Homed` with
nothing running to contradict it. The reference gets this right by construction —
`StationOutImmStruct.TypeSetupOk` is an `OutImm`, recomputed, not announced.

The rule now written into §3.12: **ask what makes the value change.** A command
produced it and it stands until another command replaces it → `OutCmd`. It is simply
true right now → `OutImm`, derived every scan. `CycleCompleted` and
`ChangeoverCompleted` stay in `OutCmd` (a cycle ran; a changeover ran). `Homed` moved.

**`_M_State(Idx, Key, Ok) : BOOL`** on `FB_ModuleBase`, returning the value so the
assignment reads exactly as it did before. What it adds is the part nobody writes per
flag: the name, `Since` on the synchronized clock — "closed" is rarely the question,
"closed for how long" is — and a bounded generic table the HMI renders without knowing
the module type. Deliberately the same shape as `_M_Await(Idx, Label, Ok)`: one idiom
for "a named boolean the framework publishes", not two.

The part worth arguing about is **abandonment**. A flag is only honest if it is
published unconditionally every scan, and the mechanism must not be able to leave a
stale claim standing — that being the exact failure it exists to prevent. So a flag
not published in a scan is marked `Stale` and forced FALSE by a sweep at the top of
`Cyclic`, before that scan's `OnCyclic` re-publishes. The HMI renders `Stale` as
*unknown* rather than as a confident "off", because a forced FALSE is the absence of a
claim, not a claim.

Deriving `Homed` also exposed a duplicate: `OutImm.ReadyForLoad` was the same three-
cylinder expression written a second time. There is now one derivation, with
`ReadyForLoad` reading from it under the name the load gate uses (§1.1 O9).

**S1 was wrong about ladder, and the rebuilt ladder proved it.** Mid-work the ladder
came back driving `_step` directly from a MOVE box — the integer state machine
without `_retVal` or `M_Advance` — and the gate went red. S1 was demanding a
transition *mechanism* it had no business nominating: SFC progresses through `_retVal`
because its runtime reads it, ladder progresses by writing `_step`, and forcing a rung
through `M_Advance` to satisfy a linter is the tail wagging the dog. S1 now requires
what actually matters — the chart records its steps, and has *some* way to move
(`M_Advance`, `_retVal`, or `_step`). The fixture that encoded the old contract was
replaced with two that encode the new boundary, including a chart that records steps
but cannot progress at all, which is still rejected.

Removing `Homed` from `ST_PneumaticPressOutCmd` meant removing its assignment from the
ladder archive. My first attempt used a regex ending in `</o>`, which matched a nested
close and ate half the neighbouring operand — the file stayed plausible and stopped
being well-formed XML. Repaired by line range and re-parsed. The lesson is the one
already in the README about chart bodies: they are object graphs, so cut on structure,
never on a lazy regex.

Structural verification only: 280 files clean in both lint profiles, 42 linter
fixtures pass, every archive re-parsed as XML, `flutter analyze` clean and 178 HMI
tests passing. `FB_StateFlag_Tests` has never executed — the XAE download is its first
run, and it is also where the `OutCmd.Homed` removal proves itself, since two press
suites now assert `OutImm.Homed` instead.

## 111. Keeping M_Advance, and finally using its defaults (2026-08-04)

Once the ladder proved a chain can move by writing `_step` directly, the fair question
was whether `M_Advance` earns its place. It does, but not for the reason it looks like.

It is **not** what registers a step. `M_Step` is: `M_Step` → `M_SequenceSetStep` →
`_M_RecordSequenceStep` fills the §3.13 rows, and `FB_UnitBase` never reads `_retVal`
at all. So the HMI argument for keeping it is worth nothing.

What it earns is an **enforceable invariant**. `M_Advance` is the one place a step
declares its complete set of exits, and S1 uses exactly that: one `M_Advance` per
non-terminal `CASE _step` branch, terminal steps excused because they end with
`M_Complete()` or `Done := TRUE`. A step branch with no exit is a hung chain, and that
check finds it at commit time. Replace it with `_step := N` scattered through
conditionals and the property becomes "does some assignment to `_step` happen on every
path", which a regex gate cannot decide — it would need dataflow analysis. Trading an
enforced invariant for one saved line is a bad deal under §1.1 O9, and the graph being
readable from the last line of each branch is O2. So: **ST chains shall use
`M_Advance`; chart languages shall not be forced into it**, since neither SFC nor a
ladder rung has a commit point to hang it on.

The real simplification was already available and unused. `OnJump1..3` have had
pragma-guarded defaults since the compat policy was inverted — the policy document
even names `OnJump1 := -1, OnJump2 := -1, OnJump3 := -1` at 22 call sites as the thing
that inversion was *for*. Nobody then went back and deleted them. 32 call sites now
read `M_Advance(OnAdvance := 999);`, and the three real jumps in the demo stand out
instead of hiding among `-1`s.

That also settles a worry left open in §109. Using these defaults makes the demo
modern-profile-only, exactly like `M_Step(Branch := …)` does — but that was already
the intended direction the moment the policy was inverted, not a new cost introduced
by the parallel-branch work. A 4024 build writes the arguments out; that is the whole
content of the legacy profile.

Not changed: `M_Advance` still mirrors `ActiveStep := target` even though the next
scan's `M_Step` would set it anyway. Removing it would move `ActiveStep` a scan later
and shift assertions in two suites for no gain.

280 files clean in both profiles, 42 linter fixtures, archives well-formed, 178 HMI
tests. No compiler here — the XAE download remains the first real check.

## 112. Explicit split and rejoin: neither leg is the main line (2026-08-04)

The SFC parallel branch was re-cut so that **both** legs are numbered — leg 1 is
A200→A240→A250, leg 2 is A300→A310 — instead of leg 1 sitting on branch 0 and
borrowing `_retVal`. That is the better model and it should have been built this way:

- A simultaneous divergence has **N equal legs**. Numbering one of them 0 was an
  artefact of the `Branch` default, not of IEC. The §3.13 chart drew that leg
  unindented and the other indented, which reads as *subordinate* when they are peers.
- `_retVal` had come to mean two things: the single-threaded line outside the fork,
  and leg 1's result inside it. Now it means one thing — the line **before and after**
  the fork. Between them there are only `_conRetVal[n]`.

Two things fell out of it.

**The join was wrong.** It read
`_conRetVal[1] = ADVANCE AND _conRetVal[1] = ADVANCE` — leg 1 twice. It would have
committed the fork as soon as leg 1 finished, with leg 2 still running, which is the
one failure a join exists to prevent. Fixed to read leg 2.

**`M_RunSub` was hard-coding `Branch := 0`.** Spotted from the API surface: there was
no way to say which leg a composite step ran in. The right answer is not to add a
parameter — the framework already knows, because `M_Step` set `_branch` from the step
record. `M_RunSub` now passes `_branch`, so a sub-chain inherits the leg of the step
that runs it and publishes its rows there. Adding an argument would have re-created
exactly the defect that folding `M_Branch` into `M_Step` removed: a second place to
state the leg, free to drift out of step with the record. A240 is the live case — it
runs the load-position chain from leg 1, and those four steps now publish as leg 1.

Not covered by a test: the `M_RunSub` inheritance is a one-expression change, and
proving it in TcUnit would need a third probe type (an FB cannot contain itself, so a
leg cannot nest a leg of its own type). It is exercised by the press demo instead, and
is visible on the chart the moment the demo runs — the load-position rows appear
indented under leg 1 or they do not.

280 files clean in both profiles, archives well-formed, 178 HMI tests. As always the
XAE download is the first real check.

## 113. The flow chart belongs to the running mode (2026-08-04)

Tracing how `FB_PressDemoLoadPosition` appears on the §3.13 chart turned up a
boundary that was never drawn. Rows are **discovered** by visit (§6.5) — which is what
makes the chart free to author, and §106 was right about that — but discovery has no
end of its own. `SequenceStepCount` only ever grew, so after AUTO then HOME the
operator would be shown AUTO's rows and HOME's together, with only some of them live.

Worse, it was close to silent truncation. The three press mode chains hold 29 distinct
step numbers against `MAX_SEQUENCE_STEPS = 32`: three rows of headroom before
`_M_RecordSequenceStep` starts returning early and later steps stop appearing at all —
bounded, as designed, but invisible. Per mode the peak is 19.

`FB_UnitBase.OnModeChanged` now calls `_M_ResetSequenceRows()`. A mode is the right
boundary: within one mode a re-run keeps its rows, so `Visited` and `LastDuration`
stay meaningful across cycles, and a project writes nothing because the clear lands in
the base hook every override already calls `SUPER^` on first (§3.14.2). The clear is
bounded by the count actually in use rather than by `MAX_SEQUENCE_STEPS`, so a mode
change does not cost the whole 32-row table in one scan.

For the record, the answer to the question that started this: a sub-chain is
**integrated, not linked**. `M_RunSub` does not publish a row for the composite step —
in the demo N240 calls only `M_RunSub` — and the sub-chain is attached to the same
host, so its steps land in the same table at `BaseStepNo + n`: 240, 260, 280, 300,
appended in visit order exactly where the composite step runs. There is no second
chart and nothing to link. The branch is not looked up either: each row carries the
branch stamped by whichever chain instance published it, which is why `M_RunSub`
inheriting `_branch` (§112) was the whole fix.

280 files clean in both profiles, archives well-formed, 178 HMI tests, 42 linter
fixtures. The new `Sequence_rows_belong_to_the_active_mode` test has never executed —
the XAE download is its first run.

## 114. MAX_SEQUENCE_STEPS 32 -> 128, and why that forced a tiering decision (2026-08-04)

32 rows covered the demo and nothing else — a real station chain of a hundred-odd
steps is ordinary, and the overflow is **silent**: `_M_RecordSequenceStep` returns
early and the chart simply stops growing, with no diagnostic saying so.

Raising it is a two-sided cost, and it is worth knowing which side hurts:

| | 32 | 128 |
|---|---|---|
| PLC memory per Unit | 36 kB | 145 kB |
| Published OPC UA nodes per Unit | 544 | 2176 |

A row is 1156 bytes of which **98% is strings** — `StepName`, `AwaitingLabel`,
`AwaitsPath`, `ErrorSourcePath`, `WarningKey`, `WarningSourcePath`. If this ever needs
to go further, shortening those is the lever, not trimming fields.

The HMI widget was never the constraint: `ListView.builder` virtualizes, and the
mapper loops to the *published count*, not the array bound. **The wire was.**
`SequenceSteps` was un-tiered, i.e. cyclic, and 2176 nodes per Unit across a forest is
precisely what `opcua_field_tier.dart` already warns about for the rings ("at ~265
nodes each across a forest they dominate the fast read"). Quadrupling a cyclic payload
would have been shipping a scalability regression against §1.1 O4, which makes
published surface a first-class property. So `SequenceSteps` joined
`onDemandContainers`: read by targeted batch while the Sequence tab is open, never in
the cyclic snapshot.

That change had a trap in it. The tab's capability was
`sequenceViewEnabled && sequenceSteps.isNotEmpty` — and once the rows are on-demand
that deadlocks: no tab, so no read, so no rows, so no tab. It is now keyed on
`SequenceStepCount`, a leaf at the module root that stays live, along with
`SequenceViewEnabled` and the `CurrentStep*` pair. Two tests pin it: the capability
against a node with a count and no rows, and the tier classifier against both index
spellings plus the live root leaves.

The §113 mode reset matters more at this size, not less: it keeps a Unit's actual
usage near its longest single chain rather than the sum of every chain it has ever
run, and it bounds the clear loop by the count in use rather than by 128.

280 files clean in both profiles, 42 linter fixtures, `flutter analyze` clean, 179 HMI
tests. XAE download is still the first real check on the PLC side.

## 115. Splitting the flow-chart row by change frequency (2026-08-04)

The proposal was "publish the critical data by OPC UA and fetch the rest on demand by
mailbox". The instinct was right; two facts moved where the cut goes.

**Sorting the 1131 string bytes by how often they change** shows the obvious split is
the wrong one:

| | fields | bytes |
|---|---|---|
| static per row | `StepName`, `AwaitingLabel`, `AwaitsPath` | 498 |
| dynamic | `ErrorSourcePath`, `WarningKey`, `WarningSourcePath` | **633** |

"Static text on demand" would have left the larger half behind. But the dynamic
strings are **sparse** — one error at a time, and a message only until its step runs
again — so every row was reserving 633 bytes for a case that is almost always empty.
They belong in a side table, not on the row.

**And no new mailbox was needed.** Fraktal already has two on-demand paths: the
`onDemand` field tier (targeted batch read while a view is open) and §3.10.2
`M_AppendConfig`/`FB_ConfigPager`, whose stated job is serving static facets kept off
the cyclic tree. A third would have been O9 debt.

The result is three tables:

| part | mechanism | 128 rows |
|---|---|---|
| live scalars (`ST_SequenceStep`, 25 B) | on-demand array read | 3.1 kB |
| static text (`ST_SequenceStepText`, 323 B) | config manifest, `OPC.UA.DA := '0'` | 40.4 kB |
| notes (`ST_SequenceAnnotation`, 205 B × 16) | on-demand array read | 3.2 kB |

**47 kB per Unit, down from 145 kB**, and the cyclic-capable node count drops from
2176 to 1408.

Two details that made it work cleanly:

**The manifest publishes the text under the LIVE half's browse paths.**
`M_AppendConfig` emits `SequenceSteps/SequenceSteps[3]/StepName`, which
`_indexedAlternatives` already recognises, so `synthesizeManifestValues` lands it on
exactly the key the mapper was already reading. The HMI mapper needed **no change** for
the static half — one row structure, half of it live, half fetched once and cached.

**The row flag stays authoritative, not the note.** The note table is deliberately
small (16). If it fills, `_M_SequenceAnnotate` returns FALSE *after* the caller has
already set `ErrorActive`/`WarningActive`, so a full table costs the text and never the
mark. Deriving the mark from the note would have silently unmarked a real failure; there
is a test for exactly that.

Also folded in the free win: `AwaitsPath`, `ErrorSourcePath` and `WarningSourcePath`
were `STRING(255)` but are copied from `I_Module.Name`, backed by
`FB_ModuleBase._name : STRING(80)`. They are `STRING(80)` now — 175 bytes per field
that could never be used. That also makes the contract explicit: a drill-down link is a
*module path*, bounded by the module's own name.

282 files clean in both profiles, 42 linter fixtures, `flutter analyze` clean, 180 HMI
tests. The PLC half — the annotation table, the manifest export — has never executed;
the XAE download is its first run, and the first place the manifest path spelling gets
checked against a real TF6100 namespace.

## 116. Liveness per leg, history per row (2026-08-04)

The question was whether every step needs live data at all, or whether only the active
ones should be published and the HMI could assemble the rest. Sorting the eleven live
fields by whether a client could reconstruct them gave three groups, and the middle one
is the interesting one:

- **Four were never live at all.** `StepNo`, `Branch`, `TimeClass`, `ExpectedTime` are
  fixed from a step's first visit. Leaving them in the live array after §115 was an
  oversight; they joined the text in `ST_SequenceStepDef` (renamed from
  `ST_SequenceStepText`, since it is no longer only text).
- **Three can move, safely.** `Active`, `Elapsed`, `TimedOut` are only meaningful for a
  running step, and a leg runs exactly one at a time — so they became `ActiveSteps`, a
  cursor **indexed by branch**: ~10 entries however long the chain is. Small enough to
  be live tier, which is a UX gain as well as a saving: the chart is correct the instant
  its tab opens instead of after the first on-demand read.
- **Four must not move.** `Visited`, `LastDuration`, `ErrorActive`, `WarningActive` are
  per-row history. An HMI polls at a few Hz; the PLC steps at scan rate. A step shorter
  than one poll interval is never observed, so a client that accumulated these would
  silently skip exactly the fast steps, mistime visits, and lose a fault that raised and
  cleared between two reads. That is the difference between a chart showing what the
  chain **did** and one showing what somebody happened to catch — §1.1 O3 is diagnosable
  by construction, not by luck.

| | after §115 | now |
|---|---|---|
| PLC memory per Unit | 47 kB | 46 kB |
| leaves read while the tab is open | 1408 | **576** |
| leaves read cyclically | 0 | 30 (the cursor) |

The memory barely moved — that was never the problem. **Leaf count** was: reads here
are per-leaf sum-reads with batch handle resolution, and 1408 handles for one open tab
is real pressure on a finite pool. 576 is a 2.4x cut with nothing inferred client-side.

Two things fell out of moving the clock from the row to the leg. The per-scan sweep is
now ~10 iterations instead of up to 128, because it sweeps legs rather than rows. And
`LastDuration` is frozen by that sweep from the cursor's own elapsed, which is exactly
the value the HMI could not have measured.

A further ~2x is available by bit-packing the three row booleans into a flags byte
(~286 leaves). Not taken: the HMI would need to know bit positions, which breaks the
"binds to named fields, knows nothing about the module type" property §3.13 exists to
protect.

283 files clean in both profiles, 42 linter fixtures, `flutter analyze` clean, 181 HMI
tests. The PLC half has never executed; the XAE download is the first check, and the
first place the `ActiveSteps` index base (the cursor is `ARRAY[0..n]`, so the HMI probes
both zero- and one-based spellings through `_indexedPrefix`) gets confirmed against a
real TF6100 namespace.

## 117. Live channel state; the RS232 terminal joins the bus view (2026-08-04)

**Channel value promoted to live.** The whole `Topology` subtree was on-demand, which
also gated the one field an operator watches without opening the bus page: an
interlock that will not clear, a sensor that never comes on. `BoolValue` and
`AnalogValue` are now `liveLeaves`, checked BEFORE the container rules so a leaf can
outrank the on-demand subtree it sits in. One leaf per channel; `Address`, `Path`,
`Diagnostic`, `Forced`, `Quality` stay gated. Two existing suites asserted the old
contract and were updated rather than worked around — `opcua_repository_test` now uses
`Forced` as its on-demand exemplar, since the value it used to pick is live.

**The EL6001 was on the bus and invisible.** Checking the XTI export settled what is
physically there:

| slave | mapped before | now |
|---|---|---|
| `=000+S-K010 (EK1200)` coupler | node, no channels | unchanged — it has no process data |
| `=000+S-K010B1 (EL1809)` 16 DI | node + 15 channels | unchanged |
| `=000+S-K010C1 (EL2809)` 16 DO | node + 10 channels | unchanged |
| `=000+S-K010D1 (EL6001)` RS232 | **node, no channels** | node + 8 channels, process image mapped |
| `=000+S-K010E (EL9011)` end cap | node, no channels | unchanged — passive |

So the tree was not missing devices; the EL6001 was missing its *channels*, which is
the same thing from an operator's chair. Mapping it needed a Core addition: the
publisher could only express digital channels, while a serial terminal's process image
is bytes. `E_ChannelKind.ANALOG` already existed in `ST_IoChannel` — only the API was
absent — so `M_DefineAnalogChannel` / `M_SetAnalogValue` mirror the digital pair
exactly, same validation, differing only in `Kind` and the engineering unit.

The terminal belongs to no module (nothing speaks a protocol over it yet), so its
channels carry the Unit as `ModulePath`: the bus view still shows and forces them, and
cross-navigation lands somewhere honest rather than nowhere.

**Flagged, not guessed:** the `TcLinkTo` names are the EL6001's *default* 3-byte PDO
assignment (0x1A00/0x1600). The terminal also offers 5- and 22-byte variants, and the
XTI lists all of them as alternatives without making the active choice readable. If
XAE is set to another variant the link names differ and the build will say so — the
comment in `GVL_PressIO` says exactly this, in the same style as the existing warning
on the N54 button channels.

283 files clean in both profiles, archives well-formed, 182 HMI tests.

## 118. Misfiled types and speculative flags — and the rule that stops both (2026-08-04)

Two questions ("why is `ST_PneumaticPressOutCmd` inside a library?" and "what about
`ChangeoverCompleted`, only written, never read?") turned out to be one habit, so the
answer had to be a gate rather than a paragraph.

**The scan.** Two passes over the PLC tree: types a library declares that nothing in
that library uses, and struct fields written by the PLC that neither the PLC nor the
HMI reads. Both raw outputs needed judgment, and saying why is the useful part:

- *"Used only from outside" is not misfiling.* The first pass flagged
  `FB_CylinderSim`, `FB_TwoHandStartCM`, `FB_ClampStationUnit`, `FB_TcpVisionCM` and a
  dozen more — every one correct, because being used from outside is what a reusable
  type is *for*. The real signal is narrower: no object **owns** it, i.e. nothing in
  the Framework tree declares a member of that type.
- *`OutImm` fields with no named reader are not orphans.* The second pass flagged the
  whole of `ST_PneumaticPressOutImm`, but `OutImm` is by definition the published live
  facet: its consumer is the generic HMI tree, which renders what is published without
  naming fields in Dart. Deleting those would have removed the contract to satisfy a
  grep.

**The one real misfiling** was exactly the four `ST_PneumaticPress*` DUTs: in
`Fraktal_Modules`, owned by no library FB, referenced only by the press project — while
`ST_ClampStation*` sit correctly beside the `FB_ClampStationUnit` that declares them.
Moved to `01_PneumaticPress/DUTs/` in the project. Every consumer of the module library
stops carrying a press it does not have.

**Rule L1** now enforces it, and getting it right took three corrections that are worth
recording because each was a false positive with a different cause:

1. Ownership must include `REFERENCE TO` — that is how a CM owns its HAL struct
   (`ST_CylinderHal` and four siblings looked unowned).
2. It must include `ARRAY[..] OF` — that is how `ST_BusNode` owns `ST_IoChannel`
   (three correctly-placed Core types looked misfiled).
3. It must span the **whole Framework tree**, not one library — `ST_IoPointIdentity`
   lives in Core and is owned by Modules, which is correct layering, not a defect.

Three fixtures pin those boundaries so the rule cannot silently loosen back.

**On speculative flags.** `ChangeoverCompleted` is written by two chains and read by one
test assertion; nothing in the machine and nothing in the HMI consumes it. The standing
rule going into AGENTS.md: declare a flag when something needs it. A published field
with no consumer is not readiness, it is surface everyone pays for. (`CycleCompleted`
is the near miss that stays: two unit types write it, so it is a convention rather than
a one-off — but it has no reader either, and should get one or go.)

283 files clean in both profiles, 45 linter fixtures. The XAE gate remains red for
reasons predating this session (§119 note pending the error text).

## 119. The library compiles — and what a whole session of "unverified" was hiding (2026-08-05)

Every report in this session ended with "no PLC compiler in this environment; the XAE
download is the first real verification." That was an assumption I never checked, and
it was false: TwinCAT 3.1.4026 and `VisualStudio.DTE.18.0` are installed here and
`tools/Invoke-TwinCatBuild.ps1` runs. The cost of not checking was a session of work
built on a base that did not compile.

**What the compiler said, once §5.1 of the workflow doc made the Error List readable.**
The DTE2 qualification is the whole trick — a COM object from `VisualStudio.DTE.<n>` is
seen by PowerShell as base `EnvDTE.DTE`, whose `ToolWindows` probe returns nothing, which
is exactly the misleading empty result I hit three times and nearly concluded was a
tooling dead end. Through `DTE2`: **27 × `C0094: Interface of overridden method ...
doesn't match declaration`**, every one in `FB_SequenceBaseLd`.

That is precisely the risk flagged and left unresolved four times in this session:
*"FB_SequenceBaseLd re-declares inherited methods with an extra `Run` input, which is not
a signature-compatible override; if the compiler rejects them the fix is distinct names."*
It did reject them. Writing a risk down is not the same as retiring it.

**The fix, in three parts** — and parts two and three were only visible because each
compile pass revealed the next layer:

1. The facade methods are **not overrides**. A method that adds `Run : BOOL` for rung
   power flow is a different method that happens to delegate, so it takes its own name:
   `M_StepLd`, `M_AdvanceLd`, … 27 of them. `SUPER^.M_Step(...)` targets are untouched.
2. A method returns through **its own name**, so every body still assigning `M_Await :=`
   was now assigning to the inherited *method*, not the return variable — 34 ×
   `Cannot convert type 'BOOL' to type 'M_AWAIT'`. Retargeted, delegation calls excluded.
3. The ladder calls the facade by name, so `FB_LD_PressDemoAuto`'s `BoxType` operands
   follow (`M_StepLd`, `M_PartProcessedLd`, `M_CountGoodLd`), and rule S1 accepts either
   spelling with the reason recorded inline.

**Result: `CheckAllObjects = True`, 0 errors, 0 warnings — for both Fraktal_Core and
Fraktal_Modules.** Everything this session added to Core compiles: the raise/report API,
the message path, concurrent branches, the split flow-chart row with its cursor and
annotation tables, derived state flags, and the analog channel API. The `ST_PneumaticPress*`
removal is validated too — Modules compiles clean without them.

**Why nobody had seen it.** The gate asserted `BootProjectAutostart` is off and threw
*before* `CheckAllObjects` for `Fraktal_Core`. That assertion is a test-project rule — a
test app must not auto-start on a runtime — and a library is never downloaded, so it is
meaningless there. Applying it anyway meant **neither library was ever compiled by CI**,
and 27 errors sat in a library the gate reported on without ever checking. The gate now
skips the assertion for the two library solutions and includes them, in dependency order,
in its default list.

Still outstanding: `FraktalTests` and `PressTests` return FALSE because `Fraktal_Core`,
`Fraktal_Modules` and `TcUnit` are not in this machine's Library Repository. That is the
*Save as library and install* step the workflow doc describes and the automation
deliberately never performs, so the seven new TcUnit suites remain unexecuted — but they
are now the only thing between here and a real test run.

## 120. SFC step naming: N for steps, A for actions (2026-08-05)

The SFC chart's steps were renamed `A<n>` → **`N<n>`** (`A200` → `N200`, and the join
placeholders `_aA250_active` → `_aN250_active`); the action objects keep `A<n>_<What>`.

It is a small change that removes a real friction. `N` is already the step token
everywhere else in Fraktal — `M_Step(StepNo := 200)`, the `200:` label in the ST twin,
the `N200` row on the §3.13 chart, the `Step N200 stalled → …` first-out message. The
chart was the only surface calling it `A200`, so a reader tracing one step across the
chart, the code and the operator's screen had to translate at exactly the moment they
were already confused.

Keeping `A` on the *action* is the other half: in the archive a step and its
`MainAction` are separate objects bound by GUID, and `N200 → A200_RamDown` says which
is which without opening either. Same number, different prefix, no ambiguity.

Documented in the README's SFC build procedure and in AGENTS.md so a generated chart
follows it.

## 121. What it takes to write a ladder chain unaided (2026-08-05)

With N000/N100/N110/N999 drawn, the ladder vocabulary is complete and the procedure is
now written down in the README (§ "Writing a Ladder sequence rung by rung"). The two
rung shapes cover every step of every chain: pure logic, and command-a-child. A jump is
not a construct — it is a second `MOVE` under a different contact. A terminal step
completes and does not `MOVE`.

What made this hard to write earlier was not the drawing, it was three facts only the
compiler could settle, all now recorded:

- the facade methods are **not overrides** (`C0094`), so they carry `Ld` names;
- a method returns through **its own** name, so renaming one without retargeting the
  body's `<name> :=` silently rebinds it to the inherited method;
- a ladder box's `BoxType` must name the facade, not the base, or it has no `Run` pin.

**Why the remaining rungs are still not generated.** Two blockers, one of them mine:

1. `FB_LD_PressDemoAuto` reports two unresolved lazy-typed implicit variables
   (`ImpVar597_1`, `ImpVar616_1`) — editor-generated intermediates for rung results
   whose type cannot be inferred, i.e. a dangling or mistyped pin in an existing rung.
   Until the file compiles, a generated rung's errors cannot be told apart from the
   ones already there, and that is precisely the confusion that hides real defects.
2. The EL6001 `TcLinkTo` names were a guess and were wrong: XAE reports
   `TIIB[=000+S-K010D1 (EL6001)]^Inputs^Status` not found, so the terminal is on a
   different PDO assignment than the default 3-byte one. The links are **removed**
   rather than guessed a second time; the variables and their §10.5.1 topology channels
   stay, so the card is still published and visible, and the comment says exactly what
   to read off the Process Data tab to restore them. A wrong `TcLinkTo` fails the build
   loudly, which is the right failure mode and the reason not to leave a plausible one
   in place.

The demo now has a real oracle (Core and Modules are installed as libraries), so once
those two are cleared each generated rung can be `CheckAllObjects`-verified as it is
added, rather than twelve at once.

The implicit-variable diagnosis above is superseded by §122: the generated names do
identify the exact archive boxes, and the defect is nested method-return composition,
not an unlocatable editor variable.

## 122. LD implicit-variable audit: the generated name locates the graph defect (2026-08-05)

An archive-level audit of `FB_LD_PressDemoAuto` resolved the two names from §121
without opening the graphical editor. In this XAE archive the convention is
`ImpVar<BoxId>_<output ordinal>`:

- `ImpVar597_1` is output 1 (`BOOL`) of `M_AwaitLd` box ID `597`; that box is nested
  as an input of OR box `612`.
- `ImpVar616_1` is output 1 (`BOOL`) of `M_AwaitLd` box ID `616`; that box is nested
  into the `Run` input of outer `M_AwaitLd` box `614`.
- box `614` is then assigned to `_startReady` by assignment node `605`.

Therefore §121's “dangling or mistyped pin whose source cannot be inferred” was not
accurate. The names are generated by XAE, but the numeric stem maps directly to the
serialized `<v n="Id">…L</v>` node. Both outputs are connected and both descriptor
tables already say `BOOL`. What TwinCAT cannot type is the *nested method-return
temporary* created by the composed graph.

The graph is also behaviorally wrong compared with both authoritative renditions.
ST N100 and SFC action `A100_AwaitTwoHand` make three independent assignments:
`_partReady := M_Await(Idx := 1, …)`, `_airReady := M_Await(Idx := 2, …)`, and the
conditional `_startReady := M_Await(Idx := 3, …)`/`TRUE`; only afterwards do they
combine `_partReady AND _airReady AND _startReady`. The LD graph instead serializes
those calls inside one `_startReady` expression, uses an inner result as another
call's `Run`, and contains no assignment operand for `_partReady` or `_airReady`.
That can suppress later waits and their diagnostics when an earlier wait is false.

The correction rule is now explicit in the TwinCAT README and AGENTS.md: draw each
value-returning facade call as its own box with an explicitly typed result local;
combine only the locals in a later logic/transition branch. `Run` carries rung power
only. The graphical repair should still be performed in XAE because `<NWL>` is a
serialized editor graph, but no unknown XAE-generated variable must be guessed.

Validation caveat found during this audit: `PressDemo.slnx` could not be exercised by
the test-only hidden helper because its deployed PLC has `BootProjectAutostart=TRUE`,
which that helper intentionally rejects. `PressTests.slnx` is safe to check but does
not include `FB_LD_PressDemoAuto`; after the latest folder/type movement it also omits
the project-owned `ST_PneumaticPress*` DUTs and reason list, so its current check stops
with 136 cascading unknown-type errors. It is not an LD oracle until that manifest is
reconciled. The LD-specific evidence here is the reported two compiler names plus the
deterministic archive mapping above.

## 123. PressTests is green again — the DUT move had broken it (2026-08-05)

§122's validation caveat was a regression I introduced. Moving the four
`ST_PneumaticPress*` DUTs out of `Fraktal_Modules` (§118) fixed the layering, but
`PressTests.plcproj` compiles the demo **sources** directly and had been resolving
those types through the module library. With them gone from the library and not added
to its manifest, the check stopped with 136 cascading unknown-type errors — the
"oracle" was reporting my own manifest omission, not the ladder.

Fixed by listing the four DUTs plus `PL_PressReasons.TcGVL` (which `FB_PressDemoAuto`
now references) and the `DUTs` folder in `PressTests.plcproj`.

**Result: `CheckAllObjects = True`, 0 errors, 0 warnings.** That covers
`FB_PressDemoUnit`, all four ST chains, the release FB, the fieldbus GVL and both press
suites — so essentially every ST change this session is now compiler-verified: the
§6.9(d) raise, the §6.9(e) message and `M_ReportFromChild`, `Homed` moving to `OutImm`
via `_M_State`, the project reason band, the `M_Advance` default simplification, and
the DUT relocation itself.

Worth noting why lint did not catch it: rule P1 checks that authored sources under a
project root appear in that project's compile list. These DUTs live under the
`Fraktal_Press_Demo` root and are consumed by a *different* project, `PressTests`, and
no rule looks at cross-project source borrowing. That is a genuine gap — a second
project compiling another project's sources is exactly where a manifest drifts
silently — and is the obvious next lint rule.

## 124. M_MayIssue -> M_TryIssue (2026-08-05)

A question-shaped name on a call that consumes what it reports. `M_MayIssue` reads as a
predicate — ask twice, same answer — but when the gate opens it latches
`_driveIssued[_branch]`, so the second call in a step returns FALSE and the command
silently never issues. Command/Query Separation, and the kind of defect that survives
review because the call site reads correctly.

`Try*` is the established convention for attempt-and-report, and it matches the real
contract including the part that is easy to miss: a **closed** gate returns FALSE
*without* consuming, so retrying on the next scan is correct. It also restores the
imperative-verb convention every sibling follows (`M_Step`, `M_Await`, `M_Advance`,
`M_Delay`, `M_RunSub`, `M_Gate`) — `M_MayIssue` was the only interrogative, because it
was conceived as a predicate and implemented as a consuming operation.

`M_BeginCommand` was the runner-up and was rejected: `OnCommandStart` already exists on
the module base and means something else (the Unit's own command edge), and the
near-collision would have cost more than the clarity gained.

59 occurrences across the base, the `Ld` facade, the ST/SFC/LD renditions, the probes
and the specification. `Fraktal_Core` verifies green (`CheckAllObjects = True`).

**Consumers need the library re-installed.** `PressTests` compiles against the
*installed* `Fraktal_Core` (0.4.0.0), which still exports `M_MayIssue`, so it now
reports 30 errors until Core is rebuilt and re-installed via **Save as library and
install**. That is the documented dependency order, not a defect — but it is the first
time this session a Core API rename has been made, and it is worth recording that the
source-green/consumer-red window is expected and is closed by the install step.
## 125. The §3.13 flow chart never told the HMI it had changed (2026-08-07)

**Symptom.** The HMI's sequence view rendered every row as `N0` with an empty
drill-down, intermittently — sometimes correct, usually not.

**Cause.** A chart row is deliberately split in two: the LIVE half (`Visited`,
`LastDuration`, the error/message marks) publishes cyclically, and the STATIC
half (`StepNo`, `StepName`, `Branch`, `TimeClass`, `ExpectedTime`,
`AwaitingLabel`, `AwaitsPath`) is served once through the §3.10.2 manifest under
the same browse paths, so the mapper reads one row without knowing it arrived by
two routes. The HMI refetches that manifest only when `ConfigRev` changes.

`SequenceStepDef` rows, however, are discovered **by visit** — and neither
`_M_RecordSequenceStep` (append) nor `_M_ResetSequenceRows` (the mode-change
clear) bumped `ConfigRev`. Every other manifest contributor already did:
`RegisterAvailableModel`, `SetAccessLevel`, the recipe commit in `SetModel`. So
a chart that grew after the HMI's one-time fetch — which is every chart, since
the rows appear as the chain runs — rendered its new rows from defaults: step 0,
no text. `OnModeChanged` then made it permanent for that mode.

That the split is invisible to the mapper is the design working; that half of it
had no revision signal is the defect. **A published surface assembled from two
sources needs one revision that covers both.**

**Fix.** `ConfigRev := ConfigRev + 1` on append (only when a row is actually
added — a re-visit rewrites identical values) and on the mode-change clear
(guarded by `SequenceStepCount > 0`, so a mode change with nothing published
costs no refetch). The HMI's `_manifestFetchInFlight` guard coalesces the bumps
of a first pass into far fewer fetches than there are steps.

Core advances to `0.4.0.1`: a contract-neutral rebuild in the fourth component
(Part II §2.2). Nothing about the published types changed, but a fixed library
that still called itself `0.4.0.0` would be indistinguishable from the broken one
in the library repository. Pins in `Fraktal_Demo`, `PressTests` and
`Fraktal_Tests` move with it; Core must be rebuilt and re-installed, then Modules
resolved, before any application binds the fix.

## 126. A ladder rung agreed on every step and still dropped an effect (2026-08-07)

**Symptom.** Running the LD rendition of the press AUTO chain, releasing a
two-hand button before the slide finished retracting put the machine in a loop:
slide in, door down, abort, door up, slide out, repeat, indefinitely.

**Cause.** `FB_LD_PressDemoAuto` network 8 (step 190, the post-abort slide-out)
carried its `M_Step`, its `M_TryIssue`, the RETRACT command, the Reset of
`_partSlide.Execute` and `MOVE 100 -> _step` — everything its ST twin does
except `_startLatched := FALSE`. `_startLatched` is a `REFERENCE TO BOOL` shared
with the Unit, and N100's `M_Await(Ok := _startLatched)` is the only thing that
holds the cycle at the two-hand wait. Still latched, N100 fell straight through
and the chain ran the whole cycle again against a released button.

The ST and SFC renditions both write it in both places (steps 190 and 999); the
ladder wrote it only at 999.

**Why nothing caught it.** `check_consistency.py --checks parity` compared which
steps exist and where each one can go. Step 190 existed and went to 100 in both
renditions, so the chain was "at parity" while doing something materially
different. **Same steps and same transitions is not the same chain.**

**Fix.** The rung gains a Reset coil on `_startLatched`, generated with
`tools/ld_rung_gen.py` and gated by the same `EQ(_step,190) AND _partSlide.Done`
power that already resets `_partSlide.Execute` — tapping rail 197, which was
computed at the top of the rung, so it cannot be re-evaluated after the MOVE
below sets `_step := 100`.

The gate now compares **effects**, not just topology: for every step carried in
both languages, the shared state the ST branch assigns must be written by a coil
in the ladder rung. "Shared" is exactly the roots the ST twin declares
`REFERENCE TO` — a rendition's own scratch is excluded on purpose, because
`_partProcessed` in ST is `_processed` in ladder and naming scratch differently
is not a divergence. A PLAIN coil is exempt everywhere: it writes its rail's
value every scan, so it already drives the symbol FALSE in every other step and
the ST twin's explicit clears have no ladder counterpart to find. That exemption
is what keeps `_outCmd.CycleCompleted` from being reported. Run against the
pre-fix artifact the check reports exactly one error, naming step 190 and
`_startLatched`.
## 127. The fieldbus tree showed each card its neighbour's state (2026-08-07)

**Symptom.** On the press bench the EL6001 (`=000+S-K010D1`) read OFFLINE on the
HMI fieldbus tree while XAE showed the terminal present and the card was
operational.

**Cause — not the HMI, and not a stale boot configuration.** `FB_EcBusHealth`
mapped the master's slave list to topology nodes *by position*:
`node := _firstSlaveNode + i - 1`. That assumes the catalog and the master's
slave list are the same sequence. They are not.

The master enumerates only devices with an EtherCAT slave controller on the
process-data ring. The press bus is EK1200 coupler, EL1809, EL2809, EL6001,
EL9011 — five entries in the project tree and in the catalog, but the coupler
and the passive end cap have **no ESC**, so `FB_EcGetAllSlaveStates` returns
three. The `.xti` shows it plainly: those two boxes declare 0 PDOs, the other
three declare 16, 16 and 10.

Everything therefore shifted by one:

| master slot | really is | published onto |
|---|---|---|
| 1 | EL1809 | node 2 — the **coupler** |
| 2 | EL2809 | node 3 — the **EL1809** |
| 3 | EL6001 | node 4 — the **EL2809** |
| — | (nothing) | node 5 — EL6001 → OFFLINE |
| — | (nothing) | node 6 — EL9011 → OFFLINE |

So the EL6001's genuine OP state was being displayed on the EL2809's row. **A
wrong state on the right node is worse than no state: it is a plausible lie**,
and it is why the symptom looked like a single dead card rather than a
system-wide off-by-one.

**Fix.** The mapping is stated, not assumed. `FB_EcBusHealth` gains
`M_MapSlaveNode(SlaveIndex, NodeIndex)` — which topology node the master's
slave *i* actually is — and `M_MapPassiveNode(NodeIndex)` for catalogued
devices that carry the bus but are not enumerated. A passive node's state is
*inferred* (OPERATIONAL exactly when the read succeeded and at least one slave
answered), never invented: leaving it OFFLINE forever on a healthy bus is the
same class of lie in the other direction. `Setup`'s consecutive
`FirstSlaveNode`/`SlaveCount` form still fills the map and stays correct for a
bus where every catalogued node really is a slave.

`FB_PressIoDriver` now declares the truth: `SlaveCount := 3` starting at node 3,
three explicit slave mappings, and the coupler and end cap as passive.

**Not verified on hardware.** The press PLC was unavailable when this was
written. The diagnosis rests on the live probe capture taken while it *was*
reachable (`SlavesReported 3`, slots 4–5 returning `0x00` = no data) plus the
`.xti` PDO counts, and both agree. The runtime re-test is outstanding: with the
bus healthy, all six nodes should read OPERATIONAL and `CountMismatch` should be
FALSE.
## 128. The manifest threw away the type it knew (2026-08-08)

**Symptom.** Every row of the §3.13 sequence flow chart rendered as `N0` with an
empty drill-down. §125 fixed the *revision* half of this (the HMI never refetched
a chart that grew), but the rows stayed blank — so that fix was necessary and not
sufficient, and I reported it as complete too early.

**Cause.** A chart row is half live, half manifest. `FB_ConfigPager.M_Append`
stamps `ValueType := TEXT` on every entry, and `M_AppendNumber` — which knows
perfectly well it is writing a number — inherited it. The type was discarded at
the source, so the HMI had to guess from the leaf NAME against a hand-maintained
allowlist. `StepNo` was never in that list. The value crossed the wire as the
string `"100"`, the mapper's `_integer()` fell back to `0`, and the whole chart
became N0. `Branch`, `TimeClass` and `ExpectedTime` were silently wrong the same
way.

**A type the sender knows must never be re-derived by the receiver.**
`M_AppendNumber` now stamps `E_ConfigValueType.NUMBER` on the slot it just wrote,
using the `_storedSlot` mechanism `M_AppendCapability` already relies on. The HMI
consults the declared type first and keeps the name list only as a fallback for a
PLC built before this change — so an un-upgraded controller still renders, and a
new leaf can never silently stringify again.

Core advances to `0.4.0.2` (contract-neutral, Part II §2.2): no published type
changed, but a fixed library must be distinguishable from the broken one in the
repository.


## 129. Output forcing existed in the contract and nowhere in the code (2026-08-14)

**Symptom.** The HMI's fieldbus page had a complete force UI, `ST_IoChannel`
carried `Forced`/`Forceable`, `E_HmiRequestKind.FORCE_CHANNEL` was routed and
audited, and `FB_UnitBase.ForceChannel` proved access, mode and state. Then it
called `_M_RouteForceChannel`, whose base implementation is one line:
`_M_RouteForceChannel := FALSE;`. No Unit anywhere overrode it, and no project
ever called `M_SetForceable`, so `Forceable` was FALSE on every channel and the
whole path was unreachable. The feature was fully specified, fully plumbed, and
did nothing — the kind of gap a compile and a lint both pass over.

**What was missing was not the plumbing but the authority to turn it on.** Core
§10.5.1 says a force is gated by §7.6 and §7.7; it did not say the surface should
be *absent* from a production machine, only that it should be refused. Refusal is
not enough: a greyed control still tells an operator the machine can be forced,
and invites a call asking who can enable it.

**§7.5 now owns that.** Core §7.5 had three lines about a `COMM_FLAG`
commissioning constant, and no mechanism. It gains §7.5.1 (a gate is a build
constant, and the set of active gates is a published register) and §7.5.2 (while
any gate is active the station annunciates it, non-clearably). Forcing became the
framework's own first gate:

- `PL_FraktalEngineering.OUTPUT_FORCING`, selected by the `FRAKTAL_ENGINEERING`
  compiler define, gates the whole surface. A production build publishes
  `Forceable = FALSE` everywhere and the HMI draws nothing.
- `FB_EngineeringMode` is the register. It is write-once, and declaring a gate IS
  activating it: `M_Declare(..., Active := <the build constant>)` registers
  nothing when the constant is FALSE. `ST_EngineeringGate` therefore has no
  `Active` member, and a production station's register is genuinely empty rather
  than a list of things that are off.
- `FB_UnitBase.SetEngineeringMode` declares the framework's own force gate as a
  side effect, so a station cannot arm forcing without annunciating it, and a
  station that wires nothing simply cannot force (§1.1 O1, fail closed).

**The annunciation is deliberately the weakest alarm in the system.** LOW,
SYSTEM, `AUTO_RESET`. Every stronger choice is wrong for a specific reason:
`MANUAL_RESET` refuses `Start` (§8.3(b)), which would make commissioning gates
block the commissioning they exist to serve; a MED/HIGH severity would displace
real process alarms in the phase that produces the most of them; PROCESS or
SAFETY category would claim something about the machine that is not true. What
makes it non-clearable is not its strength but its shape: `OperatorReset` reaches
only `MANUAL_RESET` events, and the §8.9 record is `shelvable: false`, so neither
of the two operator actions that can silence an alarm applies to it.

**Two things had to move to make a force actually reach a terminal.** First, the
held set-point could not live in `ST_IoChannel.BoolValue`: the hardware driver
republishes that member every scan from the process image, so a set-point stored
there survives exactly one cycle, and clearing a force would freeze the last
forced value rather than restore the real one. `ForceBool`/`ForceAnalog` are
separate members for that reason. Second, the per-scan permit could not live in
the `FB_IoTopologyPublisher` instance: the press attaches *two* to the same table
(the catalog defines identity, the driver moves values), and two copies of that
flag would disagree about whether a force is live. `ST_FieldbusTopology.ForcesEnabled`
is in the published table, and `M_ApplyForces` derives its falling edge from the
flag itself, so every instance agrees and leaving idle MANUAL withdraws every
force on that scan — §10.5.1's "a force cannot survive into automatic operation",
enforced rather than assumed.

**The press bench's two existing commissioning gates are now annunciated.**
`USE_SIMULATION` and `CONTROL_CIRCUIT_MAPPING_CONFIRMED` have cost multiple
debugging sessions each (see §6.0 of AGENTS.md); they were documented in three
places and visible on the machine in none. They are declared into the register
from the same `VAR CONSTANT` values, so the machine now says so itself.

`_000K951_A1` and `_000K911_A1` are excluded from the forceable set even in a
commissioning image: they drive the hardwired N54 D2 Control On relay chain, and
energizing control power from a diagnostic screen is exactly the act this surface
must never offer (§10.5.1 rule 4).

Core advances to `0.5.0.0` — a MINOR bump (Part II §2.2). Everything here is
additive: new types (`FB_EngineeringMode`, `ST_EngineeringGate`,
`PL_FraktalEngineering`), new members (`ST_IoChannel.ForceBool`/`ForceAnalog`,
`ST_FieldbusTopology.ForcesEnabled`), new methods, and one appended `E_Reason`.
No existing member changed type or meaning and no `ST_*ParCfg` schema moved, so
there is no §3.8 migration due and every prior consumer compiles unchanged — but
an application still has to resolve the new library before it can see any of it,
which is what the first `CheckAllObjects` run after this change reported.


## 130. The interlock an operator reads was wired to a test hook (2026-08-14)

**Symptom.** None visible. `plc_lint` was clean, all five solutions compiled,
and the cylinder suites were green. The defect was found by reading Core §5.7
against the source rather than against the audit.

**What was there.** `FB_CylinderCM` and `FB_ConfigurableCylinderCM` each carried
a `SimForceInterlock` method. §5.7 is explicit that such a hook "shall exist only
under the SIM build configuration and be compiled out of release builds — every
§7/§9 reaction is testable, and the bypass can[not ship]". The only occurrences
of `{IF defined (SIM_HOOKS)}` in the Modules library were **two comments telling
a future reader to add the guard**. Every release build shipped the bypass.
`AGENTS.md` stated the opposite as settled fact.

**The worse half.** The hook was the *only writer* of `Intlk.Cond[1]` — the
condition both types publish to operators as "area safe". So a reusable type
declared an interlock that its application had **no way to supply** (§7.2.1: a
condition is owned at the lowest module with the context to name it, and the
application drives `Cond[i]`), and on `FB_ConfigurableCylinderCM` that was its
*only* interlock slot. The type advertised an area interlock and offered a test
back door in its place.

**Why guarding it would have been the wrong fix.** The obvious repair —
`{IF defined (SIM_HOOKS)}` — runs into the build topology: `Fraktal_Tests`
consumes the **installed** `Fraktal_Modules`, and an installed library's pragmas
are resolved when the library is built, not when the consumer is. Keeping T3
green would have meant two library flavours, a SIM one for the gate and a release
one for machines, and a change to the install workflow. That is a lot of
machinery to preserve a back door.

**What was done instead.** Both types now expose
`SetAreaSafe(Ok, DescriptionKey)` — the same shape as the existing
`SetDirectionalPermits`: an application-supplied condition, a method rather than
an OPC UA write, re-evaluated every scan so a manual command obeys it too, and
defaulting TRUE so a station that declares no area interlock is not gated by one.
`SimForceInterlock` and its `_force` member are deleted. The T3 rows in
`FB_CylinderCM_Tests` and `FB_ClampEM_Tests` drive `SetAreaSafe`, which is
strictly better evidence: they now exercise the surface a station actually uses.
No define, no second library flavour, no workflow change.

The `Intlk.Define` default also moved from `project.interlock.areaSafe` to
`std.interlock.areaSafe`. A library type owning a `project.*` key was backwards;
an application overrides the text through `SetAreaSafe` when its own condition is
more specific.

**Lint rule C8** now rejects an unguarded `Sim*` method in `Framework/` code, so
the shape cannot return. Its fixtures assert all four cases that matter: the
exact method that shipped fires, a properly guarded one does not, and neither a
whole simulation *driver* type nor a test project is touched.

Modules advances to `0.4.0.0` — removing a public method is a contract-surface
change (§1.5), and a consumer that called the hook must be told by its resolver
rather than by a compile error it cannot explain.

**The general lesson, which is why this is worth a note.** A test that reaches
for a back door stops testing the product. Both suites were green for months
while proving something about `SimForceInterlock` and nothing about the interlock
path a station uses — and the missing application path went unnoticed precisely
*because* the test had a way in that the application did not.

## 131. The validation ladder that would have made the robot unhomeable (2026-08-24)

`FB_RobotCM` (Annex I §I.4) landed with the §5.6 rule applied faithfully: validate
the request, then the state, then command motion. Motion requires a valid position
reference, so the ladder refused any motion command while `Referenced` was false.

`HOME` was in the set of motion commands.

Homing is what *establishes* the reference. Gating it on one means the robot can
never be homed: unreferenced, so `HOME` is refused; refused, so still
unreferenced. The cell would have arrived on site with an arm that could not be
started, and the reason code would have told the technician "motion before
homing" — the truth, and completely useless.

The annex already had this right. §I.4's referenced check lists `MOVE_TO`,
`RUN_PATH`, `RUN_PALLET`, `MOVE_TEMPLATE`, `MOVE_FROM_AREA` and deliberately not
`HOME`; the implementation collapsed that list into a single "is this motion?"
helper and lost the distinction. **Reading the spec's set as a set, rather than as
an example of a category, was the whole difference.** The fix restores it, and
`Home_is_exempt_from_the_reference_check` now holds it in place — the one test
that asserts a command *is not* refused for a specific reason.

**The compiler found three more, all of them the same kind of mistake:** assuming
a base member was ours to declare, or that a property behaved like a field.

- `_step` is `PROTECTED` in `FB_ModuleBase` and set to 10 on the accepted Execute
  edge. Re-declaring it in the CM is a C0097 collision. `FB_AxisCM` never declares
  it — that was the signal, and it was there to be read.
- `_conn.LastResult.ReasonCode` is a component access on a *function result*
  (C0185): `LastResult` is a property. Third occurrence of this trap in this
  repo; it is now in `AGENTS.md`.
- `ARRAY[E_RobotOpMode] OF REAL` does not compile (C0006). An array bound is a
  range. The annex carried the same illegal declaration, so §I.4 has been
  corrected too — spec text that cannot compile is worse than none, because it is
  copied with confidence.

**`FB_SimRobotConnector` is the reason any of this is testable.** §I.5c is
normative about it and states why in one line: for a robot the simulation seam is
the *connector*, not the HAL. Eight CM tests drive it — including a protective
stop and a lost permissive mid-move — and none of them needs an arm, an emulator
or a socket. The reasons of §I.2 are exactly the ones that cannot be proven
against real hardware without deliberately breaking a cell, which is why the
ability to inject them is part of the connector contract rather than a test
fixture.

## 132. Jogging to a position nothing could keep (2026-08-24)

The axis teach jog went in first: hold an enabling device, move the axis by
hand, let go. Then the obvious question — *does the position it reached
actually get saved?* — turned out to have a five-part answer, and every part
was "no".

1. **§3.8c teach capture had no implementation at all.** Zero call sites, zero
   mechanism. The only trace in the repo was a comment in `ST_RobotGeometry`
   claiming its pose cells are "filled by teach capture (§3.8c)" — describing a
   thing that did not exist.
2. **`FB_AxisCM` registered no editable values whatsoever.** The whole
   `M_RegisterConfigWrite` registry had exactly one user, and it was
   `FB_ProbeConfigCM` — a test fixture.
3. **There was no taught-position field** anywhere on the axis to write into.
4. **`ParCfg` would have been the wrong home even so.** `I_RecipeProvider` has
   `Load` and no `Store`, so a taught number parked there is overwritten by the
   next changeover. Machine geometry is not recipe data.
5. **The durability layer §3.8b specifies is entirely unbuilt.**
   `PersistPending`, `PersistFailed`, `E_ConfigRestorePolicy`, and named
   parameter sets (save/load/list) are all zero implementations.

Capture is now built, and built the way that makes the dangerous case
impossible rather than merely forbidden: **the capture source lives on the same
record as the write it targets.** `M_RegisterCapture` refuses a key that is not
already registered as editable, so §3.8c(a)'s "a capture reaches only an
already-editable field" cannot be violated by a caller — there is nowhere to
put a source that has no field. The capture then resolves its live value to
text and rejoins `M_ApplyConfigWrite`, so revision, the type's invariant hook,
range, domain and storage are literally the same code a typed write runs. A
capture cannot accept what a typed write would refuse, because it *is* one.

**The lesson worth keeping is about half-features.** Jog without capture is a
control that moves a machine and remembers nothing — worse than no jog, because
it looks finished. The feature was not "jog"; it was "teach", and jog is one of
its two halves. Asking what the feature is *for* found the missing half in one
question, and no amount of testing the jog would have.

**Still missing, and named rather than quietly left:** durability is a stated
property in §3.8b — an accepted write shall reach non-volatile storage within a
bounded window and the root shall publish whether it has. Today the taught value
is retained by `VAR PERSISTENT` and nothing more. A station cannot save its
parametrization to a file, carry it to another machine, or warn an operator that
an accepted write has not become durable. Also worth flagging: §3.8b forbids
"a byte image ... one aggregate structure memory-copied in and out", and
`FB_LocalStationConfig.Load` is a `MEMCPY` of exactly that shape. It predates the
clause and now contradicts it.


## 133. Configuration that survives a restart, and says so when it did not (2026-08-25)

§3.8c gave the axis a taught position. §3.8b is the clause that decides whether
that number is still there tomorrow, and it had **zero implementation**:
`PersistPending`, `PersistFailed`, `E_ConfigRestorePolicy`, `SaveConfigSet`,
`LoadConfigSet` and `ListConfigSets` returned no hits anywhere in the repository.
A station could accept a value, publish it, retain it in `VAR PERSISTENT` — and
lose it at the next power cut with nobody told, because nothing ever asked the
runtime to write the retentive image out.

### What the clause actually demands, and what each demand cost

**"Storage stays distributed; the root is the authority, not the store."** A
parameter set is *a projection produced by the same deterministic walk that
builds the §3.10.2 manifest*. The cheap implementation is a second walk that
collects values into a set. That is also the wrong one: two enumerations of
"what this station's configuration consists of" drift the first time a module
registers a value, and then a set silently stops containing something (§1.1 O9).

So the set save is not a walk at all. `FB_ConfigPager` — the object the manifest
already pages through — gained a **record sink**. `M_SetupSetSave` puts it in
record mode, the ordinary `M_AppendConfig` walk runs completely unchanged, and
every capability it emits is offered to the store. No exporter knows which mode
it is feeding and none can be written to feed only one of them. The suite asserts
the consequence directly: the saved record count equals the number of writable
`STATION_CFG` capabilities the manifest publishes, counted by walking the
manifest the way a client does.

**"A byte image shall not be used."** The interface is record-oriented
(`I_ConfigStore` moves `(Scope, WriteKey, ValueType, value)`), because a
document- or blob-oriented store interface would reintroduce exactly the
prohibited property one level up: no per-value identity, and no way to reject one
bad value without rejecting all of them.

**"Durability is a stated property, not a hope."** On TwinCAT the persistent
image is written by the runtime, normally at a controlled shutdown, so every
configuration write since the last one is lost to a power cut. That is the
failure the clause exists to replace — and replacing it needs an explicit act
with a latency and a failure mode, not a comment. `FB_PersistentDataWriter`
(`I_ConfigPersistence`, `SPDM_2PASS`, the runtime's **own** `_AppInfo.AdsPort`
rather than a hard-coded 851) is the shipped LOCAL_RETAIN default and is used
with no wiring at all, so a conforming station persists its parametrization with
no file system, no network, and no project code. The root marks every accepted
write pending, drives the provider each scan, and holds the declared window to
account: exceeding it publishes `PersistFailed` rather than waiting quietly.

**"Restore is fail-closed and never silent."** `FB_ModuleBase.M_RestoreStationCfg`
writes the rule once: version 0 is a first boot that lost nothing and initializes
**silently**; any other unrecognized version means a real image was rejected and
is reported for the root to annunciate **with the owning module's canonical
path**. `FB_AxisCM` had a hand-written copy of this and it was subtly wrong in
two ways — it treated both cases identically at the CM in one branch, and it
resolved a loss by **faulting the module**, which forced the strictest possible
consequence on every station that ever instantiated an axis. The consequence is
the deployment's declaration (`E_ConfigRestorePolicy`), never the module's; the
axis lost twelve lines and gained the right behaviour.

### Three decisions worth recording

**1. `FB_LocalStationConfig` was deleted, not fenced off.** Its `Load`/`Store` are
`MEMCPY` of a whole aggregate keyed by name **and size** — so two different
structures of equal size pass its check — which is precisely the byte image
§3.8b forbids. It predated the clause. It had **no caller anywhere**: one
declaration in the CoreDemo `MAIN` that nothing ever touched. Keeping a shipped
type of the forbidden shape only invites its use, and "documented as
discouraged" is not a property a compiler enforces. `I_StationConfig` went with
it, since its only implementer was that type.

**2. An unmatched record ABORTS the load.** §3.8b says records whose capability no
longer exists are "reported, never silently dropped" and, separately, that "one
rejection aborts the whole load". The permissive reading — report it and apply
the rest — produces a machine restored to *almost* its commissioned state, which
is the failure mode hardest to notice and the one all-or-nothing exists to
prevent. So an unknown `(Scope, WriteKey)` fails staging like any other record
and the refusal names it.

**3. A model set can be SAVED and cannot be LOADED, and that is deliberate.**
§3.8b requires a `PAR_CFG` set to be applied through the §3.8 changeover
transaction — `PrepareRecipe` → recursive readiness → infallible `CommitRecipe`
— "never as a sequence of per-field writes". Replaying its records through
`M_ApplyConfigWrite` is exactly that forbidden sequence. Building the supported
path needs `I_RecipeProvider` to gain a `Store` it does not have, which is its
own design decision. So the load is **refused, naming the model**, and the gap
is named here rather than filled with the version the clause prohibits.

### `AXIS_TEACH_LOST` (10207) was retired

It said the same thing as the new framework code `CONFIG_RESTORE_LOST` (2040),
one band down, for one module type. §8.8's own rule is that a generic code plus
`SourcePath` renders instance-specific — *"Loc130.PartFeed: configuration lost"*
— so a per-type duplicate of a framework fact is the duplication O9 forbids. Its
rationalization was more pointed (HIGH/PROCESS, "re-teach the axis position"),
and that is a real trade: the generic entry cannot say "re-teach". The answer
§3.8b actually provides for "this station's lost values are dangerous" is
`BLOCK_UNTIL_ACKNOWLEDGED`, which refuses `START_STOP` outright — a stronger
guarantee than a louder alarm, and the press bench declares it.

### The press: what moved, and what deliberately did not

The bench registered **no** editable configuration of its own. It now carries
`ST_PneumaticPressStationCfg`, and one member was **taken out of the recipe**:

- `RequireTwoHandStart` → `STATION_CFG`. It was recipe data in name only — all
  four catalog records set it `TRUE` — and §3.8a's test is whether the value
  changes with the model. It does not; it answers whether this *cell's* risk
  assessment demands a two-hand start. A model recipe able to switch it off
  would let a changeover quietly remove a required operator protection.
- `TransferSettleTime` **stayed** in `ParCfg`. Its catalog values genuinely
  differ per model (80/100/120/150 ms) — a heavier steel blank settles on the
  slide more slowly than a plastic one. That is a fact about the part.
- `StallGuardMs` is new `STATION_CFG` and is **derived** into `StallTime` every
  scan rather than latched at Setup, so an edited guard takes effect on the next
  step and the published value can never disagree with its configuration.

The move touched all three AUTO renditions. The ladder edit was a **leaf operand
substitution only** — no node id, no wiring, no box type — and `ld_dump.py`
confirmed all four operands retyped as `BOOL` with their `NEG` flags and ids
intact, because a clean compile does not prove a generated node still exists.

### Proven, and not

`plc_lint` clean in both profiles, `check_consistency --strict` clean, all five
TwinCAT solutions pass `CheckAllObjects`, and 166 tests / 39 suites build. The
**runtime TcUnit gate has not been run** — those counts are derived from source,
not from a green runner, and no evidence record exists for this work. Nothing
here is claimed to have executed on a PLC.


## 134. The direct ADS client read the whole program, not the contract (2026-08-26)

Switching the press Unit HOME → AUTO took about ten seconds to settle. Other mode
changes did not. The obvious suspect was the §3.13 flow chart — AUTO has 15
distinct steps against HOME's 2, rows are discovered by visit, and each newly
appended row bumped `ConfigRev`, so entering AUTO charged roughly sixteen full
paged manifest refetches where HOME charged three. §133's predecessor commit
coalesced those bumps in the PLC (`_M_ChartRevCyclic`). The operator reported no
improvement.

### What the measurement actually said, and why it was misleading

A probe reported a 2.7 s cyclic snapshot over 21,585 symbols, and that number
was used to conclude the transport was saturated. Two things were wrong with it.

**The probe measured a client nobody ships.** `probe_map_cost` and
`probe_symbol_weight` connect an `AdsSessionClient` and call `snapshot()`.
`OpcUaRepository` does not: it classifies the discovered contract through
`opcua_field_tier.dart` and pushes an excluded set to the transport before it
ever polls. The probes never called `setExcludedPaths`, so they read every
discovered leaf and reported a cyclic cost several times the real one. That
over-report is not conservative — it points the next fix at subtrees the HMI
already skips. The worked example is the headline item: `MAIN.PartCarrier.Produced`
at 17.0% of the snapshot is 16 × `ST_PartResult` = 16 × 229 = 3,664 leaves, of
which the `Records` sub-arrays (16 × 32 × 7 = 3,584, **97.8%**) were already
on-demand. The "biggest single lever" was already pulled. Both probes now apply
the real tiers through `tool/probe_read_tiers.dart`.

**A snapshot cost is mode-independent.** It is the same work in HOME as in AUTO,
so it cannot explain an asymmetry between them. Whatever made AUTO slow had to
be the mode-dependent term, which is the manifest refetch count — not the
snapshot size. The snapshot still mattered, but as the *multiplier* every
refetch competes with, never as the cause.

### The defect the correct measurement exposes

TF6100 TMC-Filtered publication starts at the instances explicitly marked
`{attribute 'OPC.UA.DA' := '1'}` — the deployed root Units — and their inherited
children. In the press demo's `MAIN` that is `PneumaticPress`, and nothing else.

ADS has no such filter. `SYM_UPLOAD` exposes the entire program, and the bridge
scoped discovery with `name.rfind("MAIN.", 0) == 0` — *everything* under MAIN. So
the direct client read, every cycle, the composition root's private instances:
the part carrier and its result ring, the I/O driver and its `_busHealth`, the
recipe catalogue, the config store, the access provider, the HAL structs, the
simulation controls. None of it is in the published contract, no widget reads it,
and over OPC UA it does not exist. The same blindness covered every member the
framework marks `OPC.UA.DA := '0'`: `Nameplate` and `Catalog` on **every**
module, `_configWrite` (12 × 18 = 216 leaves per module, also on every module),
`AlarmLog/Meta`, `ModePolicy`, `AvailableModels`, and `SequenceStepDef` — 128
rows × 7 fields = **896 leaves per Unit**, read at 4 Hz, named by nothing in the
HMI. The mapper reads the *live* `SequenceSteps/…` paths, which is exactly where
`M_AppendConfig` re-serves those same static fields.

That is the honest form of the question "should the ADS transport honour
`OPC.UA.DA := '0'`". The answer is yes, and the reason is stronger than
performance: **a transport that shows a different address space from the one the
contract publishes is not a second view of the same machine.** Anything the HMI
came to rely on there would work over ADS and vanish over OPC UA.

### What was changed, and where the rule lives

The rule belongs in the HMI's existing single classifier, not in a second copy
of the PLC's declarations:

- `OpcUaFieldTier.isOutsidePublishedRoots` — a path under a program container
  that owns a discovered root, but outside every root, is off-contract. The
  containers are **derived from the discovered roots**, not matched against the
  name `MAIN`, so it holds for any program name and for a peer forest (§3.1a).
  With no roots discovered yet nothing is outside them, because the first
  snapshot is how the roots become known.
- `OpcUaFieldTier.isManifestServed` — the **container** half of the config tier,
  every entry checked against `M_AppendConfig` to confirm the manifest re-serves
  the identical browse path. The **leaf** half deliberately stays cyclic: that
  list is a heuristic that also catches `Status/Name` and the `SupportedModes`
  capability, and excluding those emptied the module tree and the mode dropdown
  once already. A container name is unambiguous; a leaf name is not.

Discovery still enumerates the excluded leaves, so they stay writable by path —
which is what `MAIN.FieldbusViewActive`, the §10.5.1 demand gate, needs.

Over OPC UA and the gateway this is a **no-op**: those paths are unpublished, so
they never reach the classifier. It changes the direct ADS client only, which is
the transport that had diverged.

### The refetch storm, and the part of it that is not fixed

Two client-side guards, neither of which needs a PLC download:

- A refetch now waits for the published `ConfigRev` signature to hold still
  (`_configRevSettle`, 750 ms) before it is charged. The first hydration is
  exempt — there is no manifest to coalesce and delaying it would delay the
  first complete tree. The PLC coalesces too, but the HMI cannot assume the
  library in front of it does.
- The cyclic poll **no longer stands down for a refetch**. It yielded for any
  manifest fetch, which is right for the initial hydration (no tree to keep
  alive) and wrong for a refetch: the operator is already looking at a live
  screen, and freezing it for the duration is what made a mode change read as a
  hang rather than a lag.

**Not fixed, and worth stating plainly.** A newly discovered chart row genuinely
needs the manifest, because that is where its `StepName` lives — so a chain that
discovers 15 steps over a production cycle still charges refetches spread across
it. The settle window bounds a *burst* (mode entry clears and re-records rows in
one scan); it cannot coalesce rows that appear seconds apart. Making that cheap
needs an incremental or scope-limited `QUERY_CONFIG`, which is a protocol change,
not a tuning change.

**The next measurable lever, deliberately not taken here.**
`AdsSessionClient.writeBatch` is a `for` loop of single writes — ten sequential
round trips per mailbox request, paid by every operator command and by every
manifest page. The bridge already sum-writes (`kSumWrite`, used for handle
release), so batching is structurally available. It was left alone because it
carries the §6.1 commit contract — `Sequence` is written **last** on purpose —
and whether an ADS sum-write preserves sub-command ordering is a question about
the runtime, not about this code. It should be answered against hardware before
the write path changes.

### Proven, and not

`flutter analyze` clean; 268 HMI tests pass, 4 skip, and the 2 failures
(`cycle_gantt_test.dart` §8.11.4(c) guard ink, `opcua_snapshot_mapper_test.dart`
facet hydration) were verified to fail **identically at `HEAD`** by stashing this
work and re-running them. `plc_lint` clean in both profiles,
`check_consistency --strict` clean. No PLC source changed, so the library-install
and `CheckAllObjects` gates were not applicable and were not run.

**Nothing here was measured against a PLC.** The controller became unavailable
before a baseline could be taken — the one probe that did run failed at
`SYM_UPLOADINFO2` with ADS `1861` (client sync timeout) on the symbol upload
itself, which also means it was never confirmed whether the running controller
carries the PLC-side coalescing at all. Every quantity above is derived from
source arithmetic (array bounds × struct members, cross-checked against the
probe's own per-subtree counts, which it reproduces exactly for `Produced` = 3,664
and `SequenceStepDef` = 896). The expected reduction in cyclic leaves is
therefore **predicted, not observed**, and the before/after the task asked for is
still owed. `probe_read_tiers.dart` exists so that when the PLC returns, one run
of `probe_map_cost` reports what the HMI actually polls rather than what an
unconfigured client would.

## 135. A module says what TYPE it is, not only what it is called (2026-09-27)

`LOCALIZATION_AND_MODULE_CONTENT.md` §7 authors a faceplate against a module
**type**, and §7.1 says a type is a key in the catalog vocabulary. Nothing
published answered "what type is this?": `Status.ModuleType` separates a Unit
from an EM from a CM and stops there, and the press publishes `Door`,
`PartSlide` and `PressRam` as three instances of one declared cylinder.

The binding already half did it. Every reusable type set a type-scoped display
key (`std.moduleType.cylinder.name`) while an application module set an
instance-scoped one (`project.module.clampStation.name`), so the type/instance
split existed in the key namespace — overloaded onto `DisplayNameKey`, where
nothing could read it as a type without guessing at the prefix.

**What changed.** `ST_ModuleStatus` gains `TypeKey : STRING(160)` after
`DescriptionKey`, and `FB_ModuleBase._M_SetPresentation` gains a `TypeKey` input
assigned beside the two existing ones. No new call path: the key is set through
the call every concrete type already makes. All eleven call sites carry it in
the same change, because the pinned 4024 compiler requires every method input
at every call:

| Call site | `TypeKey` |
|---|---|
| `FB_AirPressureMonitorCM` | `std.moduleType.airPressure` |
| `FB_AxisCM` | `std.moduleType.axis` |
| `FB_ClampEM` | `std.moduleType.clamp` |
| `FB_ConfigurableCylinderCM` | `std.moduleType.configurableCylinder` |
| `FB_CylinderCM` | `std.moduleType.cylinder` |
| `FB_DigitalInputCM` | `std.moduleType.digitalInput` |
| `FB_PowerGroupCM` | `std.moduleType.powerGroup` |
| `FB_SeparatorCM` | `std.moduleType.separator` |
| `FB_TwoHandStartCM` | `std.moduleType.twoHand` |
| `FB_ClampStationUnit` | `project.moduleType.clampStation` |
| `FB_PressDemoUnit` | `project.moduleType.pneumaticPress` |

A type key has no `.name` suffix — that suffix belongs to the display key, and
§7.1 makes the type key an identifier first and a display key second. The
namespace follows the display key it sits beside: a type whose name the standard
owns takes `std.`, one the project owns takes `project.` (§1). `FB_ClampStationUnit`
lives in `Fraktal_Modules` but has always named itself with a `project.` key, so
its type key follows that rather than inventing a second ownership rule here.

`FB_DigitalInputCM` is the case the member exists for. Its display name is an
instance input — the press passes `project.module.partPresentSensor.name` — and
its type key is a literal, because every digital input is the same type whatever
it is called. `FB_InputCM_Tests` now asserts both halves of that: the display key
is the instance's, the type key is the type's. They are assertions added to the
existing test, not a new `TEST`, so the documented suite/test counts are unchanged.

A module that sets no type key publishes `''`. §7.1 makes the empty case fall back
to the coarse `ModuleType` scope, so no default is invented and none is derived
from the FB name: `FB_RobotCM` never called `_M_SetPresentation` and still does not.

**Version.** An additive member on a released type is a MINOR step (Part II §2.2).
Core moves `0.6.0.0 -> 0.7.0.0`. Modules also moves `0.6.0.0 -> 0.7.0.0`: ten of
its types changed a call, and a Modules 0.6 compiled against Core 0.6 cannot
resolve against Core 0.7's `_M_SetPresentation`. `Fraktal_Demo`, `PressTests` and
`Fraktal_Tests` re-pin both; `Fraktal_Press_Demo` resolves `*`.

The eleven new keys each have an English catalogue entry, and the three types
that already carried Spanish names (`airPressure`, `separator`, `axis`) have
Spanish ones, or `check_consistency` would report them unlocalized and the
operator would read a raw key.

**Deliberately not here.** The Allen-Bradley declaration/manifest/projection and
the HMI mapper and faceplate resolution are the other halves of the same
contract and are being done on another host (`TC3_TYPE_KEY_HANDOVER_PROMPT.md`).
The read-surface gate will refuse an HMI read of `Status/TypeKey` that the AB
projection does not publish, which is the cross-check that the halves agree.
`HMI_CONTRACT.md` is not amended yet for the same reason: it is the table the HMI
*implements*, and today the HMI does not read this member.

**Gates.** `plc_lint` clean in both profiles (360 files); the TwinCAT tool suite
75 tests OK; `Invoke-TwinCatLibraryInstall.ps1` installed Core 0.7.0.0 then Modules
0.7.0.0 after a clean `CheckAllObjects`; `Invoke-TwinCatBuild.ps1` passed all five
solutions, each `Compile complete -- 0 errors, 0 warnings` (the one Error List row,
on `FraktalTests`, is the benign "Unknown TMC file version" notice of the XAE
workflow §9.1); `check_consistency --strict` 0/0; its 27 tests OK.

**The Core/Modules gate was blocked by a stack overflow that predates this change;
it now runs, and is red identically with and without it.** On the local UmRT
(`192.168.1.6.1.1:851`, `-Interactive`) `Fraktal_Tests` first stopped on
`0xc00000fd` stack overflow in `PlcTask` moments after Start. The same gate from a
clean worktree of `46efbc2` against Core/Modules `0.6.0.0` overflowed identically,
and its download build names the cause:

    C0297: Possible Stack Overflow. Stack Size Usage for '...FB_ConfigSet_Tests.
    Set_operations_need_a_store_and_the_CONFIG_SET_gate': 332192 of 49152

That method declared a whole `FB_ProbeConfigUnit` as a method local, which lives on
the task stack - §56's failure mode again. It is now a suite member (`_bare`), set
up once behind a guard because `Setup` registers a config value and a child and a
persistent instance must not repeat that every scan. No other POU declares an FB
by value in a method's stack sections. `CheckAllObjects` does not report C0297 -
only the download build does - which is how it passed every object-check gate
since §133 (`e157b0a`, 2026-08-25). The last runtime record was 2026-08-24, so the
166/39 inventory had never executed.

With the fix: `PRG_TcUnitRunner`, **166 tests / 39 suites, 154 passed, 12 failed**.
`FB_InputCM_Tests`, including the new `TypeKey` assertions, passes. The same gate
from `46efbc2` + only the stack fix, against `0.6.0.0`, fails **the same 12 tests**,
so none is this change. They are all §3.8b/jog work that first ran today:
`ConfigSetTests` 8 (the first assertion to fail is "a station set saves" -
`SaveConfigSet` refuses, and the rest of the suite depends on a saved set),
`ConfigDurabilityTests` 3, `AxisJogTests.A_safety_fault_withdraws_the_permission` 1.
Each is owed an investigation of its own.

**The press gate ran and is red, identically before and after.** `PressTests` on
the same runtime: `PRG_PressTestRunner`, 8 tests / 2 suites, **6 passed, 2
failed** - `Start_release_enforces_operating_air` ("project release component
exposes the cleared named condition") and `Auto_cycle_returns_to_load_position`
("AUTO cycle records a good part"). The same gate from a clean worktree of
`46efbc2` against Core/Modules `0.6.0.0` failed the same two tests with the same
messages, so neither is this change. The last green press record is 2026-08-02;
both failures are owed an investigation of their own.

## 136. What the Core suite found the first time it ran (2026-09-27)

Once the stack overflow was gone (§135) the 166/39 inventory executed for the
first time, on the local UmRT, and was red: 154/166. The failures clustered in
§3.8b and the jog permission - the work of 08-24/25 that had only ever been
object-checked. Read over ADS from the stopped PLC rather than guessed at, they
were three product defects and four test defects.

### Product defects (Core 0.7.0.0 -> 0.7.0.1, contract-neutral)

**`CONFIG_SET` was refused by construction.** `CONFIG_SET := 11` was appended to
`E_GatedAction` and `ST_AccessPolicy.Required` widened to `[0..11]`, but both range
guards in `FB_AccessManager` (`Permits`, `ConfigureRequired`) still capped the gate
at `POWER_CONTROL`. Every set save, load and import was denied on every station -
failing closed, so it looked like a permission rather than a bug - and an ADMIN
could not even configure the level. `FB_UnitBase`'s HMI write path had been moved
to `CONFIG_SET`; the manager had not. Both guards now name the last member.

**`BLOCK_UNTIL_ACKNOWLEDGED` blocked nothing.** `SetConfigRestorePolicy` stored the
policy and `ST_ConfigPersistStatus` published it, and nothing read it - although
`_M_DrainRestoreLoss` says it is "evaluated in ReleaseReportStart", and the
catalogue ships `std.release.configRestoreUnacknowledged` for exactly that refusal.
The press bench's `MAIN` declares this policy, so the press started on defaults
after losing its commissioning. `ReleaseReportStart` now adds that reason (reason
`CONFIG_RESTORE_LOST`, kind `ALARM`) while a loss is unacknowledged under that
policy.

**A faulted safety facet still granted jog.** `F_ManualEnable` returned from inside
the device loop as soon as an enabling device read as held, so the facet-level
`Safety.FaultActive` check after the loop ran only when nothing was held - never
in the one case its comment was written for. The fault is now part of the held
condition itself.

### Test defects

* **`_M_TakeLoss` blanked what it took.** `Path => _path` is written on every call,
  including the terminating one that returns FALSE, so the helper overwrote the
  loss it had just captured. It now takes into locals and keeps only a success.
* **The window test measured time inside one scan.** `TIME()` does not advance
  within a scan, so three `_u()` calls always saw 0 ms and a 0 ms window never
  elapsed. The Core is right (the window fails on the next scan); the test now
  spans scans, bounded at 50. The suite's other seven tests are unguarded and
  would re-arm the window every scan, so they run exactly once.
* **A login is a request.** `RequestLogin`/`RequestLogout` queue; `Access.Cyclic`
  applies them on the Unit's next call. The test acknowledged at the previous
  level, so its "refused below ENGINEER" assertion passed for the wrong reason and
  its "ENGINEER may accept" assertion could not pass. Each request is now
  followed by `_u()`.
* **Seven set names against four slots.** `MAX_CONFIG_SETS` is 4 and the store
  never evicts; the four deliberately wrong imports now share the name `imported`.

### Still red, and why it is not fixed here

With the product fixes and the first three test fixes: **160/166**. The login fix
compiles but has not yet run. Five `ConfigSetTests` still fail, and the cause is
not in any one test: `FB_LocalConfigStore` keeps its sets in `VAR PERSISTENT`,
which survives a download, so each run starts with the previous run's sets
(`tainted`, `fromolder` were still there) and the suite's result depends on run
history. There is no delete on `I_ConfigStore`, and a test cannot zero an FB that
carries an interface pointer. Isolating the suite needs an API decision - a
clear/delete on the store, which an operator also needs the day a station has
saved four names - and that is not a call to make inside a fix.

`PressTests` stays 6/8 for a different reason: since `fcafae9` (2026-08-12) the
bench selects `RELEASE_LANGUAGE` and `AUTO_SEQUENCE_LANGUAGE` = LADDER_DIAGRAM,
after the last green press run (08-02). With LD selected the published ST
`ReleaseConditions` is never evaluated - its own comment says so - and
`Start_release_enforces_operating_air` asserts on it, so its "cleared" assertion
cannot pass. `Auto_cycle_returns_to_load_position` has not been diagnosed; the LD
chain is the first suspect. Whether the gate tests the selected rendition or the
gate selects ST is the project's decision.

## 137. A set can be deleted, and the press publishes and runs its Ladder correctly (2026-09-27)

### Parameter sets can be deleted (Core 0.8.0.0)

`I_ConfigStore` had save, read and list and no delete, so a store that had held
`MAX_CONFIG_SETS` names could only ever overwrite one of them again: a new product's
recipe could not be kept without destroying an old one under its name. It is also why
the set suite depended on run history (§136) - the store is `PERSISTENT`, and nothing
could empty it.

`I_ConfigStore.M_Delete(SetName)` frees the slot; `FB_LocalConfigStore` refuses when
the name is absent or a save into that slot is open, so a transaction is never pulled
from under itself. `FB_UnitBase.DeleteConfigSet` is gated exactly like save and load
(`CONFIG_SET`, a wired store, the root `READY`), marks persistence pending, refreshes
the published listing, and is audited with the set name. The mailbox gains
`DELETE_CONFIG_SET := 35`, appended; the HMI transport enum and the AB mailbox carry
the ordinal in the same change (both are pinned to the DUT), and AB refuses it as it
refuses every set operation. An interface method is a contract change, so Core takes
a minor step, 0.7.0.1 -> 0.8.0.0; Modules is unchanged.

`FB_ConfigSet_Tests` now empties the store through that delete before it runs, and
`A_deleted_set_is_gone_and_frees_its_slot` proves the rest: deleted and unreadable,
a second delete refused, persistence pending, and every freed slot usable (167 tests).

### The press publishes the release conditions of the rendition that runs

`FB_PressDemoUnit` published `ReleaseConditions : FB_PressDemoRelease` (ST) while
`RELEASE_LANGUAGE` selected the private LD rendition, so every named condition a
client browsed sat at its initial FALSE - its own comment called it "a bench
limitation". The two renditions also declared the same outputs word for word.

That block now lives once, in `FB_PressDemoReleaseState`, which both renditions
EXTEND (LD operands resolve by name, so no rung changed). Neither instance is
published; the selected one copies its conditions into `ReleaseConditions :
ST_PressDemoReleaseConditions` every scan straight after it evaluated. The browse path
`ReleaseConditions/ModeStartAirPressureOk` is unchanged and now true; the `ModeStart`
permit record is no longer browsable under it, which nothing read.

### Two defects in the LD AUTO chain the bench runs

`Auto_cycle_returns_to_load_position` had failed since the bench selected LD
(`fcafae9`, 2026-08-12). The same suite with `AUTO_SEQUENCE_LANGUAGE` temporarily set
to ST passed 8/8, which located both in `FB_LD_PressDemoAuto`:

* **`N999` counted good parts on the inverted condition.** ST reads
  `IF NOT _partProcessed THEN M_CountGood()` - with no traceability carrier
  `M_PartProcessed` returns FALSE and the chain counts directly. The rung enabled
  `M_CountGood` on `_processed`, so a station without a carrier never counted a good
  part and its OEE quality stayed at zero. The enable is now `NOT _processed AND NOT
  _partDispositioned`, the ST condition exactly; the `_processed` contact is negated
  and a negated `_partDispositioned` contact added, shaped on box 1066 of the same rung.
* **The ram never returned up.** With a zero dwell `N200`..`N240` ran in one scan, so
  `N240`'s load-position sub-chain Set the ram's `Execute` in the scan `N200` Reset it.
  The ram never saw `Execute` low, kept reporting the extend's `Done`, and the
  sub-chain took that as retracted - the cycle completed with the ram down. This is the
  rung-order trap the README documents for `N180`/`N185`; the ram pair was missed. The
  `N240` network now sits above `N200` (moved whole with `split_networks`/`rebuild`,
  no network contents changed). `FB_PressDemoUnit` still selects LD.

### Runtime

Local UmRT `192.168.1.6.1.1:851`, `-Interactive`, Core 0.8.0.0 / Modules 0.7.0.0:
`PRG_TcUnitRunner` **167/167** across 39 suites and `PRG_PressTestRunner` **8/8**
across 2 suites, both validated by `tcunit_to_junit.py`. The first fully green run of
either gate since 2026-08-24 and 2026-08-02 respectively
(`Specification/Evidence/2026-09-27_Core_Press_TcUnit.md`).

## 138. Data classes and raise-only per-value access (Core §3.8d, 2026-09-27)

§7.7 gated every editable value with one pair of actions, `DATA_READ`/`DATA_WRITE`,
so a station could not guard its commissioning values at ENGINEER and still let an
OPERATOR adjust a preset. §3.8d adds an access axis orthogonal to `ConfigKind`: a
root declares **data classes**, each with its own read and write level, and a value
may raise - never lower - its class's level. Core 0.8.0.0 -> **0.9.0.0** (a new
interface method, new manifest fields, a new request kind); Modules is unchanged.

**Where each fact lives.**

* The **module** states what it knows: `M_SetConfigAccess(WriteKey, ClassId,
  MinReadLevel, MinWriteLevel)` on an already-registered value, stored on the same
  `ST_ConfigWriteDef` row as everything else about it. Public on purpose: a
  composition root may put a *library* value into one of the *project's* classes,
  which a library cannot know.
* The **root** owns the policy: `M_DeclareDataClass` at Setup and
  `SetDataClassLevel` (gated `ACCESS_POLICY`, request `SET_CLASS_LEVEL := 36`).
  Declared levels are defaults - a class already in the table keeps the levels a
  deployment edited, so declaring on every boot never undoes a policy change.
* `FB_AccessManager.M_DataLevel` is the **one** place an effective level is computed:
  the class level (the built-in class `''` uses `DATA_READ`/`DATA_WRITE`), raised by
  the value's minimum. An undeclared class or a corrupt level fails closed at ADMIN,
  so a typo in a class id locks a value down instead of opening it.

**The class table is a separate persistent variable, not new members of
`ST_AccessPolicy`.** The policy is `VAR PERSISTENT`; changing its layout would make
TwinCAT reinitialize it on the next download, and a locked-down station would come
back fully open without anyone being told. A new variable starts empty and touches
nothing that exists.

**Enforcement.** The root resolves the level through a new recursive query,
`I_ConfigSource.M_ConfigAccessOf` (the same walk and "first owner answers" rule as
the write), and checks it before `WriteConfig`, `CaptureConfig`, every record of a
set load (in the staging pass, so nothing moves), and every record line of an export.
`WriteConfig`'s blanket `DATA_WRITE` check is gone; for a value in the built-in class
the result is identical. A refusal is audited (`std.audit.dataAccessDenied`).

**Manifest.** `ST_ConfigEntry` gains `ClassId`, the effective `ReadLevel` and
`WriteLevel`, and `Readable`. The root hands the pager its access manager before a
QUERY_CONFIG walk (`M_SetAccess`); a capability's levels are computed once, *before*
its value is placed, so a class readable below `DATA_READ` shows its value and an
unreadable one is listed without it. QUERY_CONFIG therefore no longer refuses a
session below `DATA_READ` outright - plain entries are blanked at `DATA_READ`
instead - because a public class must be visible to exactly the operator it exists
for. A set save still receives real values: saving reveals nothing outside the PLC.

**Tests.** `FB_DataClass_Tests` (7): built-in class unchanged; a public class open to
an OPERATOR; a raised minimum refuses the class's own level; an undeclared class is
ADMIN-only; re-declaring keeps an edited level; the manifest publishes effective
levels and hides an unreadable value; and a set load needs the write level of every
record. The last one first asserted that an ENGINEER could load the set - and the
PLC refused, naming `probe.label`, the fixture value in the undeclared class. The
rule was right and the expectation wrong; the test now asserts that refusal and an
ADMIN load.

Runtime (local UmRT): `PRG_TcUnitRunner` **174/174** across 40 suites.

**Specified, not yet implemented.** §3.8e (line data, one owner and mirrors) and
§8.5.2 (shifts and per-shift statistics) are in Core Part I with this change; no code
implements them yet.

## 139. Line data: one owner, read-only mirrors (Core §3.8e, 2026-09-27)

Station data describes one station and model data one product; the shift calendar,
a line takt or the line's host identity describe the LINE and are shared by every
station on it. Held per station they drift the first time one is edited and its
neighbour is not. §3.8e gives them their own `ConfigKind` (`LINE_CFG := 2`) and one
authoritative copy. Core 0.9.0.0 -> **0.10.0.0**.

**`FB_LineData` is an ordinary control module**, registered under one root Unit,
with the four-structure contract (`OutImm` *is* `ST_LineStatus`; the staleness window
is `ParCfg.StaleAfterMs`). A project registers its line values on it with the usual
`M_RegisterConfig*` calls and `Kind := LINE_CFG`, so line values are edited, audited
and access-classed (§3.8d) exactly like any other value - no second write path.

* **OWNER** - every accepted write raises a persistent `Revision` (never 0 once
  published) and the whole line is republished as `Image : ST_LineImage` on the scan
  after, rebuilt only when the revision moved.
* **MIRROR** - polls an `I_LineSource` every scan. A new revision is applied **whole
  or not at all**: the image must carry exactly the line values this copy registered,
  every record is staged through its owning typed handler, and only then are all
  applied - the §3.8b set-load discipline. A wrong `LineId` (error 1) or a line that
  is not applicable whole (error 2) applies nothing. Its values are published with
  `Writable := FALSE` and every client write, capture or staged set record is refused,
  through one new protected hook, `FB_ModuleBase._M_ConfigReadOnly`, that the base's
  write, staging and manifest paths consult. `_applied` is deliberately not
  persistent: every boot re-applies the owner's line once, because the persistent
  revision says only what was applied, not that the values behind it survived.
* **Staleness** is published (`Stale`, `LastUpdate` with its clock quality,
  `SourceError`) and annunciated as a LOW/SYSTEM `AUTO_RESET` event
  (`std.error.lineDataStale`) that closes itself on recovery. It never blocks
  production on its own (§3.8e(d)).

**Sources.** `FB_LineLocalSource` reads an owner on the same controller directly.
`FB_LineAdsSource` reads an owner on another TwinCAT controller by symbol name
(`ADSRDWRT`, index group `SYM_VALBYNAME`) - one request in flight, no symbol handle,
so a mirror polling for years never touches the owner's handle pool (the same
reason Read-TcUnitResults.ps1 reads by name, TWINCAT_XAE_WORKFLOW §9.1). Both controllers must run the same Core:
the image is read as the bytes of one `ST_LineImage` layout.

`_M_ConfigValueText` moves from PRIVATE to PROTECTED so the line module can render
its own registry into the image; nothing else changed visibility.

**Tests.** `FB_LineData_Tests` (6), with every unit run every scan at the top of the
suite so a mirror polls exactly as on a station: the owner's revision rises and the
line is republished; a mirror applies it whole through its typed handler and names
its owner; a mirror refuses a direct write; a mirror carrying a value the owner does
not applies nothing - not even the value both share; a mirror whose source fails goes
`Stale` and recovers by itself; and a mirror fed by `FB_LineAdsSource` over real ADS
on this runtime reaches the owner's revision and value (read back from the stopped
PLC: revision 2, owner `Test.LineOwner.Line`, value 1200, no error).

Runtime (local UmRT): `PRG_TcUnitRunner` **180/180** across 41 suites on the first
run; `PRG_PressTestRunner` 8/8.

**Not yet.** Nothing on the press is line data yet, and §8.5.2 (the shift calendar
as the first line data, and per-shift records) is next.

## 140. Shifts close themselves, on time, into a bounded history (Core §8.5.2, 2026-09-27)

§8.5.1 said counters and OEE reset "typically at shift start" from a deployment's
scheduler, so every deployment wrote one, the reset landed whenever it ran, and the
figures of the shift that just ended were gone the moment it did. Core 0.10.0.0 ->
**0.11.0.0**.

**The calendar is line data** (§3.8e): `FB_LineData.Calendar : ST_ShiftCalendar`,
registered identically on owner and mirror, so it is edited once and mirrored whole.
It is deliberately five values - one start per shift (`-1` = unused, `MAX_SHIFTS` = 4)
and one UTC offset - because a module registers at most `MAX_CONFIG_WRITES` (12)
values and a calendar with used-flags and editable names would have taken 13, leaving
the project nothing. A shift is named by its index, which the front end localizes, so
no operator text lives in PLC values (LOCALIZATION §1). §8.5.2(a) now says exactly
this. The synchronized clock (`F_Now`) is **UTC**, so the calendar carries the line's
offset; daylight saving is set, never guessed.

`M_CurrentShift(MinuteOfDay)` is the latest used start at or before the minute, and
before the day's first start the day's last shift - a night shift wraps midnight, and
the calendar has no gaps by construction. `M_MinuteOfDay(Now)` applies the offset,
normalized for a negative one.

**Every root that references a line closes its own shift.** `SetLine(pLine)` attaches
it; `FB_UnitBase.OnCyclic` calls `M_ShiftTick(F_Now(), F_TimeSynchronized())` every
scan beside the OEE accounting. On a boundary `_M_CloseShift` records the ending shift
into `ShiftHistory[1..MAX_SHIFT_HISTORY]` (newest first, `Truncated` on overflow) with
its counts, OEE buckets and factors exactly as they stood, then resets the per-shift
counts and OEE accumulators (the trend ring is kept) - one operation in one scan -
and audits it come+gone, so an `I_EventSink` receives every shift. A boundary on an
unsynchronized clock still closes and the record says so; a `ResetOee` mid-shift marks
that shift's record `ManualReset`. `M_ShiftTick` is public so a test drives the SAME
code across a boundary with a synthetic time instead of waiting for one; a Unit with
no line does no shift accounting at all.

**Two tool defects found on the way.**

* `plc_lint`'s reserved-word list lacked the date/time keywords. A local named `tod`
  (`TIME_OF_DAY`'s short form) desynced the parser into 47 errors, none naming the
  word. `tod`, `time_of_day`, `date`, `date_and_time` are now reserved in the lint.
* `test_ld_rung_gen` regenerates press AUTO `N999` from a declaration and compares it
  node for node with the file; the declaration still carried the inverted
  `M_CountGood` enable fixed in §137, so two tool tests had failed since that commit
  (the hook runs them only when a tool changes). The declaration now matches the
  corrected rung - and reproduces the hand-grafted node flag for flag.
* The TcUnit result harvest raced TcUnit itself: `AllTestSuitesFinished` rises before
  the results table is collected, collection spans several cycles, and the gate then
  stopped the PLC - so with 186 tests the harvest read 0/0 and so did every re-read.
  `Read-TcUnitResults.ps1` (which the gate calls) now waits for the table on the same
  deadline. This run's results were recovered by letting the stopped test application
  run 15 s more before reading; the application was not re-downloaded.

**Tests.** `FB_Shift_Tests` (6): the calendar and its midnight wrap and offsets; a
boundary closes the shift with its figures and restarts the counts; an unsynchronized
boundary is recorded as such; a manual reset marks one shift only; the history is
bounded and newest first; no line, no accounting.

Runtime (local UmRT): `PRG_TcUnitRunner` **186/186** across 42 suites and
`PRG_PressTestRunner` 8/8, both validated by `tcunit_to_junit.py`.

**Not yet.** No HMI renders the current shift or `ShiftHistory`, edits the calendar,
or groups line data; that is the HMI phase.

## 141. The set listing and export lines were unreachable; the HMI now has a sets dialog (2026-09-27)

`ConfigSets`, `ConfigSetCount`, `ConfigSetDocument`, `ConfigSetDocumentLine` and
`ConfigSetDocumentLines` were all marked `{attribute 'OPC.UA.DA' := '0'}`, with the
comment "off the cyclic tree: it is catalog data a client fetches when a set dialog
opens". But DA := '0' takes a symbol out of the OPC UA address space entirely, so a
client could send LIST_CONFIG_SETS or EXPORT_CONFIG_SET and never read the answer:
§3.8b's list and export were unusable over the transport every HMI uses. The
attribute is removed and the intent kept where it belongs - in the client: the HMI
classifies all five as `FieldTier.onDemand`, so they are target-read right after the
acknowledgement and never ride in the cyclic snapshot. Publication only, no logic;
Core 0.11.0.0 -> **0.12.0.0** because the published contract grew.

The HMI had none of the set operations wired - the request kinds existed only as
ordinals. `PlcRepository` gains list/save/load/delete/export/import and the PLC's
last refusal reason (`ConfigPersist.LastRejectScope/Key`); `OpcUaRepository`
implements them as request-then-targeted-read, `ScopedPlcRepository` root-checks
them, and `SimRepository` keeps a bounded in-memory store so the dialog works without
a controller. The dialog (from the configuration editor, for the owning root) saves a
station, model or line set, loads and deletes with confirmation, exports as copyable
JSON lines, and imports pasted ones; a refusal shows the record the PLC named.

**A contract limit, recorded rather than changed.** `ST_HmiRequest.TextValue` is
`STRING(255)`, but an exported line can reach 480 characters, so an import line longer
than 255 would be truncated and refused (fail-closed, but a long record cannot be
imported). Widening the request struct changes the mailbox layout the Allen-Bradley
binding pins byte for byte, so it is a deliberate contract step for later; until then
the HMI checks every line first and names the one that is too long
(`kConfigSetImportLineMax`).

Verified: all five solutions `CheckAllObjects` 0/0; flutter analyze clean, 324 tests
(8 new); check_consistency --strict 0/0. Not yet exercised against a live PLC over
OPC UA - the local runtime holds the test application.

## 142. A set line longer than one request comes back in pieces (Core 0.13.0.0, 2026-09-28)

§141 recorded a contract limit rather than changing it: `ST_HmiRequest.TextValue`
is `STRING(255)` but an exported set line can reach 480 characters, so a station's
own export could not always be imported again (objectives audit 2026-09-28, G1).

Widening `TextValue` would have changed the mailbox layout the Allen-Bradley binding
pins byte for byte, and capping export at 255 would have trapped a station's own data
inside it. The step taken is additive: `IMPORT_CONFIG_SET` with `IntValue = 1` holds
a piece (`_importPart`, `STRING(480)`, off the OPC UA tree), and the next import
request without that flag completes the line through the new public
`ImportConfigSetPiece`, which hands the joined line to `ImportConfigSetLine` unchanged.
The join is measured before it is made against the line's own declared width
(`SIZEOF`), so it is refused and the import aborted rather than truncated; any other
request kind in between discards a held piece. A root older than 0.13 reads a piece
as a whole line, fails to parse it and refuses it - fail-closed. AB refuses
`IMPORT_CONFIG_SET` altogether, so it is unaffected.

The HMI splits a line longer than 255 characters (`configSetLinePieces`) and still
refuses one longer than 480 by name. Test: `A_line_longer_than_a_request_imports_in_pieces`
imports a 330-character record in two pieces, reads its 70-character value and
140-character key back whole, and proves a join past 480 is refused. Core/Modules
runner: 187 tests / 42 suites.

## 143. Set lines past 255 characters were exported truncated; the codec no longer uses the standard string functions on a line (2026-09-28)

Found by the first runtime run of §142's test. `FB_ConfigSetJson` built each line with
`CONCAT` into a `STRING(480)`, measuring first with `LEN` in the belief that "CONCAT
truncates at the target width". On TwinCAT 3.1.4026.24 it does not: `CONCAT` cuts at
**255** whatever the target, and `LEN` reports at most **255**. Both are measured, not
assumed: the test scanned a rendered 330-character record as exactly 255 bytes, and on
the corrected build `LEN` returned 255 for a 290-character line. `FIND` has the same
limit, so `_M_Field` could not have found a member placed past character 255 either.
Every set record whose line exceeded 255 characters had therefore been exported as
broken JSON since the export was written. That contradicts the codec's own rule,
"emitted or refused, never truncated", and Part II §3.8. Short records, the only ones
the earlier tests used, were unaffected, and no compile gate can see a value property.

The codec now owns the long-string mechanics in one place:
- `_M_Length` scans to the terminator, bounded by `LINE_MAX`.
- `_M_Put` / `_M_PutText` append byte by byte and refuse a whole append that would
  exceed `LINE_MAX`, leaving the line as it was.
- `M_Record` and `M_Header` are built with them.
- `_M_Field` finds a member by byte scan.
- `M_Join` is the public append the piece import uses. `ImportConfigSetPiece` calls it
  instead of `LEN`/`CONCAT`, so Core has exactly one implementation of a line longer
  than 255.

Standard string functions stay where every operand is provably under 255 characters:
field values, the member token, and number text.

Evidence: `Specification/Evidence/2026-09-28_Core_Press_TcUnit.md`, with Core/Modules
187/187 and Press 8/8. Anything else in Core that joins strings which can exceed 255
characters needs the same treatment. It is owed an audit (a lint rule could flag
`CONCAT`/`LEN`/`FIND` whose operand is declared wider than `STRING(255)`).

## 144. Units are codes, and a choice names its labels (Core 0.14.0.0, 2026-09-28)

An operator editing the press saw `TRUE`/`FALSE` and bare ordinals to type, and a unit
that was free text chosen at each call site (`'ms'`, `'min'`, `'mm'`). Three changes:

- **`E_EngUnit`** (append-only, `NONE := 0`, 33 units) replaces the free-text unit on
  registration. `M_RegisterConfigWrite`/`M_RegisterConfigNumber` take `Unit : E_EngUnit`,
  so every number declares one (4024: every input at every call); durations are
  `MILLISECOND`, flags and choices `NONE`. The published `ST_ConfigEntry` gains
  `UnitCode` and keeps `Unit` as text **derived** from the code by `F_EngUnitSymbol`,
  so a client that predates the code still shows a unit - one source, one projection.
  The HMI mirrors the ordinals in `EngUnit` (lint E1) and shows its own translated
  symbol, `std.unit.<name>`.
- **`EnumLabelKey`** names the catalog prefix that labels each `EnumDomain` value
  (`<key>.<value>`). New `M_RegisterConfigChoice` registers a fixed set in one call and
  refuses an empty domain. The Unit's mode-policy values now carry
  `std.enum.modeSwitchShield` / `std.enum.modeSwitchStyle`.
- The HMI edits a `BOOLEAN` as a checkbox and a choice as a translated dropdown; the
  unit follows the value.

The registration signature change is a compile error for any project still passing a
string - visible, not silent - hence the minor version. `ST_ConfigEntry` only grows.
Test: `Units_and_choices_publish_codes_and_labels` (Core/Modules runner: 188 / 42).

## 145. The line leaves the Unit tree (Core 0.15.0.0, 2026-09-28)

§139 made `FB_LineData` a control module registered as a child of one root, to reuse
the config write path. That contradicted §3.8e(a) three ways: a line is orthogonal to
the forest (no parent), it is no CM (no HAL, no commands), and with two roots on one
controller it hung under whichever registered it. The press demo, which copied the
probe, showed it as `PneumaticPress.Line`.

- **Where it lives.** The composition root declares the line beside the roots (the
  press: `MAIN.PressLine`), exactly as it declares a control domain. `FB_LineData` now
  extends `FB_ModuleBase` directly - only because the typed value registry lives there
  (`ModuleType` NONE, commands refused) - and is never `_M_Register`ed.
- **How a root reaches it.** `SetLine` is unchanged for a project. `FB_UnitBase`
  overrides the five `I_ConfigSource` walks (`M_ApplyConfigWrite`, `M_StageConfigWrite`,
  `M_ApplyCapture`, `M_ConfigAccessOf`, and `M_AppendConfig`): the subtree answers
  first, and a `line.*` key under the root's own scope that nobody owned goes to the
  line under the line's name. The manifest publishes the line's values under the
  root's scope with items prefixed `Line/`, so the HMI shows them in that root's
  Line data group with no HMI change. The base's capability loop became the protected
  `_M_AppendCapabilities(Pager, Scope, ItemPrefix)` for this.
- **Keys.** `M_RegisterConfigWrite` refuses a `LINE_CFG` key that does not begin
  `line.` and any other kind that does, so the root's keys and its line's cannot
  collide. The calendar keys became `line.shift.utcOffsetMin` / `line.shift.<n>.startMin`.
- **Who runs it.** A line is no child, so nothing ticked it. The first root to
  reference it hosts it (`FB_LineData.M_BindHost`, called by `SetLine`): it runs the
  line once per scan and lends its alarm log for the staleness event; later roots
  only reference it. `Setup` therefore lost `pAlarmLog`. Every referencing root bumps
  its `ConfigRev` when the line's revision moves (a mirror apply, or an edit through a
  peer root), so its manifest is re-read.

`Setup`'s signature and the calendar keys changed, hence the minor version. Test:
`A_line_is_no_child_and_its_keys_are_its_own` (Core/Modules runner: 189 / 42).

## 146. The principles sweep (Core 0.16.0.0, Modules 0.8.0.0, 2026-09-28)

The sweep recorded in `OBJECTIVES_AUDIT_2026-09-28.md` §8 found violations the per-clause
audit had not looked for. What changed, by finding:

- **P2 - one start predicate.** The press called `Start()` only when a part and air were
  present, so the release report was not the whole predicate and a refused two-hand press
  explained nothing. `Start()` is now asked unconditionally and its report names a
  refusal. What stays qualified is the start LATCH: a press counts only when the part and
  air the N100 wait also names are there, so a press made before loading cannot start the
  stroke when the part arrives.
- **P8 - air loss holds.** Air is restored by the process, not repaired. It is now each
  cylinder's own process condition (`SetAreaSafe`, the slot meant for it), so a cylinder
  that loses air mid-stroke HOLDS and resumes, and the Unit rolls the hold up by name. The
  Unit's hand-coded fault is gone. The recovery tests use a genuine defect instead (a
  power enable refused with the safety permit withdrawn); `Air_loss_mid_stroke_holds_and_resumes`
  is new (PressTests 9 / 2).
- **P9 - the base restarts chains.** `I_Sequence.M_Restart` (flow state + the chain's own
  `OnChainReset`) is driven by `FB_UnitBase` on first scan, mode change, abort and abort
  in error, which also clears a pending decision. Restart-vs-resume after a Start or a
  reset stays project policy (§6.9(d)), taken with `_M_RestartSequences()`. The press lost
  `_M_ResetModeSequences` and its chains' `M_Reset` methods (state moved to `OnChainReset`).
  Adding an interface method is the minor step.
- **P3/P14 - no application Unit in the library.** `FB_ClampStationUnit` and its four
  structs left `Fraktal_Modules` (0.8.0.0). CoreDemo now owns `FB_ClampCellUnit` with the
  chain `FB_ClampCellAuto`, in `00_System` / `01_ClampCell` folders, and has an XAE
  solution, so the build gate compiles it for the first time. The Unit-tier rows move to
  `FB_UnitTier_Tests` on the test probe `FB_ProbeClampRoot`.
- **P4/P5/P11 - key ownership.** Library types raise `std.*` keys only; vision cameras,
  code readers and robots publish type keys (`std.moduleType.visionCamera|codeReader|robot`,
  vendor profiles inheriting their category's); the press's `project.config.*` text moved
  from the standard catalogue to the project one, with Spanish.
- **P6/P7 - no copies, no logic in MAIN.** The press `OutImm` lost nine child facts copied
  under new names plus `ReadyForLoad` and `ActiveSettleTime`; the pushbutton-lamp condition
  is derived in the Unit (`TwoHandStartReady`) and `MAIN` only maps it.
- **P10** - one pair of `RECIPE_MAX_*` constants for the changeover check and the edit range.

## 147. The robot connector is a connector (Core 0.17.0.0, Modules 0.9.0.0, 2026-09-28)

Finding P12 of the principles sweep. `FB_StaubliVal3Connector` extended `FB_AsciiDeviceCM`,
a Control Module, while `FB_SimRobotConnector` extended `FB_DeviceConnectorBase`. So:
two bases for one role; swapping connectors changed the module tree, which Annex I I.5
says it must not; the Staubli type had no heartbeat or LinkTimeout (`Linked` meant
"socket open"), contrary to §3.15.2; its `LinkReason` always reported "link down", even
while linked; and nothing serviced it except a caller remembering to (§3.15.3).

- **`FB_AsciiLink` (Core, new).** Terminator framing, the one-outstanding-request rule, the
  receive bound and the response timeout, written once. Each tick returns an
  `E_AsciiLinkEvent`; it owns no open policy and raises nothing. `FB_AsciiDeviceCM` now
  composes it and keeps only its faults and bounded reconnect, with the same codes and
  behaviour as before.
- **`FB_StaubliVal3Connector` on `FB_DeviceConnectorBase`.** Session, heartbeat, loss after
  `LinkTimeout` and bounded reconnect with no self-resume are inherited. The heartbeat IS
  the status poll: STA every `ParCfg.StatusPeriod`, and any well-formed reply proves the
  controller alive, so a command in flight does not starve it. A command that times out
  or is refused lands in `LastResult`, which the robot CM already adopts verbatim.
  `Setup(Name, Chan, DevHost, DevPort)` became `SetupLink` (the base owns `Setup(Name)`).
  Its own command/output structs (`ST_StaubliConnOutCmd/OutImm/ParCmd`) are gone; what an
  operator needs is published by the robot CM.
- **`FB_RobotCM` services its connector every scan (§3.15.3),** and the reconnect service
  action of §3.15.4 is its command `RECONNECT` (appended to `E_RobotCommand`, with
  `ParCmd.AcknowledgeController`). It stays BUSY until the link is back and resumes
  nothing.

The connector tests now run across scans, because `Linked` comes up only after the first
answered heartbeat. The suite count is unchanged.

## 148. One published diagnostic per module (Core 0.18.0.0, Modules 0.10.0.0, 2026-09-28)

Audit P15. Every library module published its first-out twice: the base's
`Status.Diagnostic`, and a copy in its own `OutImm.Diagnostic`, written by hand in each
type's cyclic hook and usually in a `_M_PublishStatus` override that existed for nothing
else. The HMI streamed both in its live tier. Core §6.1/§6.9 named the `OutImm` one, but
nothing read it: the HMI binds `Status.Diagnostic` (HMI_CONTRACT), the Allen-Bradley
projection publishes only `Status/Diagnostic`, and the stall walk uses `GetFaultSummary`.

**`Status.Diagnostic` is the one**, on the objectives:
- **O9, one source.** The base computes it once. The `OutImm` field could only ever be a copy.
- **O1.** A copy every type must remember to write is the per-type glue O1 forbids. Making
  `OutImm` authoritative instead would have put that duty on every type.
- **O4.** Each module's diagnostic streamed twice in the HMI's live tier.
- **O2/O8.** `Status` is the structure every module has on every binding, which is why
  the generic HMI and the AB projection already read it and nothing else.

`OutImm` keeps only the type's derived facts (§3.12). The `Diagnostic` member left 13
`ST_*OutImm` structs (two Core, ten Modules, the press), the copies left 13 types, and 11
`_M_PublishStatus` overrides went with them. The domain status records
(`ST_ControlPowerStatus`, `ST_PowerGroupStatus`) keep theirs: they are not module
`OutImm`s, and the HMI's control-power card reads them. Core §6.1/§6.9 and Annexes A, B,
C and H now name `Status.Diagnostic`. The new lint rule **D2** rejects a `Diagnostic`
member in an `OutImm` and any write to `OutImm.Diagnostic`.

## 149. Model data is editable for every model (Core 0.19.0.0, 2026-09-28)

The HMI could edit model data only for the running model: the manifest walked live
`ParCfg`, and a value of model B existed only in B's recipe record. The press also kept
its own copy of the recipe-store write-back in the project (`SetRecipeCatalog`, an
`M_Store` on the catalog and a `MEMCMP` block in `OnCyclic`), which every station wanting
the same thing would have had to repeat (§1.1 O1).

- **The mailbox is unchanged.** The model travels in `HmiRequest.DurationMs`, which
  QUERY_CONFIG and WRITE_CONFIG did not use (0 = active, n = `AvailableModels[n]`).
  `ST_HmiRequest` keeps its byte layout, which the Allen-Bradley binding pins; AB ignores
  the field and serves the active model, and publishes no `ModelScoped`, so the HMI never
  sends it an index.
- **The redirection is generic, the buffer is the root's.** `FB_ModuleBase` knows a
  *model region* (`_M_SetModelRegion`) and, while a view is open, resolves each capability
  target through `_M_Target`: a target inside the region is moved to the same offset in
  the view. `_M_StoreConfigValue` and `_M_ConfigValueText` go through it, so every value
  type works unchanged. `FB_UnitBase` owns the one staging buffer
  (`MAX_MODEL_DATA_BYTES`, 1024), opens a view with `_M_OpenModelView` (the live region is
  copied first, then `Load` fills it), and saves back with `_M_SaveModelData`.
- **Saving is an optional provider capability, `I_RecipeStore.Save`.** It writes only an
  existing (model, key) record of the same size whose first UINT (`SchemaVersion`) matches
  — never creates, resizes or migrates. `FB_LocalRecipeProvider` implements it. The root
  finds it with `__QUERYINTERFACE`, which needs the source interface to extend
  `__System.IQueryInterface`, so `I_RecipeProvider` now does (as `I_Module` does); an
  implementer needs nothing more.
- **Only the root's own record is model-scoped.** `ST_ConfigEntry.ModelScoped` (appended)
  is set for a `PAR_CFG` capability whose target lies in the region. A child's `ParCfg` is
  resolved by the same changeover but not staged here: the buffer would have to hold every
  child's record at once.
- **READY does not gate another model.** `_M_RouteConfigWrite` treats an open view as
  ready: nothing that record holds is running.
- **The press glue is gone.** `M_RegisterModelData(ADR(ParCfg), SIZEOF(ParCfg),
  PRESS_RECIPE_KEY, Recipe)` in `Setup` replaces it; `OnCyclic` keeps only the OEE ideal
  cycle update.

`FB_ModelData_Tests` (4 tests) proves another model is served and edited in its own
record, an active edit reaches its record, an unknown model is refused, and station values
do not follow the model. Core/Modules: 193 tests / 43 suites.

## 150. Local PINs are kept only as salted hashes (Core 0.20.0.0, 2026-09-28)

A read-only ADS probe listed `FB_LocalAccessProvider._users` with every PIN in plain
text, and the press kept the same PINs as retained text in `GVL_PressCommissioning`
for the provider to re-register each boot. Core §7.7(c) already cleared the login
secret after each attempt; the table itself undid that.

- **The PIN is not stored.** `ST_UserRecord.Pin` became `Salt` (16 bytes, drawn per
  registration from the clock, a sequence and the user name) and `PinHash` (SHA-256 of
  salt and PIN, then `PIN_HASH_ROUNDS` = 256 rounds of SHA-256 of the previous digest
  and the salt; about a millisecond per login). The comparison ORs every byte
  difference, and an unknown user costs the same hash, so timing does not separate a
  wrong name from a wrong PIN.
- **The table is hidden.** `{attribute 'hide'}` takes `_users`/`_n` out of the ADS
  symbol table, and `OPC.UA.DA := '0'` out of OPC UA. For a four-digit PIN this is the
  control that matters: any hash of a four-digit PIN falls to an offline search. The
  hash is what keeps a memory dump, a backup or the persistent-data file from handing
  out the PINs as text.
- **`F_Sha256` is plain ST** (FIPS 180-4), so it needs no crypto library and behaves the
  same on 4024 and 4026. `FB_Sha256_Tests` checks it against the three FIPS example
  vectors (empty, one block, a two-block padding).
- **Migration is automatic.** The record layout changed, so TwinCAT reinitializes the
  persistent table on the next download; the PINs it held are gone with it. Users
  are registered again from the deployment's source.
- **The press consumes a commissioning PIN.** `MAIN` registers a PIN from
  `GVL_PressCommissioning` in the scan it is written and clears it, every scan rather
  than only in `Init`. A PIN is no longer retained as text, the persistent table keeps
  the user across restarts, and the `MAIN.Init := FALSE` step is gone.

`FB_Access_Tests` gains `Re_registering_replaces_the_PIN` (two users sharing a PIN,
old PIN refused after re-registration, unknown user and empty secret refused).
Core/Modules: 197 tests / 44 suites.

## 151. Another model's data is served as one page (Core 0.21.0.0, 2026-09-28)

Found on the live press: choosing another model in the HMI's model card took 50+
mailbox round trips. §149 served another model through the ordinary manifest walk with
the model's record swapped in, so the answer was the whole station manifest - every
module's capabilities, the command catalogues, the fieldbus topology, the §3.13 step
definitions - paged 16 entries at a time, from which the HMI kept four values.

- **`FB_ConfigPager.M_SetModelOnly`.** While it is on, the walk counts and stores only
  capabilities marked `ModelScoped`; a plain entry, and a capability that is not model
  data, is skipped before it is counted. The page count therefore follows what is kept,
  and the answer is one page for a record of up to 16 values. `M_Setup` resets it, so a
  walk cannot inherit it from an earlier request.
- **`M_AppendModelConfig` turns it on for any index but 0.** Index 0 is the running
  model, and its answer is the whole manifest as before: nothing else uses the index.
- `M_Append` became a filter over the private `_M_Window`, which is the old body; a
  capability that passes the filter goes straight to the window.

`FB_ModelData_Tests.Station_values_do_not_follow_the_model` became
`Another_model_page_holds_only_its_model_data`: model B's page holds one entry on one page,
and the running model's page still carries the station value. Counts unchanged.


## 152. Optional model catalog and current export request ordinals (Core 0.22.0.0, 2026-10-04)

The shared append-only enum reserves CREATE_MODEL=37 and EXPORT_CURRENT_CONFIG=38.
The AB binding implements the optional capabilities; the current TC3 recipe
provider does not publish ModelCapacity or Features/ExportCurrentConfig and
therefore does not offer either action. TC3's unsupported dispatch still refuses
these kinds. No TC3 runtime model-creation or persistence claim is added.


## 153. AB-to-TC3 model/export and weekly Line preparation (Core 0.23.0.0, 2026-10-05)

Optional catalog creation lives in the provider and root, not project clone glue.
The local provider owns bounded persistent created payloads at stable addresses;
the root copies validated complete model capabilities into its volatile model view
and publishes the new ordinal only after provider commit. Root-only model-region
ownership is an explicit current bound; composite banks refuse rather than cloning
only one owner's data. Existing seed APIs, live recipes and ordinals stay intact.
Created-code capacity accounts for seeds/fallbacks; compatibility compares first
UINT schema and exact size, with invalid catalog images reported as restore loss.

Current export reuses the capability walk into a volatile `FB_ConfigSnapshot`,
with per-line read checks, an export token, session generation and ordered cursor.
Every replacement cancels the old cursor. A second volatile snapshot freezes
untrusted load records before identity/type/revision validation. Local saved-set
overwrite stages privately, so abort does not destroy the previous saved set.

`FB_LineDataV3` adds explicitly versioned calendar/record types and five rows;
the released daily calendar remains untouched. Whole weekly intervals validate
before commit; batch writes stage in one owner candidate. V1 migration derives
durations and V2 preserves four ordinals; the fifth starts unused with zero goal.
Only this Line owner allocates its twenty-one capability slots; ordinary modules
keep twelve. Shift closure snapshots the latched target and factors before count
reset, empty/off intervals preserve production, and manual OEE reset starts a new
factor epoch without clearing counts. The inherited cyclic call remains required.

The press Changeover entry no longer reports compressed air as a Start condition;
AUTO/HOME and cylinder directional/area permits still own their pressure gates.
New runtime fixtures cover inactive/BUSY/capacity creation, snapshot isolation,
calendar validation/migration/boundaries/history and owner image publication;
press fixtures count repeated actual EXTEND completions and end positions.

Preparation checks and the failed Login attempts are in
`Specification/Evidence/2026-10-05_TC3_Handover.md`. No TcUnit runtime pass,
physical retention, browser commissioning or complete AB parity is claimed.

## 154. Credential persistence claim corrected by native TMC generation (2026-10-05)

The compiler warns that `FB_LocalAccessProvider._users` and `_n` cannot persist
because they carry `hide`. This contradicts §150's claimed retained user table.
`TcNoSymbol` has the same persistence restriction. Symbol exclusion is retained:
changing to `conditionalshow` would permit offline searching of short-PIN hashes.
A protected persistence design and measured restart/download acceptance remain
required; passing same-run authentication tests does not establish retention.


## 155. Native handover found the pending-logout export race (2026-10-05)

The first executed aggregate returned 213/215. `Access.Cyclic` deliberately
follows the HMI handler so an accepted operator action can rearm idle expiry.
A direct pending `ReqLogout` therefore still had the old session generation
while EXPORT_CONFIG_SET ran. Reordering session handling would change that
established activity policy; current-export header and continuation instead
refuse pending logout immediately. The native test requires refusal and empty
document output. The mailbox LOGOUT path already cancels the cursor as an
intervening operation. No production permission or release gate was relaxed.

The second failure was fixture pollution: the OEE fixture passed NONE to CountNok,
which correctly faulted RESULT_RECORD_REJECTED and prevented the later Start.
The fixture now supplies TEST_FAULT; production's NOK-reason guard stays intact.
After installation and all six object checks, independent ADS results show
**215/215 across 45 suites**. Failed logs/JUnit remain beside the corrected
acceptance in `Specification/Evidence/2026-10-05_TC3_Handover_AggregateCorrected.md`.
Separate Press renditions and physical retention keep their separate scope.


## 156. Native SFC restart and branch-aware Press acceptance (2026-10-05)

The portable Press fixture originally looked for N200/N220 only in CurrentStep.
Those actions run on SFC's parallel ram leg; the fixture now reads the bounded
ActiveSteps/SequenceStepDef cursors. Its dwell assertion still requires the
named false two-hand condition, so a stale or unrelated condition cannot pass.

The corrected fixture exposed a real lifecycle defect: M_Restart reset the
shared state but not TwinCAT's native SFC graph. FB_SequenceBase now owns the
excluded SFCReset flag. M_Restart/M_ChainReset set it after shared reset; the
initial action's existing mandatory M_Step consumes it. The chart uses that
inherited flag (Reset Use=true, Declare=false, UseDefaults=false), without a
project reset method/call. ST and LD continue using their ordinary state path.
The serialized chart graph is unchanged and was read back with sfc_dump.py.

Final native results: aggregate 215/215 in 45 suites; Press 9/9 in two suites
for ST, SFC and LD. Each Press run checks repeated actual completed strokes,
end positions and hold/fault/reset recovery. Disabling only SFC Reset/Use on
the corrected fixture returns 5/9; restoring source returns 9/9. Earlier
failed fixture and lifecycle attempts remain evidence, not passing mutants.
The default source selects LD. Final all-six object checks and detailed scope
are in Specification/Evidence/2026-10-05_TC3_Handover_Final.md.


## 157. Press x32 cascaded errors from a removed Modules dependency (2026-10-05)

The local Fraktal_Modules project and installed 0.11.0.0 library had lost the
Fraktal_Core reference. A direct Core reference in Press cannot supply missing
dependencies inside a referenced library: its bases and public field types were
unknown, producing 501 pasted diagnostics. Restore the owning library's reference,
then save/install Core before Modules and cold-open the consumer. Core 0.23.0.0
and Modules 0.11.0.0 now pass PressDemoX32's native CheckAllObjects on Debug /
TwinCAT RT (x86), XAE 3.1.4026.24. No IEC behavior or runtime license was changed.
Evidence: Specification/Evidence/2026-10-05_TC3_PressX32_LibraryDependency.md.


## 158. Use the native x32 IDE and refresh its exported libraries (2026-10-05)

The missing-dependency Modules blob was reinstalled after §157's repair. It
exactly matched Framework/Release/x32/Fraktal_Modules.library; that stale export
could reintroduce the problem despite a repaired source reference. Rebuilt and
installed through TcXaeShell.DTE.15.0 in 32-bit PowerShell, and refreshed both
Release and Release/x32 exports. Both locations now match the installed Core
0.23.0.0 / Modules 0.11.0.0 blobs. Legacy single-library .sln wrappers accompany
the modern .slnx files, selected by the installer for DTE15.

The actual x32 IDE passes Press object checks and full offline code generation
for x86 and x64 PLC targets. Typed EnvDTE text-point dispatch restores its Build
pane diagnostics. No PLC was downloaded or activated. The two existing hidden
credential persistence warnings remain separate. See Specification/Evidence/
2026-10-05_TC3_PressX32_NativeIDE.md for exact artifacts and memory measurements.

## 159. Observe the selected Windows clock source and use the real task period (2026-10-06)

The real Press profile previously supplied unavailable time quality, although
F_Now already read Windows UTC. The user selected the target's existing Windows
time service. Core 0.23.1.0 adds FB_TcWindowsTime and the owning health probe's
one-time M_UseWindowsTime setup. A target-local native observer reads documented
MS-W32T RPC status and atomically publishes a versioned, packed, CRC-protected
sample. It observes only: no clock/peer/service settings are changed. Existing
Tc2_System asynchronous file access avoids a new PLC socket license/dependency.

The reader validates format, time bounds, service status, sync age and offset,
and expires unchanged cached samples using monotonic time every scan. Quality
continues through the existing single GVL authority and SystemHealth contract.
Existing explicit-provider inputs remain supported; simulation stays synthetic.
Modules 0.11.0.1 only rebuilds the Core dependency. Released health layouts and
reason ordinals are unchanged. PL_Fraktal owns the default sample path; the
native package defaults are derived from it.

Press derives its expected period and overrun indication from its current
_TaskInfo entry. The earlier hard-coded 1 ms expectation misdiagnosed the
configured 10 ms task as 9 ms jitter. Task thresholds now follow that period.
Real controller/IPC telemetry remains unavailable until wired to verified APIs.
Local CMOS Clock remains unsynchronized; the adapter cannot manufacture sync.

The guide is Specification/Guides/TC3_WINDOWS_CLOCK.md; dated evidence records
native x86/x64 observer reads, compiler gates and the separate runtime scope.
The new decoder fixture covers valid signed offsets, stale/future/corrupt
samples, service loss and excess offset; inventory is now 216 tests / 45 suites.

## 160. The local user table is retained outside the symbol table (Core 0.24.0.0, 2026-10-06)

Closes §154. The table must stay hidden (§150) and TwinCAT persists by symbol, so
`_users`/`_n` never persisted; same-run login tests could not see that.

- **Two alternating images in the Boot directory.** `FB_LocalAccessProvider` keeps
  `ST_AccessImageV1` (packed, versioned, CRC-32 through the new shared `F_Crc32`) as
  `<stem>.A.bin`/`.B.bin` under `PATH_BOOTPATH`, beside the persistent data and inside
  its write-filter exclusion. The default stem is `FraktalAccess_` plus the instance
  path (`{attribute 'instance-path'}`), so retention follows persistent-data identity
  and the project calls nothing; `M_UseStorage` overrides it and `''` is volatile. The
  table, both transfer buffers and the salt sequence stay hidden.
- **Restore is whole or nothing; a write never touches the newest image.** The newest
  image that validates as a whole wins; a torn write falls back to the previous table.
  A non-secret persistent marker - the highest generation confirmed written, bound to
  the stem by CRC - catches a newer confirmed image that is gone. What survived a loss
  is written back, so a loss is announced once.
- **The root drives it.** `I_AccessProvider` extends `__System.IQueryInterface`;
  `FB_AccessManager` finds the optional `I_AccessStore` and services it every scan. A
  loss reaches the root's §3.8b drain as `<root>.Access` (`CONFIG_RESTORE_LOST`,
  `std.error.accessRestoreLost`), with the ENGINEER acknowledgement and restore policy;
  `_M_AnnounceRestoreLoss` is now the one announcer for modules and the table. A failed
  write raises `CONFIG_PERSIST_FAILED` (`std.error.accessPersistFailed`) until a 10 s
  retry succeeds.
- **Registration.** A registration made before the restore completes wins over the
  retained record; an empty name or out-of-range level is refused, because an image
  holding one would be refused at restore. The five fixtures not about retention keep
  volatile tables, so no earlier run's file becomes their precondition.

The provider's persistent layout changed, so Core steps to 0.24.0.0; Modules 0.11.0.2
only rebuilds against it. `FB_CreateDir` reports 0x70C for "exists or invalid path",
so the TcUnit failure path uses a probe store, and the provider's real failing write
was accepted live against a directory staged in the Boot folder.

## 161. Controller/IPC metrics and the EtherCAT master's own health (Core 0.24.0.0, 2026-10-06)

The real Press profile supplied unavailable controller metrics, `IpcAvailable=FALSE`,
zero frame/slave counters and no DC. Separately, `M_BusOk` - Control On's bus
criterion - was refreshed after the first scan only while the HMI bus view was open.

- `FB_TcIpcDiagnostics` reads the Beckhoff Device Manager through Tc3_IPCDiag:
  `CPU_Usage`, `Memory_ProgramMemoryAvailable`, `CPU_Temp`, `Fan_Speed`,
  `MassStg_DriveList_EraseCyclesLeft`/`SpareBlocksLeft`, names and types taken from the
  installed library 1.2.6.0. One read at a time after a 20 s start delay, 40 s
  freshness, range checks, and re-registration after a whole round of failures.
  `FB_TcSystemHealthProbe.M_UseIpcDiagnostics` enables it once.
- `ST_SystemHealthInput/Status` gain `FanAvailable`/`StorageAvailable` (input default
  TRUE): a fanless IPC or a drive without wear data is neither a fault nor a healthy
  reading. The publisher gates the fan and storage alarms on them. Additive.
- `FB_EcBusHealth` samples device state, frame statistics and summed slave CRC errors
  every second, outside the demand gate. Counts are the larger of the current and last
  complete 10 s window; `MasterHealthy` uses mask `16#0FF3`, DC bit `16#1000`.
  `M_BusOk` also requires the live `MasterHealthy`. `M_UseEtherCatMaster` feeds the
  probe; the Press driver hands over its adapter (`M_BusHealth`) and MAIN enables both
  providers in the real profile only.

On the test host both stay unavailable, as they should: no Device Manager
(`0xECA8070C`) and no EtherCAT master (ADS 0x7 on `192.168.1.6.2.1`). Positive values
need the Beckhoff IPC target.

## 162. Clock acceptance findings and an unattended runtime gate (2026-10-06)

- The 216-test aggregate from §159 executed for the first time: 216/216.
- `FB_TcWindowsTime` reported 13 ("invalid data") for a missing observer record; it now
  reports the file-service error whenever the cached record does not validate (1804,
  not found). It also copied a rejected record's measurements into `Quality` before
  validating it - a corrupted byte appeared as a 255 us offset; measurements now come
  only from an accepted record.
- Live on the isolated runtime with the native observer: 1062 (Windows Time stopped,
  as `w32tm` reports), 1460 after 90 s without a new record, 13 for a corrupted record,
  recovery without a PLC reset, and 1804 for a missing record.
- Hours later the same harness read 1460 while the observer was still writing: the
  usermode runtime's TwinCAT time (`F_Now`, which stamps every event) had fallen 475 s
  behind Windows UTC, so every fresh record looked future-dated and was rejected before
  its change was tracked. Freshness now rests on the record changing plus a maximum
  age, the sync age is judged on the record's own OS time base, and a PLC clock more
  than the sample age behind the OS clock is reported as unsynchronized (`ErrorID
  1398`) - otherwise a synchronized OS would vouch for event stamps eight minutes off.
- `Invoke-TwinCatTcUnitGate.ps1 -StartBootProjectWithAds`: activation already writes the
  boot application, and with Autostart off the restarted runtime has none loaded (ADS
  Invalid); an ADS Run request loads and starts it. The gate refuses a port already
  running, verifies the loaded project name over ADS and stops it in `finally`. That
  closes the Login blocker of workflow §9.1 for unattended runs. One Press run met a
  transient ADS 0x4 (router mailbox) while the boot application loaded and aborted
  before marking the start; the state poll now retries until its deadline, and the
  start is marked before the Run request so `finally` always stops it.

Final: aggregate 227/227 in 47 suites; Press 9/9 for each of LD, ST and SFC. Scope
and artifacts: `Specification/Evidence/2026-10-06_TC3_MissingFeatures.md`.

## 163. Retained data on a project-chosen medium (Core 0.25.0.0, 2026-10-06)

Owner request: the Press bench keeps its station, model and line configuration and
its local users (name and PIN hash) as files on the hard drive, and where retained
data lives must be a per-project choice - a persistent variable, a file, a database -
switchable without touching the modules, since not every platform offers every medium.
The owner chose a dedicated folder, file plus persistent-variable media now (a database
medium once a server and a TF6420 licence are named), and the saved parameter sets on
the same medium.

- **One medium interface.** `I_PersistMedium` moves keyed byte documents through a
  bounded FIFO of tickets; every consumer polls its own ticket, which is what advances
  the medium, so a project schedules nothing. `FB_PersistMediumBase` holds the queue
  once; `F_ValidPersistKey` is the one key rule (no separator, at most 80 characters).
  `M_Confidential` says whether a document stays out of the symbol interfaces.
- **`FB_FilePersistMedium`.** Two files per key with a readable 80-byte header
  (generation, length, CRC-32 of key, data and header); folder chain created on the
  first request; persistent confirmed generations for loss detection, keyed by the CRC
  of folder and key. **`FB_RetainPersistMedium`**: a bounded persistent pool flushed by
  the shipped `FB_PersistentDataWriter`; not confidential.
- **`FB_ConfigSetDocument`** renders a set from any `I_ConfigStore` to the existing
  JSON-lines text and parses it back whole or not at all; `FB_MediumConfigStore`
  (sets) and the root's live documents share it. `FB_ConfigSetJson` refused
  `kind` 2, so a `LINE_CFG` set could be exported but never parsed back; it now accepts
  every `E_ConfigKind` member.
- **The root's live documents.** `SetPersistMedium` keeps `<root>.station`, the owned
  line, and every catalog model's data. `LoadConfigSet`'s staged apply moved into
  `_M_ApplySet`, which the restore reuses (without the session level: the restore is
  the machine's act); `_M_ValidateSetShape` gains `AnyRevision`, because a document
  carries an earlier run's `ConfigRev`; capture writes into any store
  (`_M_CaptureInto`), so writing documents never invalidates an export cursor. Writes
  are refused and Start names `std.release.configRestoring` until the documents are
  back. A runtime-created model whose catalog record did not survive is created again
  from its document.
- **Stores that write themselves out.** `I_ConfigStore` extends
  `__System.IQueryInterface`; `SetConfigStore` finds an `I_ConfigPersistence` on the
  store and the root drives it beside its own writer, so `PersistPending` covers a
  saved set until its file exists.
- **User table on the medium.** `FB_LocalAccessProvider` lost its own A/B file code:
  it keeps the image as one document on `M_UseMedium`'s medium (confidential only) or,
  by default, on its own file medium in the Boot directory under
  `FraktalAccess_<CRC of instance path>`; `M_UseKey` replaces `M_UseStorage`. Images
  written by the never-released 0.24.0.0 layout (`<stem>.A.bin`) are not read.
- **Press.** `MAIN` declares `Storage : FB_FilePersistMedium` on
  `C:\ProgramData\Fraktal\PressDemo\` and gives it to the root
  (`SetPersistMedium`), to `ConfigStore : FB_MediumConfigStore` and to the user
  table (`PneumaticPress.users`).

**Two defects found by live acceptance, not by TcUnit.** The first file medium kept one
"expected header" buffer for both slots, so verifying the newest copy compared it with
the other slot's header whenever the newest was not the last one scanned; the copy was
rejected, the fallback then chose the rejected slot again, and the next write - steered
by a per-key cache that recorded the wrong conclusion - replaced the newest copy. A
second runtime restart of the acceptance harness therefore came back on defaults and
announced its station and model documents lost while every file was intact (verified
independently on the host). Every TcUnit restart had read a newest copy that happened
to be the last scanned. Now the expected header is rebuilt per slot, the fallback takes
the newest slot still valid, both headers are re-read before every write and the cache
is gone, and `The_newest_copy_wins_in_either_slot` pins it. Separately, a file-service
error other than not-found was counted as damaged content, so a transient error at
start would have been restored as defaults and written over the documents; such a read
now answers `Ok = FALSE`, writes are refused, and the root, the user table and the set
store retry (announced as `std.error.storageUnreadable`) instead of concluding. Second,
`FB_MediumConfigStore.Durable` went TRUE while a set's write was still in flight;
TcUnit caught that one.

Host-side files are created by the runtime's account (`TcSysSrv`); with the default
`C:\ProgramData` ACL an ordinary user may read them but not change them - the live
acceptance's attempt to damage a document from an unelevated shell was refused - so
the acceptance harness damages, removes and obstructs documents through the PLC's own
file service (`PRG_PlatformAcceptance`, test-only).

The confirmed generations live in the runtime's persistent data, which activating a
*different* PLC project on the same port replaces: the user table written before the
PressTests gates ran had lost its marker, so deleting it afterwards went unreported (a
lost marker can only miss a loss). Once written again in the current project, its
deletion was announced on `Acceptance.Access`.

Final: Core 0.25.0.0 / Modules 0.11.0.3 installed from the isolated checkout (one XAE
crash while closing the Core solution after the library was saved - "Index was outside
the bounds of the array"; the IDE restarted and the install completed); six
`CheckAllObjects` clean; aggregate 235/235 in 49 suites; Press 9/9 for each of LD, ST
and SFC. Live on the isolated runtime with files in `C:\ProgramData\Fraktal\Acceptance\`:
two runtime restarts with the newest copies alternating between the slots restored
every value, model record, set and user without a loss; damaged, deleted and obstructed
documents behaved as described above. Scope and artifacts:
`Specification/Evidence/2026-10-06_TC3_PersistMedium.md`.

## 164. An analog channel's unit is a code (Core 0.26.0.0, 2026-10-26)

First step of the generic control-module expansion. A configuration value has published
its unit as a code since Core 0.14 (`ST_ConfigEntry.UnitCode`, §3.10.2), so the HMI shows
its own translated symbol; a fieldbus channel still carried only free text
(`ST_IoChannel.Unit`), so the analog channels the expansion adds would have shown
untranslated ASCII in the bus view.

- **`ST_IoChannel.UnitCode : E_EngUnit`**, appended, `OPC.UA.DA` 0: static identity,
  served through the manifest like `Name`/`Address`. `Unit` stays for clients that
  predate the code.
- **One source per channel.** `FB_IoTopologyPublisher.M_DefineAnalogChannel` gains a
  `UnitCode` input. With a code, `Unit` is derived through `F_EngUnitSymbol` - the
  `ST_ConfigEntry` pattern. The catalog's `EngUnit` text is kept only for a unit the
  vocabulary lacks (`mA`, raw counts). A channel given both is refused with the existing
  `std.error.fieldbusChannelMappingInvalid` (`MappingValid=FALSE`) instead of resolved
  silently: two sources for one fact is exactly what O9 forbids, and the catalog is
  reviewed engineering data, so the defect belongs on the commissioning screen.
- **Manifest.** `F_AppendTopologyConfig` exports `UnitCode` only when it is not `NONE`;
  an absent code reads as none, so a digital channel costs the manifest nothing extra.
- **HMI.** `IoChannel.unitCode`/`unitKey`; `engUnitKey` in `types.dart` is now the one
  code-to-key rule, used by `CfgField.unitKey` as well. The mapper reads a channel's
  absent, `NONE` or newer-than-the-client code as "no code", so the legacy text stands:
  for a channel, `NONE` means the unit was given as text, and a binding that publishes
  the whole struct (TIA, a raw ADS read) sends 0 for every uncoded channel. A first
  version read 0 as "no unit" and would have hidden such a channel's `mA`. The channel row and the force dialog show the translated
  symbol (`2.50 µm`, not the PLC's ASCII `um`).
- **Upgrade cost.** Core *minor*: the `ST_IoChannel` layout and the method signature
  change. Every `M_DefineAnalogChannel` call passes `UnitCode` - the 4024 profile has no
  defaulted method inputs - so the Press catalog's eight EL6001 byte channels now pass
  `UnitCode := E_EngUnit.NONE`. No retained data is involved.
- **Tests.** `UnitCode_derives_the_unit_text`, `No_code_keeps_the_catalog_text`,
  `A_code_and_a_text_together_are_refused` in `FB_IoTopologyPublisher_Tests`, on a table of
  their own: the refused definition marks its table invalid, and the existing rows
  validate theirs. HMI: `channel_unit_code_test.dart` (mapper, and the row in every
  theme).
- **Parity.** AB carries channel text only; TIA's `FB_IoTopologyPublisher` (C19) does not
  carry the code yet. Both are recorded in their own census, and the read-surface gate
  (`tools/check_consistency.py`) declares the AB absence in `AB_ABSENT`. That was the
  first fieldbus entry ever declared there, and the gate reported it stale although the
  HMI reads it: its staleness check looked only at module reads. It now judges a
  `Topology/...` entry against the fieldbus reads and publications
  (`test_a_fieldbus_absence_is_judged_against_the_fieldbus_surface`).

## 165. Digital-input debounce at the source (Modules 0.12.0.0, 2026-10-26)

A bouncing contact is settled by the module that owns the signal (§7.2.1), not by a wait
in each sequence that happens to read it: the latter is a per-chain timer a project has
to remember (O1), and a chain that forgets it advances on a bounce.

- **`ST_DigitalInputParCfg` v2** appends `DebounceTime : TIME := T#0MS`. The type has no
  recipe provider - the composition root assigns `ParCfg` - so nothing is stored and
  nothing migrates; existing instances compile to v2 with the default, which is v1.
- **Behaviour.** `OutImm.Value` follows the HAL only after it has differed from the
  published value continuously for `DebounceTime`; the timer restarts on acceptance, so a
  bounce straight back is timed from its own edge. `T#0MS` passes through in the same
  scan. `Quality = FALSE` publishes `Value := FALSE` and resets the timer, so returning
  quality is timed afresh rather than restoring the old value.
- **Fail closed (§5.6).** A `SchemaVersion` other than the compiled layout's, or a
  `DebounceTime` above `DI_DEBOUNCE_MAX` (`T#10S`, a type constant), makes `Setup` return
  FALSE and publishes `Quality := FALSE` / `Value := FALSE` every scan for as long as it
  persists - checked each scan, because `ParCfg` is an input a root may assign after
  `Setup`. The compiled layout is the DUT's own initializer, read from a method-local
  default instance, so the version number is written once.
- **Surface.** No raw-value member and no reason code: a passive monitor has no command
  to fault, and the raw value waits for a maintenance view that reads it (O4/O9).
- **Upgrade cost.** Modules *minor* (published `ParCfg` layout); no behaviour changes for
  an instance that does not set `DebounceTime` - the Press `PartPresentSensor` among them.
- **Tests.** Five rows in `FB_InputCM_Tests`. The timed rows assert the elapsed `TIME()`
  when `Value` changes, not a scan count, so a jittery test runtime can neither hide an
  early change nor fail a correct one.
- **Parity.** AB's generated digital-input type and TIA's M2 pass the value through;
  both are recorded in their own census.

Final (§164 and §165): Core 0.26.0.0 / Modules 0.12.0.0 installed from an isolated
worktree; six `CheckAllObjects` clean (0 errors, 0 warnings); both lint profiles, the tool
tests and strict consistency green; HMI analyzer clean, 622 passed / 12 skipped on Flutter
3.44.6 (the 3.47.x pin is not installed on this host). On the isolated UmRT: aggregate
243/243 in 49 suites, Press 9/9 in 2 suites (Ladder AUTO). The first aggregate run met an
expired `TC3 PLC` trial licence (2026-10-13); the owner renewed it and both gates passed
unchanged. Scope and artifacts: `Specification/Evidence/2026-10-26_TC3_GenericCM_Phase0.md`.

## 166. Cylinder valve timing (Modules 0.13.0.0, 2026-10-26)

Phase 1 of the generic control-module expansion: the valve-timing options stations set
on their cylinders, on `FB_CylinderCM` - the type stations instantiate.

- **`ST_CylinderParCfg` v2** appends `SettleTime`, `MinOutputTime`, `PulsingWidth`,
  `PulsingPeriod`, `ResetOnEndPos`, `ResetOnTimeout`; every default reproduces v1.
  `SettleTime` keeps the configurable cylinder's name and meaning.
- **Which phase pulses** - the question the plan left open, settled against station
  practice: a move that **starts with neither end sensor confirmed** (the undefined middle
  a stop or a held move leaves behind) pulses its coil for `PulsingWidth` of every
  `PulsingPeriod` until the target confirms; a stroke from an end position is driven
  steadily. Pulsing is travel, never an end-position refresh. A width that grows each
  period and pulsing that depends on the mode wait for a station that needs them.
- **`FB_ValveDrive`**, owner-private (no identity, nothing published): one move's coil
  level and its minimum output time. The plan's `Hold` input was dropped: the cylinder's
  §6.1 HOLD rewinds the move to its first step, so a resumed move begins afresh, and a
  second way to freeze the pattern would have had no caller.
- **Completion.** `Done` needs the target sensor held for `SettleTime` and the move
  commanded for `MinOutputTime`. The coil is then held (v1) or, under `ResetOnEndPos`,
  withdrawn; `ResetOnTimeout` withdraws it on the timeout fault.
- **No weaker stop.** `OnAbort` still de-energizes, a lost interlock still HOLDS with both
  coils off, and pulsing never runs while held. One latch is new: a pulsed move writes its
  coil every scan, which would have undone an owner's `WithdrawOutputs` - the Press
  withdraws its ram mid-dwell and on every abort. A withdrawal now stays until
  `RestoreOutputs` or the next move begins, which is what v1 gave by writing the coil once
  per move. `RestoreOutputs` restores what the module itself would drive, so a coil reset
  at its end position stays off.
- **Validation (§5.6).** `PrepareRecipe` refuses a non-zero `SettleTime` or
  `MinOutputTime` not shorter than `MoveTimeout`, and a `PulsingWidth` not shorter than
  `PulsingPeriod`, with `CYL_CFG_INVALID` (10115, now shared by both cylinder types); a
  refused record is not applied. A zero time is off and cannot conflict, so the existing
  `MoveTimeout := T#0S` timeout rows stand.
- **Upgrade cost.** Modules *minor*. Records compiled from `ST_CylinderParCfg` take v2 on
  rebuild. A record a station **stored** under `CylinderCM` is v1-sized and is refused with
  `RECIPE_INVALID` at the next prepare: list them through `I_RecipeCatalog` before the
  upgrade and save them again after. The Press passes `Recipe := 0` and stores none. No
  configuration value is registered for the new members; a station that needs one on site
  registers it then (`M_RegisterConfigDuration`).
- **Tests.** Thirteen rows in `FB_CylinderCM_Tests` - the plan's eleven plus
  `A_move_from_an_end_position_does_not_pulse` and
  `Withdrawn_outputs_stay_off_while_a_pulsed_move_runs` - with T5 restamped for v2, and four
  in the new `FB_ValveDrive_Tests`. The stored-record row uses a v1-shaped probe record
  (`ST_ProbeCylinderParCfgV1`), so it fails on the size a real stored record has.
- **Deferred.** Valve preset matrices, "reached too fast" detection, mode-dependent
  pulsing, a growing pulse width, and adoption by `FB_ConfigurableCylinderCM` (with its first
  consuming station). AB and TIA record the gap in their census.

Final: Modules 0.13.0.0 installed from the isolated worktree; six `CheckAllObjects` clean
(0 errors, 0 warnings); both lint profiles, the tool tests and strict consistency green. On
the isolated UmRT: aggregate 260/260 in 50 suites, Press 9/9 in 2 suites (Ladder AUTO).
Scope and artifacts: `Specification/Evidence/2026-10-26_TC3_GenericCM_Phase1.md`.

## 167. The Unit's NOK-part limit (Core 0.26.1.0, 2026-10-27)

Generic control-module expansion WP5.1, with the Press bench as its first consumer.

- **`FB_UnitBase.SetNokPolicy(Cfg : ST_NokPolicyParCfg) : BOOL`**, given by the
  composition root: `InSeries` NOK parts in a row and/or `WindowNok` NOK among the last
  `WindowCount` judged parts (`PL_Fraktal.NOK_WINDOW_MAX` = 32). Zero turns a rule off;
  the default is no limit. Refused, policy unchanged, unless it is the compiled layout and
  each rule is off or well formed - a window without a limit is refused rather than read
  as "trip at once". An accepted policy counts afresh. Editing it on site waits for a
  station that asks.
- **Counted on the one verdict path, `CountGood`/`CountNok`** - not in `_M_PartProcessed`
  as the plan said. A station without a part carrier counts through `M_CountGood` and never
  reaches `_M_PartProcessed`, so the planned hook would have missed it. REWORK neither
  counts nor ends a series.
- **A trip** is one `NOK_LIMIT_REACHED` (2028) event, `MANUAL_RESET`; Start is refused by
  the record `ReleaseReportStart` already adds for any blocking alarm
  (`std.release.manualReset`), so there is no new gate. The plan stopped there, but a
  blocking alarm only refuses the *next* Start and a Unit in continuous AUTO is not
  restarted: it would have kept producing rejects. A running Unit therefore also finishes
  its cycle at its stop point (`_stopReq`, the graceful mode-change path) and stays
  stopped.
- **Fail closed.** A trip whose alarm found the table full is raised again every scan
  until it exists, and the counters re-arm only once the operator's reset has closed that
  alarm (`_M_NokCyclic`, also called from `OperatorReset` so the reset re-arms at once).
  Only the alarm is published; the policy and the window are `OPC.UA.DA` 0.
- **§8.9.** Rationalized MED/PROCESS, not shelvable. The generator gained the `NOK`
  acronym, so the reason reads "NOK limit reached."; operator text
  `std.error.nokLimitReached` in English and Spanish.
- **Press.** `MAIN` sets 3 in a row or 5 of the last 20 - bench values that exercise both
  rules, not a process recommendation. The PressTests composition sets none.
- **Cross-binding.** `E_Reason` is part of TIA's frozen candidate ABI, which allows no
  change without a versioned review. The owner reviewed this append on 2026-10-27:
  `TIA_FROZEN_CONTRACTS_V2.json` is V1 plus this entry, V1 stays byte for byte, and
  `tools/check_tia_contracts.py` now checks against the newest baseline and requires every
  earlier one to be contained unchanged and bound in Part IV
  (`test_a_successor_preserves_and_keeps_binding_every_earlier_baseline`). The TIA
  packages were regenerated - its command kernel carries 2028's rationalization - and the
  S12 field pin moves to 615. No TIA or AB Unit has the limit; both record the gap.
- **Upgrade cost.** Core *patch*; Modules 0.13.0.1 is only a rebuild against it. No
  retained data is involved.
- **Tests.** `FB_NokPolicy_Tests`, nine rows on two probe Units. The single-scan rows
  share one, each starting from a clean slate, because a probe Unit is about 350 KB.

Final: Core 0.26.1.0 / Modules 0.13.0.1 installed from the isolated worktree; six
`CheckAllObjects` clean (0 errors, 0 warnings); lint, tool tests, strict consistency and every
AB/TIA replay and contract gate green; HMI analyzer clean, 622 passed / 12 skipped. On the
isolated UmRT: aggregate 269/269 in 51 suites, Press 9/9 in 2 suites. Scope and artifacts:
`Specification/Evidence/2026-10-27_TC3_GenericCM_NokPolicy.md`.
## 168. The generic analog input CM (Modules 0.13.1.0, 2026-10-30)

L1 of the remaining-library plan. One type covers a plain analog signal, a
measuring sensor (a value read once it is stable) and a scale (a tared
reading): the differences are configuration, not types (O9), and after L1/L2/L5
reserve 10700/10800/10900 every CM reason block is allocated.

- **`FB_AnalogInputCM`**: `ParCfg` scales linearly over `[RawMin, RawMax]` to
  `[EngMin, EngMax]` (both ranges may be inverted) until a two-point adjustment
  is active, then a first-order `FilterTime` filter on `Gross - Tare`, an
  `UnderRange`/`OverRange` judgement and a `StableBand`/`StableTime` stability
  window with re-anchoring on a band exit. Bad quality, a ParCfg the type
  cannot honour or an implausible retained adjustment publishes `Valid` FALSE
  and `Value` 0 (S5.6) - never the last good value, and the filter
  re-initialises so returning quality is measured afresh. The one command,
  `MEASURE`, waits for stability within `MeasureTimeout` and completes with
  `OutCmd.Value`; `Gross` (before tare) and `Raw` are published beside `Value`
  because they are the adjustment's and the tare's capture sources (S3.8c(b)).
- **Two-point adjustment and tare are deployment data** (`StationCfg`,
  S3.8a/S3.8b): five editable values, the two measured points and the tare also
  capturable from the live signal. A pair is ACTIVE when both references and
  both measured points differ; single points may be written while it is
  inactive, so an operator captures one point at a time. A pair whose gain lies
  outside `[0.5, 2.0]` of the nominal gain is implausible - that is a corrupted
  restore, not a calibration - and `_M_OnConfigWrite` refuses a typed OR
  captured candidate that would make the pair active and implausible. This is
  the library's first `_M_OnConfigWrite` override; it sees raw text, has no
  side effects, and parses with `STRING_TO_LREAL` under the same rule.
- **IEC AND does not short-circuit - a lesson bought on the runtime.** The
  first build guarded the plausibility call as
  `IF (a) AND (b) AND NOT _M_AdjustmentPlausible(...)` and evaluated the call
  on every INACTIVE pair: `(Ref2-Ref1)/(Meas2-Meas1)` divided 0/0, the FPU trap
  (0xc0000090) halted the PLC task, and the aggregate gate died at startup
  twice before the Windows event log named the exception. Every call that can
  divide, dereference or fault now sits under its own IF (the `valid`
  dereference chain included). No static gate catches this class; the TcUnit
  runtime gate does.
- **The TcUnit gate had a swallowed-start race** (`Invoke-TwinCatTcUnitGate.ps1`,
  `Set-AdsPlcState`): a Run request issued while the boot application is still
  loading is accepted yet swallowed - no ADS error, the state stays Stop, and
  with autostart deliberately disabled nothing re-issues it. The request is now
  re-issued on every poll that still sees the old state. Measured twice on the
  UmRT on 2026-10-30; the aggregate and press gates then passed unchanged.
- **Reasons 10701-10705** (`AI_UNDER_RANGE`/`AI_OVER_RANGE`/`AI_SIGNAL_INVALID`/
  `AI_ADJUSTMENT_INVALID`/`AI_NOT_STABLE`), rationalized, catalogued (78 -> 83,
  generator gains the `AI` expansion), Part I S8.8 registry row added.
  `AI_ADJUSTMENT_INVALID` is raised before `AI_SIGNAL_INVALID` so the operator
  is sent to the adjustment, not the wiring. Operator text in English and
  Spanish; the HMI gains the `analogInput` module symbol (`Icons.show_chart`).
- **Upgrade cost.** Core *patch* 0.26.2.0 - only the generated reason catalog
  changed (the S167 precedent); Modules *patch* 0.13.1.0 pins it and adds the
  type. New type: no stored records, no retained image exists yet, nothing
  migrates. TIA: Modules-only, so the packages change only by the
  `PL_ModuleReasons` hash (examples manifest refreshed); the frozen candidate
  contract is untouched. AB records the gap in its census.
- **Tests.** `FB_AnalogInputCM_Tests`, 16 rows: T2 first-out with the schematic
  tag, T5 implausible refused typed or captured, timed filter/stability/timeout
  rows asserting elapsed `TIME()`. A first boot initializes version 0 silently,
  and an unrecognized layout keeps the module out of error while defaulting.

Final: Core 0.26.2.0 / Modules 0.13.1.0 installed from an isolated worktree;
six `CheckAllObjects` clean (0 errors, 0 warnings); both lint profiles, the tool
tests, strict consistency and every AB/TIA replay and contract gate green; HMI
analyzer clean, 622 passed / 12 skipped on Flutter 3.44.6 (lock unenforced). On
the isolated UmRT: aggregate 285/285 in 52 suites, Press 9/9 in 2 suites. Scope
and artifacts: `Specification/Evidence/2026-10-30_TC3_GenericCM_AnalogInput.md`.
## 169. The generic analog output CM (Modules 0.13.2.0, 2026-10-30)

L2 of the remaining-library plan. The output-side counterpart of S168: one
command, `SET`, and a channel whose state is always somebody's.

- **`FB_AnalogOutputCM`**: `SET` drives the channel to a target inside
  `[ParCfg.Minimum, ParCfg.Maximum]` (both inside the scalable range; the
  safe value inside the band) and completes in the scan the value is
  written; the value then stays applied until the next `SET`. Whatever
  state nobody stands behind drives `SafeValue`: before the first `SET`,
  while an interlock withholds it, while withdrawn, and after an abort
  (S5.6 - the channel never silently keeps its last driven value).
- **Held, not resumed.** During a `SET` an interlock is S6.1 HELD (the
  output withdrawn by the same permit, a resume re-applies the target). A
  value applied and THEN withheld drives `SafeValue` and does NOT
  self-resume when the condition returns (S9.3): only `RestoreOutputs` or
  a new `SET` re-applies it. `RestoreOutputs` restores what the module
  itself would drive and only while the interlock permits - the caller
  asks, this module still decides; a suspended channel is released but a
  withdrawn-with-nothing-applied one keeps driving `SafeValue`.
  `WithdrawOutputs` holds until restore or the NEXT `SET`, which releases
  it in the same act that applies its own target (the cylinder latch
  semantics, on one value instead of two coils).
- **The manual set point is deployment data**: `ManualCommand(SET)`
  applies `StationCfg.ManualTarget` - an ordinary editable value with the
  band as bounds - so an operator's set point survives a restart and is
  never a silent recipe member (S3.8a/S3.8b).
- **Reasons 10801-10802** (`AO_TARGET_OOR`, `AO_CFG_INVALID`),
  rationalized, catalogued (83 -> 85), registry row added; the generator
  gains the `AO` expansion. Operator text in English and Spanish; the HMI
  gains the `analogOutput` module symbol. One rule the L1 runtime lesson
  set is already baked in here: the only division lives in
  `_M_ScaleToRaw`, which every caller reaches only under a valid `ParCfg`,
  and no call sits inside a boolean expression.
- **Upgrade cost.** Core *patch* 0.26.3.0 (generated reason catalog only);
  Modules *patch* 0.13.2.0 pins it and adds the type. New type: nothing
  migrates. TIA: hash-only change, packages regenerated and verified; AB
  records the gap in its census.
- **Tests.** `FB_AnalogOutputCM_Tests`, nine rows: T2 (out-of-band target
  refused before writing), T3 (interlock withholds the channel, resumes),
  T5 (invalid configuration refused). The first aggregate run failed three
  rows, all test-authoring defects the runtime caught: the shared instance
  had already been SET by another row, a band instance whose own
  `SafeValue` lay outside its band is configuration-invalid rather than
  target-out-of-range, and a `DONE` command is no longer abortable - the
  abort row now aborts a HELD `SET`, the one state a one-scan command can
  be busy in.

Final: Core 0.26.3.0 / Modules 0.13.2.0 installed from an isolated worktree;
six `CheckAllObjects` clean (0 errors, 0 warnings); both lint profiles, the
tool tests, strict consistency and every AB/TIA replay and contract gate
green; HMI analyzer clean, 622 passed / 12 skipped on Flutter 3.44.6. On the
isolated UmRT: aggregate 294/294 in 53 suites, Press 9/9 in 2 suites. Scope
and artifacts: `Specification/Evidence/2026-10-30_TC3_GenericCM_AnalogOutput.md`.

## 170. Axis depth: named positions, relative moves, speed scale and override (Modules 0.14.0.0, 2026-11-02)

L3 of the remaining-library plan. Every addition is checked before any
`MC_*` call, so each refusal is provable without an NC axis; the motion
itself is not (no NC PTP licence on this host).

- **Named positions.** A second retained image, `ST_AxisTeachCfg`
  (`ManualStep` and `Positions[2..PL_Axis.MAX_POSITIONS]`, schema
  `PL_Axis.AXIS_TEACHCFG_SCHEMA` 1), restored by its own
  `M_RestoreStationCfg`. The v2 `ST_AxisStationCfg` and its keys are
  unchanged, so no deployed image is lost and a first boot after the
  upgrade is silent. The composition root declares positions with
  `M_DeclarePosition(Index, LabelKey)` before `Setup` (refused out of
  range, for an empty label, twice, or after `Setup`); `Setup` registers
  each as `axis.position<n>` with the soft limits as bounds and a capture
  from `ActPos`, plus `axis.manualStep` - 10 of the 12 registrations.
  `ParCmd.PositionIdx` selects the target (0 `Target`, 1 `TaughtPosition`,
  2..8 a declared position); an undeclared index is refused
  `AXIS_POSITION_UNDECLARED` (10207) before the range and datum checks.
- **Relative and step moves.** `E_AxisCommand` appends `MOVE_REL`
  (sequence only: `ParCmd.Distance`) and `STEP_POS`/`STEP_NEG` (manual
  catalog: `±ManualStep`), all on `MC_MoveRelative`. A zero distance
  completes without an `MC_*` call; a step with no manual step set is
  refused `AXIS_PARAM_OOR` (`std.error.axisManualStepNotSet`).
- **Defects found in review and fixed before the first commit.**
  - The first version judged `ActPos + distance` against the soft limits
    on every scan, so the target travelled with the axis: a legal move
    from 0 to 80 under `SoftMax` 100 would have faulted `AXIS_TARGET_OOR`
    at `ActPos` 40. The relative request is now resolved and judged once,
    when the command starts, and the distance is latched (`_relDistance`).
    No TcUnit row can reach the moving step without an NC axis, so this
    fix is reasoned, not runtime-proven.
  - Index resolution and `M_DeclarePosition` guarded the array read with
    plain `AND`/`OR`. ST evaluates both operands, so an out-of-range index
    still read `_positionDeclared[ParCmd.PositionIdx]` past the array
    (and, if that byte happened to be non-zero, `_teach.Positions[...]`
    too). Both chains are now `AND_THEN`/`OR_ELSE` throughout, so the
    range check really guards the read.
  - Seven `FB_Axis_Tests` rows shared an instance whose `Setup` nobody
    called, so they never started and the aggregate gate never reached
    `AllTestSuitesFinished` (the result print stopped at suite 33,
    `AxisTests`). The first of the seven now sets the instance up. Two
    rows used a `Setup` result that is FALSE by design as their done mark,
    and the stored-v1 row had no valid default record, so its "refused"
    assertion was satisfied by `Setup`'s own refusal: each now has a done
    mark and the provider a current-layout record. In `FB_AxisJog_Tests`
    the out-of-range, index-0 and empty-label refusals sat behind a flag
    the previous row had always set, so they never ran; the row now uses
    its own instance and proves each refusal before `Setup`, then the
    after-`Setup` refusal.
- **Speed.** `ST_AxisParCfg` v2 appends `SpeedScaleMin`/`SpeedScaleMax`
  (REAL percent, the robot idiom) and `ST_AxisParCmd` `SpeedScale`; a
  scale outside the band is refused `AXIS_PARAM_OOR` (10208) before the
  datum, never clamped, and scales the commanded velocity. `PrepareRecipe`
  refuses a non-positive, inverted or over-100 band with
  `AXIS_CFG_INVALID` (10209). `SetOverride(Percent)` is set-and-hold
  (0..100, refused and kept otherwise), drives `MC_Power.Override` - so it
  acts on a running move and on jog - and is published as
  `OutImm.Override`. No freshness fallback: a silent owner can only leave
  an already accepted value.
- **Reasons 10207-10209** rationalized and catalogued (85 -> 88), the
  registry row widened to "axis CM 10201-10209", Annex G updated, operator
  text in English and Spanish, AB/TIA census rows; the TIA packages
  regenerated (a hash-only change).
- **Upgrade cost.** Modules *minor* 0.14.0.0 (ParCfg v2, ParCmd growth,
  enum append, a new retained image, a new OutImm member); Core *patch*
  0.26.4.0 carries only the regenerated reason catalog. `ST_AxisParCfg`
  records **stored** in a recipe provider are refused (`RECIPE_INVALID`)
  until saved again; no StationCfg image is lost.
- **Tests.** Fifteen rows - thirteen in `FB_Axis_Tests` (index resolution,
  relative and step refusals, zero distance, speed-scale band, override
  set-and-hold and refusal, invalid band at prepare, a stored v1
  `ST_AxisParCfg` refused through the probe `ST_ProbeAxisParCfgV1`) and
  two in `FB_AxisJog_Tests` (declared positions register and capture;
  declarations refused at index 0, 1 and 9, for an empty label, twice, and
  after `Setup`).

Final: Core 0.26.4.0 / Modules 0.14.0.0 installed from an isolated
worktree; six `CheckAllObjects` clean (0 errors, 0 warnings); both lint
profiles, the tool tests, strict consistency and every AB/TIA replay and
contract gate green; HMI analyzer clean, 622 passed / 12 skipped on
Flutter 3.44.6. On the isolated UmRT: the first aggregate run stalled at
`AxisTests` (the rows above that never started); after the fixes,
aggregate 309/309 in 53 suites and Press 9/9 in 2 suites. Scope and
artifacts: `Specification/Evidence/2026-11-02_TC3_GenericCM_AxisDepth.md`.

## 171. The configurable cylinder adopts the valve timing (Modules 0.15.0.0, 2026-11-02)

L4 of the remaining-library plan. `FB_ConfigurableCylinderCM` drives its
commanded output through the same `FB_ValveDrive` as `FB_CylinderCM`
(§166), so the two cylinder types time their valves one way and the timing
is written once.

- **`ParCfg` v2** appends `MinOutputTime`, `PulsingWidth`, `PulsingPeriod`
  (`T#0MS`) and `ResetOnEndPos`, `ResetOnTimeout` (`FALSE`); `SettleTime`
  already existed and keeps its 30 ms default. Every new default
  reproduces v1: a steady output held after Done and after a timeout.
- **Behaviour.** One private `_M_DriveCoil(ToWork, Level)` writes the
  commanded output and never the spring side of a single-acting cylinder.
  A move that starts with neither position confirmed pulses; any other is
  steady. Done needs the settle **and** `MinTimeElapsed` (a sensorless
  move: `MinTimeElapsed` after its travel time), then withdraws the output
  when `ResetOnEndPos`; a timeout withdraws it when `ResetOnTimeout`. The
  interlock path is unchanged: a lost area interlock still withdraws both
  outputs and faults (this type has no HELD path and no `WithdrawOutputs`;
  neither is added here).
- **`PrepareRecipe` refuses (`CYL_CFG_INVALID`)** a non-zero
  `MinOutputTime` the move timeout cannot contain, a pulse as long as its
  period, `ResetOnEndPos` on a single-acting cylinder (withdrawing a
  spring-return coil at its end returns the cylinder), and - one rule
  stricter than the plan - pulsing unless **both** positions are sensed.
  With an unsensed end, "neither position confirmed" is also true at that
  end, so every stroke from it would pulse, and a pulsed stroke towards an
  unsensed end would invalidate the travel time the type completes on.
- **A defect found while adopting it.** A refused prepare left
  `_recipePrepared` as the previous accepted prepare had set it, over a
  staged record that was now the refused one: a `CommitRecipe` meant for
  the earlier prepare would have applied the refused record.
  `PrepareRecipe` now clears the mark first, as `FB_CylinderCM` does, and
  a test row commits after four refusals to prove nothing is applied.
- **Kept as `FB_CylinderCM` has it.** A timeout without `ResetOnTimeout`
  leaves the output at its last level, which during pulsing may be either;
  both types behave the same.
- **Upgrade cost.** Modules *minor* 0.15.0.0 (a persistent layout change).
  Core unchanged; no reason added. `ST_ConfigurableCylinderParCfg` records
  **stored** in a recipe provider are refused (`RECIPE_INVALID`) until
  saved again. Nothing outside TC3 carries the layout; the Siemens plan
  and AB census record the gap.
- **Tests.** Eight rows in `FB_ConfigurableCylinderCM_Tests`: settle and
  minimum output time gate Done, pulsing from the middle, a stroke from an
  end position is steady, end-of-move and timeout resets, the four
  refusals plus the commit-after-refusal, the declared defaults reproduce
  v1, and a stored v1 record refused through the probe
  `ST_ProbeConfigurableCylinderParCfgV1`.

Final: Core 0.26.4.0 / Modules 0.15.0.0 installed from an isolated
worktree; six `CheckAllObjects` clean (0 errors, 0 warnings); both lint
profiles, the tool tests, strict consistency and every AB/TIA replay and
contract gate green. On the isolated UmRT: aggregate 317/317 in 53 suites
and Press 9/9 in 2 suites. Scope and artifacts:
`Specification/Evidence/2026-11-02_TC3_GenericCM_ConfigurableCylinderTiming.md`.

## 172. The curve monitor (Modules 0.15.1.0, 2026-11-02)

L5 of the remaining-library plan. `FB_CurveMonitor` judges one measured
curve - force over stroke, pressure over time - against windows it must
pass through and envelopes it must stay on one side of. It is
owner-private like `FB_ValveDrive`: no module identity, no published
state, no I/O, and it raises nothing itself.

- **Use.** The owner embeds an `ST_CurveSpec` in its own `ParCfg`,
  validates it in `PrepareRecipe` with `M_Validate` (refusing with
  `CURVE_SPEC_INVALID`), calls `M_Begin` when the curve starts,
  `M_Sample(X, Y)` once per measured point and `M_Finish` when it ends.
  `M_Begin` copies the spec, so a recipe committed mid-curve cannot move
  this curve's verdict, and an invalid spec judges nothing and finishes
  NOK with `CURVE_SPEC_INVALID`. Samples outside `M_Begin..M_Finish` are
  ignored; `M_Finish` again returns the same result.
- **Online, no buffer.** Every rule is decided as the samples arrive:
  windows track inside/outside per sample, envelopes keep a segment cursor
  that moves with X, so a monotonic curve costs O(windows + envelopes) per
  sample. A window is judged on its samples - a curve sampled too sparsely
  to land one inside it misses it.
- **Windows.** Bounds are inclusive. `ANY_EDGE`/`ANY_EDGE` passes on one
  inside sample. A declared `EntryEdge` is the edge the outside-to-inside
  segment crosses last (the largest segment parameter among the bounds the
  outside sample violates), a declared `ExitEdge` the one the
  inside-to-outside segment crosses first; an exact corner goes to the
  first in `LEFT, RIGHT, BOTTOM, TOP` order. A curve that starts inside
  never crossed a declared entry, and one that ends inside never took a
  declared exit; both fail the window. The plan's names did not survive
  the gates: the members `Entry`/`Exit` became `EntryEdge`/`ExitEdge`
  (`EXIT` is reserved, lint rule C2), and the enum member `ANY` became
  `ANY_EDGE` - the compiler rejected `ANY`, IEC's generic-type keyword
  (C0368, then C0004 at every use), which C2 did not know. C2 now lists
  the IEC generic types (`ANY`, `ANY_INT`, ...), with a test, so the next
  one fails in seconds, not in XAE.
- **Envelopes.** `Upper` keeps the curve at or below the linear
  interpolation, otherwise at or above; outside the envelope's X span
  nothing is judged. The first violating sample's index is recorded per
  envelope.
- **Verdict.** `Complete` = the curve reached every window's `XMax` and
  every envelope's last X. OK only when complete, every window passed and
  no envelope cut; otherwise NOK naming the first failing rule -
  incomplete before window before envelope.
- **One addition to the plan's result: `DescriptionKey`**, the operator
  text of `Reason`, so every owner faults with `_M_FaultN(Result.Reason,
  Result.DescriptionKey)` instead of mapping four codes to four keys
  itself (§1.1 O1).
- **Validation** also refuses a spec of another `SchemaVersion`
  (`PL_Curve.SPEC_SCHEMA`), an edge value the type does not know (a stored
  record), and a spec with no rule at all - a check that checks nothing is
  a configuration mistake, not an OK.
- **Reasons 10901-10904** (`CURVE_WINDOW_VIOLATED`,
  `CURVE_ENVELOPE_VIOLATED`, `CURVE_INCOMPLETE` MED/PROCESS;
  `CURVE_SPEC_INVALID` MED/SYSTEM), registered to the helper and raised by
  its owner; catalogued (88 -> 92), registry row, operator text in English
  and Spanish, the generator expands `SPEC`. This allocates the last free
  CM block: a further CM type needs a Part I §8.8 registry amendment
  first.
- **Upgrade cost.** Modules *patch* 0.15.1.0 (additive); Core *patch*
  0.26.5.0 carries only the regenerated reason catalog. TIA: hash-only
  change, packages regenerated and verified; the Siemens plan and AB
  census record the helper as not carried.
- **Tests.** `FB_CurveMonitor_Tests`, eleven single-scan rows: spec
  validation (and an invalid spec finishing NOK), `ANY_EDGE` window pass
  and miss, declared entry/exit edges passing (`LEFT`->`RIGHT`,
  `BOTTOM`->`TOP`), a wrong entry edge and a curve starting inside, a
  wrong exit edge and a curve ending inside, an upper envelope cut on its
  second segment by interpolation, a lower envelope, an incomplete curve
  (and one with no sample), verdict precedence, and `M_Begin` resetting
  the previous curve.

Final: Core 0.26.5.0 / Modules 0.15.1.0 installed from an isolated
worktree; six `CheckAllObjects` clean (0 errors, 0 warnings); both lint
profiles, the tool tests, strict consistency and every AB/TIA replay and
contract gate green; HMI analyzer clean, 622 passed / 12 skipped on
Flutter 3.44.6. On the isolated UmRT: aggregate 328/328 in 54 suites and
Press 9/9 in 2 suites. Scope and artifacts:
`Specification/Evidence/2026-11-02_TC3_GenericCM_CurveMonitor.md`.

## 173. The curve record and the HMI Curve tab (Modules 0.15.2.0, 2026-11-02)

L6 of the remaining-library plan: the last judged curve becomes visible to
the generic HMI without a per-station screen.

- **PLC.** `ST_CurveRecord` (`SampleCount`, `Truncated`,
  `Samples[1..PL_Curve.MAX_SAMPLES]`, `Spec`, `Result`) and
  `FB_CurveMonitor.M_Record(Target)`. The helper now keeps the first 256
  samples while it judges; later samples are still judged
  (`Result.Samples` counts all, an envelope cut past the buffer still
  fails the curve) and only `Truncated` says they are missing from the
  record. `M_Record` copies the last **finished** curve and is refused
  while a curve runs or before the first finishes, so a published record
  never shows half a curve; rows past `SampleCount` are cleared, and a
  curve judged against an invalid spec is recorded with an empty spec
  rather than a stale one. The owner publishes the record as
  `OutImm.Curve` and calls `M_Record` once per curve after `M_Finish`.
- **HMI.** `CurveFacet` (with `CurvePoint`, `CurveWindow`, `CurveEnvelope`
  and `CurveEdge`, whose ordinals are `E_CurveEdge`'s) on
  `ModuleNode.curve`. The read tier puts everything under `Curve` on
  demand - a record is several thousand leaves - except `SampleCount`, a
  live leaf, so the tab exists before its record has been read (the §3.13
  flow chart's pattern). The new built-in `curve` tab kind (appended;
  kinds persist by name) appears for any module publishing the record,
  demands `{Curve}` only while it is open, and draws the windows in their
  pass/fail colour, the envelopes, the samples, the first envelope cut and
  the PLC's verdict with its reason text. Nothing is recomputed, nothing
  is written. Geometry is fractions of the chart box; every colour is a
  semantic token (`CurvePalette`) measured at 3:1 against the card in
  every theme. The simulator's `PackerC.Sealer` publishes a synthetic
  sealing-force curve.
- **Cross-binding.** The strict read-surface gate requires every path the
  HMI reads to be published by the AB projection or declared absent:
  `OutImm/Curve` is declared absent (no AB type publishes a curve record;
  the helper is a recorded AB gap). The mapper reads the record through
  the file's own binding idiom (`final curve = '$base/OutImm/Curve'`,
  `_indexedPrefix`, `_arrayElement`), which is what lets that gate resolve
  each read.
- **Upgrade cost.** Modules *patch* 0.15.2.0 (additive: a new record type,
  a method and a constant; the helper's own state grows by the sample
  buffer). Core unchanged. The HMI tab is additive; a stored layout that
  predates it gets the tab appended, as for every built-in tab.
- **Tests.** PLC: two rows in `FB_CurveMonitor_Tests` (the record copies
  the finished curve, is refused before and during one, and clears the
  previous curve's rows; a truncated record keeps the whole verdict). HMI:
  a field-tier row, a mapper row (length only, then the read record, then
  no record), widget rows for every theme, the not-yet-read and
  unpublished states and the tab's demand set, and a contrast row for
  every chart role.

Final: Core 0.26.5.0 / Modules 0.15.2.0 installed from an isolated
worktree; six `CheckAllObjects` clean (0 errors, 0 warnings); both lint
profiles, the tool tests, strict consistency and every AB/TIA replay and
contract gate green; HMI analyzer clean, 628 passed / 12 skipped on
Flutter 3.44.6 (three earlier full runs each failed a wall-clock test in
`opcua_freshness_test` under load, which the baseline without this change
reproduces; it passes alone). On the isolated UmRT: aggregate 330/330 in
54 suites and Press 9/9 in 2 suites. Scope and artifacts:
`Specification/Evidence/2026-11-02_TC3_GenericCM_CurveRecord.md`.

## 174. The robot CM completed (Modules 0.16.0.0, 2026-11-03)

Closes the gaps the robot user-channel audit named
(`Specification/Reports/TC3_ROBOT_USER_CHANNEL_AUDIT_2026-11-02.md`) and
builds two of the three items Annex I had left unbuilt; the bounded vision
offset (I.8a) stays deferred until a vision path needs it.

- **The mode request half (I.4a(a)).** `ParCfg` v2 appends `DefaultMode`
  (the most restrictive mode this cell supports, `MANUAL_REDUCED` unless
  configured), `ModeTimeout` and `JogTimeout`. The default is requested at
  link-up and whenever a reported mode is lost; `REQUEST_MODE`
  (`ParCmd.Mode`) asks for another and completes only when the controller
  REPORTS it, faulting `ROBOT_MODE_NOT_PERMITTED` after `ModeTimeout`;
  `OutImm.RequestedMode` stands beside `ActualMode` so an ungranted
  request is visibly ungranted.
- **Configuration validation.** `PrepareRecipe` refuses a non-positive,
  inverted or over-100 speed band, a ceiling outside 0..100, an UNKNOWN or
  unknown default mode and any zero timeout with the new
  `ROBOT_CFG_INVALID` (10316); `Setup` runs it, as for every CM.
- **The §9 safety alias.** `SetSafetyPermit(Permit, DescriptionKey)`,
  read-only, deliberately separate from `Intlk` (a lost application
  permissive HOLDS on path; a lost safety alias does not). Losing it stops
  a running command first, then asks power off on the falling edge and
  every 500 ms while power is still reported; regaining it re-enables
  nothing. `POWER_ON` and motion are refused without it. Raises
  `ROBOT_SAFETY_DROPPED` (10307, registered in Annex I, now in
  `PL_ModuleReasons`, SAFETY category, never shelvable).
- **Held jog.** `JOG_POS`/`JOG_NEG` held commands (§7.6.1) in the manual
  catalog, accepted only in a manual mode the controller reports, only
  with the enabling device held (no station opt-out, unlike the axis),
  never while a command runs, never through a lost interlock or safety
  alias; started once and stopped with `Abort` when the request stops
  arriving (`JogTimeout`). `SetJogSelection(Mode, Axis)` picks frame and
  axis; `OutImm.Jogging`, `JogStopReason`, `JogMode`, `JogAxis` publish
  it.
- **`SET_PAYLOAD`, the arm-power fact and path progress.** `SET_PAYLOAD`
  selects the load case by ID; `I_RobotConnector` gains `ArmPowerOn` and
  `PathIndex` (last completed point of the current or most recent
  `RUN_PATH`), published in `OutImm`. An aborted path is continued by a
  DELIBERATE `RUN_PATH` from `PathIndex + 1`, never automatically.
- **The user channel.** `M_DeclareUserSignal(Index, Key, ToRobot, Kind)`
  declares up to `PL_Robot.MAX_USER_SIGNALS` (8) signals, published
  read-only in `OutImm.UserSignals` with validity; `M_WriteUserSignal`
  writes a declared to-robot signal and refuses a value that does not fit
  its kind. The connector gains `WriteUserSignal`/`UserSignal`; it is not
  a robot request and never touches `LastResult`. Annex I states the rule
  that it carries no positions, modes, speeds or "go" requests.
- **Defects found while finishing, and fixed.**
  - *Abort did not stop the arm.* The type had no `OnAbort`, so an aborted
    command left the module ABORTED with the robot still moving. `OnAbort`
    now sends `Abort` to the connector.
  - *Refusal adoption compared against a stale snapshot.* The CM compared
    the connector's `LastResult` with the value at command start: an
    accepted command after a refused one faulted with a zero code, and a
    repeated refusal with the same code read as "unsupported command". The
    contract is now explicit (I.3): `LastResult` describes the most recent
    request - empty when accepted, its reason when refused - and the CM
    adopts any reason after the accept. Unsupported commands are refused
    before anything is issued.
  - *The TCP connector could never run a move.* Step 10 sends the speed
    and then the move in one scan, and the connector allowed one
    outstanding request, so the move was always refused - as a lost link.
    The heartbeat's status poll caused the same refusal intermittently.
    The connector now has a one-deep queue (a request arriving while the
    slot is taken waits and is sent when the reply lands; a second waiting
    request is still refused), `Abort` empties the queue first, and every
    refusal leaves a reason (mode UNKNOWN, jog outside manual, resume off
    path, speed out of range used to refuse silently).
  - `OutImm.SpeedScale` published the requested scale; it now publishes
    the one sent.
- **Wire protocol (TCP connector).** The status poll carries the to-robot
  user values (`STA,<out1>,...`); the reply appends
  `<power>,<pathIdx>,<in1>,...`. A server that predates them omits them,
  which reads as power not reported, no path progress and inputs 0. Whole
  numbers go on the wire without a fraction (`SPD,50`).
- **Improvement candidates reviewed.** A commercial robot-integration
  package was reviewed for ideas. Path progress was adopted now; the rest
  are listed with a disposition in the generic-CM audit plan (capability
  discovery, brake test and safe reference run, a fast-input position
  latch, never-taught point refusal, tool/frame consistency, declared
  manual moves, controller identity). Continuous streaming and PLC-side
  kinematics are not adopted: they put coordinates into PLC code (I.1).
- **Upgrade cost.** Modules *minor* 0.16.0.0: `ST_RobotParCfg` v2,
  `E_RobotCommand` appends, `ST_RobotParCmd`/`ST_RobotOutImm` grow, and
  `I_RobotConnector` gains members - a third-party connector must
  implement `ArmPowerOn`, `PathIndex`, `WriteUserSignal` and `UserSignal`.
  Core *patch* 0.26.6.0 carries the regenerated catalog (92 -> 94). TIA:
  hash-only, regenerated.
- **Tests.** `FB_RobotCM_Tests` 8 -> 21 and `FB_RobotConnector_Tests` 6 ->
  9 (the existing CM rows now run as an auto-only cell, which is what
  their fixtures assumed): default and requested modes and an ungranted
  request; configuration refusal; `SET_PAYLOAD`; the safety stop with no
  re-enable; `POWER_ON` refused without the alias; abort stopping the arm;
  the jog's gates and freshness; jog selection; user signals; arm power
  and applied speed; a repeated refusal keeping its reason; an aborted
  path continued deliberately; on the wire, power, path index and inputs
  decoded, outputs riding the status poll, and a speed and a move in one
  scan both reaching the wire.

Final: Core 0.26.6.0 / Modules 0.16.0.0 installed from an isolated
worktree; six `CheckAllObjects` clean (0 errors, 0 warnings); both lint
profiles, the tool tests, strict consistency and every AB/TIA replay and
contract gate green; HMI analyzer clean, 628 passed / 12 skipped on
Flutter 3.44.6. On the isolated UmRT: aggregate 346/346 in 54 suites and
Press 9/9 in 2 suites. Scope and artifacts:
`Specification/Evidence/2026-11-03_TC3_RobotCompletion.md`.

## 175. The robot backlog: capabilities, routines, untaught points, manual moves (Modules 0.17.0.0, 2026-11-03)

Builds four items of the robot backlog in the generic-CM audit plan (§12:
R2, R3, R5, R7), all ideas reviewed in a commercial robot-integration
package and rewritten against Annex I.

- **Capabilities (R2).** `I_RobotConnector` gains `Capabilities :
  ST_RobotCapabilities` - the connected controller's own answer: which
  commands it offers (bit n = `E_RobotCommand` n), how many axes a jog may
  address, how many user-signal slots it carries, and `Reported`.
  `FB_RobotCM` publishes it read-only in `OutImm.Capabilities` and refuses
  a command that is not offered before anything is sent
  (`UNSUPPORTED_COMMAND`, `std.error.robotCommandNotOffered`); it starts
  no jog that is not offered, refuses a jog axis or a user-signal write
  beyond what the controller carries, and marks such a declared signal
  invalid. An unreported set filters nothing: before the controller has
  said, its own refusal is the authority, so a server that predates the
  question behaves as before. The simulated connector reports
  `Offered`/`JogAxes` inputs; the TCP connector asks `CAP` once per
  session (housekeeping like the poll: it never touches `LastResult` or
  `MotionBusy`, and waits for a free slot). Not done: hiding an unoffered
  command in the HMI. The catalog is static configuration served by the
  manifest (§3.9, §3.10.2), so it stays listed and is refused with that
  reason.
- **The controller's routines (R3), on a secondary interface.** Annex I.5b
  catalogues the brake test as a capability group and requires such groups
  to be a narrow secondary interface, never a widening of
  `I_RobotConnector`. So `I_RobotRoutines` (`RunBrakeTest`,
  `RunSafeReference`, `BrakeTestDue`, `SafeReferenceDue`) is implemented
  by both connectors and found by the CM at `Setup` with
  `__QUERYINTERFACE`; without it the routines are not offered and nothing
  is due. The demands are published as `_M_State` flags 1 and 2
  (unconditional every scan) and in `OutImm`;
  `BRAKE_TEST`/`SAFE_REFERENCE` are appended commands and one-press
  catalog entries. They are motion (link, safety alias, `AUTO_REMOTE`,
  reference) but carry no speed scale - the controller paces its own
  validated routine - and take `HomeTimeout`. A routine passes only when
  the controller withdraws its demand; ending with the demand standing
  faults the new `ROBOT_ROUTINE_FAILED` (10317, HIGH, SAFETY, never
  shelvable). The CM invents no refusal of its own while a demand stands:
  that is the controller's decision.
- **No move to a point that was never taught (R5).** `ROBOT_POINT_UNKNOWN`
  (10302, registered in Annex I) is now raised. The CM refuses a
  point-addressed command naming no point (ID 0, or no `FromId` for
  `MOVE_TEMPLATE`) before anything is sent; an ID the controller never
  taught is the controller's to refuse with the same reason. The simulated
  connector, which synthesizes a pose for any ID, holds IDs
  `1..TaughtPoints` (default 999) and refuses the rest; the TCP connector
  classifies the controller code `UNKNOWN_ID` as 10302 and keeps the
  controller's text verbatim.
- **Declared manual moves (R7).** `M_DeclareManualMove(Slot, PointId,
  LabelKey)` declares up to `PL_Robot.MAX_MANUAL_MOVES` (8) one-press
  moves, once after `Setup`, into the §7.6.1 catalog under catalog value
  `PL_Robot.MANUAL_MOVE_BASE + Slot` (clear of every command). A press
  runs `MOVE_FROM_AREA` to the declared point, so the route starts
  wherever the arm stands, through every gate a program command meets, at
  `ParCfg.SpeedScaleMin` under the mode ceiling - a screen press carries
  no speed, and the program's `ParCmd.SpeedScale` is not inherited.
  Catalog budget: 2 held jogs + 2 routines + 8 moves = `MAX_CMD_CATALOG`
  (12).
- **Defect found while doing it: the TCP connector could still refuse the
  move.** §174's one-deep queue covered a free slot: the speed went out
  and the move waited. But when the heartbeat's status poll - or now the
  link-up `CAP` - holds the slot at the very scan the CM sends the speed
  and the move, the speed took the only waiting place and the move was
  refused as a lost link, intermittently. The queue is now two deep
  (oldest first, a third request refused, `Abort` still empties it first),
  and a request joins the queue whenever others wait, so nothing
  overtakes. Row `Speed_then_move_in_one_scan_both_reach_the_wire` now
  runs with `CAP` on the wire.
- **Wire protocol.** The status reply gains `<due>` after `<pathIdx>` (bit
  1 brake test, bit 2 safe reference) and the user inputs move to field 18
  on; a server that omits it reads as nothing due. New requests `CAP`
  (`CAP,OK,<commands>,<jogAxes>,<userSignals>`), `BRK`, `SRF`.
- **Upgrade cost.** Modules *minor* 0.17.0.0: `I_RobotConnector` gains
  `Capabilities` (a third-party connector must implement it;
  `I_RobotRoutines` is optional), `E_RobotCommand` and `E_RobotSimFault`
  append, `ST_RobotOutImm` grows. Core *patch* 0.26.7.0 carries the
  regenerated catalog (94 -> 96). TIA: the example outputs refreshed for
  the rationalized severities only.
- **Tests.** `FB_RobotCM_Tests` 21 -> 26 and `FB_RobotConnector_Tests` 9
  -> 11: a command and a jog not offered refused before issuing; a missing
  and an untaught point refused with nothing moving; a due brake test
  published as a state flag and withdrawn by running it; a routine leaving
  its demand standing faulting 10317; a declared move's bounds, catalog
  entry and one press running it to its point at the slowest speed; on the
  wire, the offer asked once and decoded with the routine demands, and an
  untaught point carrying its own reason while a refused `CAP` filters
  nothing. Every existing wire row now answers `CAP` and the moved
  user-input field.

Final: Core 0.26.7.0 / Modules 0.17.0.0 installed from an isolated
worktree; six `CheckAllObjects` clean (0 errors, 0 warnings) after two
compiler findings in this step (an IEC apostrophe written `''` in test
messages; `C0195`, then `C0032`, on the TCP connector's due-bit test, now
a `DWORD`); both lint profiles, the tool tests, strict consistency and
every AB/TIA replay and contract gate green; HMI analyzer clean, 628
passed / 12 skipped on Flutter 3.44.6. On the isolated UmRT, after the
trial licence was renewed: aggregate 353/353 in 54 suites and Press 9/9 in
2 suites. Scope and artifacts:
`Specification/Evidence/2026-11-03_TC3_RobotBacklog.md`.

## 176. Release the shared maintenance reason and the Modules audit fixes (Core 0.26.8.0 / Modules 0.18.0.0, 2026-11-10)

Executes `Specification/Reports/TC3_HANDOVER_PROMPT_2026-11-11.md` against
main `4af593db7`. Siemens P8 added `CONTROLLER_MAINTENANCE_DEMANDED` (22)
and regenerated the shared reason catalog (97 entries). This step updates
release metadata and consumer pins and corrects the runtime regressions below;
it does not hand-edit generated sources.

- Core is a patch: 0.26.7.0 -> 0.26.8.0, an additive shared reason.
- Modules is minor: 0.17.0.0 -> 0.18.0.0. A revision-only rebuild would hide
  the observable changes already merged in `78115a2b0`: `Commands` in
  `ST_RobotCapabilities` widened from DWORD to LWORD, changing the published
  layout and connector return contract; real robots now require an explicit
  safety alias; pulsed cylinder outputs are withdrawn on travel timeout.
  Part II §2.2 requires a minor step for a changed published layout. Rebuild
  third-party robot connectors and typed clients and supply the safety alias.
  No ParCfg schema or retained-data layout changes in this release step.
- The existing Core reason 22 and the TIA V3 contract keep their identities.
  The Siemens and Allen-Bradley trees are unchanged by this handover.
- Beckhoff documents `_AppInfo.ActivePlcForces` and `ActiveIoForces` from
  4026.21. The proposed runtime annunciation is a separate owner decision;
  this release does not infer force activity or add the health condition.

- The first aggregate runtime attempt exposed a defect in the audit follow-up's
  test: the safety-alias row allocated a robot CM (39,712 bytes) and connector
  (4,288 bytes, measured from the generated TMC) as method locals. The PLC
  task raised 0xc00000fd (stack overflow), disappeared from ADS and produced
  no TcUnit summary; that attempt is a failed gate even though the wrapper
  exited zero. Both fixtures now live in the suite's instance storage, and
  the row calls Cyclic before checking its derived OutImm.SafetyPermit.
  This is test-only; neither the task stack nor a production gate is relaxed.

- The next aggregate completed with 351 successful / 2 failed. The cylinder
  row proved that WithdrawOutputs' added M_Reset erased the pulse selection,
  so RestoreOutputs could not resume pulsing. Remove that reset only: the
  withdrawal latch still forces both outputs off; timeout resets remain.
- The robot row proved that the real-connector fixture received the simulation
  default. An empty I_SimulatedRobotConnector was not a discriminating
  capability on this compiler. It now has a read-only Simulated property;
  FB_SimRobotConnector returns TRUE and Setup consumes the value. The row
  directly checks both positive and negative interface queries. Implementers
  of this optional simulation interface must supply the getter. The primary
  I_RobotConnector contract is unchanged by this repair.

Measured acceptance is recorded in the dated handover evidence and receipt.

The following 352/353 attempt left the robot fixture's own override scenario
as its remaining failure. The row now explicitly starts and ends with that
override disabled through the standard API, and asserts withdrawal removes
permission; its no-alias and both interface assertions are preserved.

Final: Core 0.26.8.0 / Modules 0.18.0.0 installed from the isolated checkout;
six CheckAllObjects TRUE with 0 compiler errors / 0 warnings. One PressTests
COM startup failure (0x80080005) was retried from a clean XAE process; the test
check's benign Unknown TMC file version row is retained verbatim. Both lint
profiles are clean (469 files), 79 TC3 tool tests OK (one skip), strict
consistency 0/0 and its 36 tests OK, reason catalog --check clean (97 entries).
On UmRT_Default 192.168.1.6.1.1:851 with boot autostart disabled: aggregate
353/353 in 54 suites and Press 9/9 in two, both independently validated.
PressTests is stopped. Both documented native force flags read FALSE over ADS;
adding the maintenance alarm source remains the handover's owner decision.
Evidence: Specification/Evidence/2026-11-10_TC3_MaintenanceHandover.md and its
SHA-256 receipt. No AB/TIA or HMI lockfile changes; no commit or push.


## 177. Native engineering-force maintenance notice (2026-11-11)

Owner approved the handover review's detector proposal. Core 0.26.9.0 appends
MaintenanceAvailable/MaintenanceDemanded to the adapter input record; existing
producers default to unavailable. This record is neither retained nor the
published SystemHealth status, so the additive change is a patch under TC3 §2.2.
Modules 0.18.0.1 is a contract-neutral rebuild against that Core.

FB_TcSystemHealthProbe samples the native PlcAppSystemInfo ActivePlcForces and
ActiveIoForces fields (introduced in 3.1.4026.21). Implementation conditional
pragmas query both declared members; an older target declaration yields explicit
unavailability without a project define or extra scan call. The existing Unit
SetSystemHealth path carries the sample to FB_SystemHealthPublisher, which owns
one deduplicated LOW/SYSTEM/AUTO_RESET event, reason 22, using the registered
non-shelvable key. Demand/availability/configuration clearing closes the event.
The notice leaves Healthy unchanged and adds no Start gate or force-write path.

The Core health port generator accepts its existing named Boolean condition
shape unchanged. Shared input additions and authoritative source hashes require
regenerating the Siemens declaration/Press packages and the type-map field pin;
the S7 probe keeps its existing dedicated maintenance source. Frozen V3 is not
changed. The previous accepted source baseline is preserved separately before
these edits; dated handover evidence and its receipt remain immutable.

Two TcUnit rows cover availability, repeated demand, registered metadata,
non-shelvability, nonblocking behavior, automatic close/history/re-raise and the
native probe mapping. Dated follow-up evidence records the measured gates.
