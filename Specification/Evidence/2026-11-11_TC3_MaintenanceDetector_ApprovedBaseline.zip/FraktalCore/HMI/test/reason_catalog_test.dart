import 'package:flutter_test/flutter_test.dart';
import 'package:fraktal_hmi/localization/default_catalogs.dart';
import 'package:fraktal_hmi/localization/reason_catalog.g.dart';

void main() {
  test('generated reason codes resolve to standard localization keys', () {
    expect(generatedReasonSymbolByCode[2001], 'TIMEOUT');
    expect(generatedReasonSymbolByCode[10112], 'CYL_WORK_NOT_REACHED');
    expect(reasonDescriptionKey(2001, 'project.error.moreSpecific'),
        'std.reason.2001');
    expect(standardEnglish['std.reason.2001'], 'Timeout.');
    expect(standardEnglish['std.reason.10112'], 'Cylinder work not reached.');
  });

  test('unregistered project codes retain the PLC diagnostic fallback', () {
    expect(reasonDescriptionKey(0, 'project.error.none'), 'project.error.none');
    expect(reasonDescriptionKey(19999, 'project.error.custom'),
        'project.error.custom');
  });

  test('every generated reason has a standard English fallback', () {
    // This pin was already stale before the §3.8b reasons were added (61 vs the
    // 74 the catalog then held): a count assertion nobody updates stops being a
    // check. 77 = 74 + CONFIG_RESTORE_LOST, CONFIG_PERSIST_FAILED,
    // CONFIG_SET_REJECTED, EVENT_CONFIG_SET_APPLIED, minus the retired
    // AXIS_TEACH_LOST, which the framework band now owns (§8.8). 78 adds
    // NOK_LIMIT_REACHED (§3.16.5). 83 adds the analog input CM block
    // 10701-10705 (AI_UNDER_RANGE..AI_NOT_STABLE). 85 adds the analog output
    // CM block 10801-10802 (AO_TARGET_OOR, AO_CFG_INVALID). 88 adds the axis
    // depth block 10207-10209 (AXIS_POSITION_UNDECLARED, AXIS_PARAM_OOR,
    // AXIS_CFG_INVALID). 92 adds the curve monitor block 10901-10904
    // (CURVE_WINDOW_VIOLATED..CURVE_SPEC_INVALID). 94 adds the robot's
    // ROBOT_SAFETY_DROPPED (10307, registered earlier, raised now) and
    // ROBOT_CFG_INVALID (10316). 96 adds ROBOT_POINT_UNKNOWN (10302, registered
    // earlier, raised now) and ROBOT_ROUTINE_FAILED (10317). 97 adds the
    // controller's own maintenance demand, CONTROLLER_MAINTENANCE_DEMANDED (22).
    expect(generatedReasonSymbolByCode, hasLength(97));
    for (final code in generatedReasonSymbolByCode.keys) {
      expect(standardEnglish['std.reason.$code'], isNotNull,
          reason: 'missing fallback for reason $code');
      expect(standardEnglish['std.reason.$code.consequence'], isNotNull,
          reason: 'missing consequence for reason $code');
      expect(generatedReasonPriorityByCode[code], inInclusiveRange(0, 2));
      expect(generatedReasonCategoryByCode[code], inInclusiveRange(0, 2));
      expect(generatedReasonShelvableByCode[code], isNotNull);
    }
  });

  test('alarm metadata is actionable while lifecycle entries remain events',
      () {
    expect(reasonActionKey(2001), 'std.reason.2001.action');
    expect(
        standardEnglish[reasonActionKey(2001)], contains('awaited condition'));
    expect(reasonActionKey(2024), isEmpty);
    expect(generatedReasonShelvableByCode[2024], isFalse);
    expect(generatedReasonSymbolByCode[2901], 'TEST_FAULT');
  });
}
