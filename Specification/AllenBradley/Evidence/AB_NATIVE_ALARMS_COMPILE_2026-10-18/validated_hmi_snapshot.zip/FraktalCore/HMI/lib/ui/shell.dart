/// Responsive app shell: on wide screens the tree is a persistent left panel; on
/// narrow (phone/Android portrait) it becomes a Drawer. Global alarm banner and
/// connection chip are always visible; the plant overview is the landing screen.
library;

import 'package:flutter/material.dart';
import '../domain/types.dart';
import '../state/app_state.dart';
import 'login_dialog.dart';
import 'module_detail.dart';
import 'overview_and_indicators.dart';
import 'tree_menu.dart';
import 'fieldbus_tree.dart';
import 'view_switch.dart';
import 'mode_bar.dart';
import 'release_panel.dart';
import 'global_reset_button.dart';
import 'settings_dialog.dart';
import 'app_theme.dart';
import '../localization/localized_text.dart';

class Shell extends StatelessWidget {
  final AppState app;
  final VoidCallback? onEditUnitSelection;
  final VoidCallback? onEditConnection;
  final VoidCallback? onEditAppearance;
  final VoidCallback? onEditAccess;
  final ValueChanged<String>? onLanguageChanged;
  const Shell({
    super.key,
    required this.app,
    this.onEditUnitSelection,
    this.onEditConnection,
    this.onEditAppearance,
    this.onEditAccess,
    this.onLanguageChanged,
  });

  static const _breakpoint = 900.0;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final wide = box.maxWidth >= _breakpoint;
      final Widget body;
      if (app.showFieldbus) {
        body = FieldbusTree(app: app);
      } else if (app.showOverview) {
        body = PlantOverview(app: app);
      } else {
        body = ModuleDetail(app: app);
      }
      return Scaffold(
        appBar: _appBar(context, wide),
        drawer:
            wide ? null : Drawer(child: SafeArea(child: TreeMenu(app: app))),
        body: Column(children: [
          // §7.5.2 above §8.3: the gate banner is the LOWEST priority message
          // the station raises, so it must not compete with the alarm banner for
          // the same strip - it would always lose, on exactly the builds where
          // it matters most.
          EngineeringModeBanner(app: app),
          // §3.8b above §8.3 for the opposite reason to the gate banner: a
          // configuration that will not survive the next restart is not an
          // active process alarm and will never appear in that list, so the
          // alarm strip cannot carry it at all.
          ConfigDurabilityBanner(app: app),
          GlobalAlarmBanner(app: app),
          if (!app.showFieldbus && !app.showOverview) ReleasePanel(app: app),
          Expanded(
            child: app.showFieldbus
                ? body
                : wide
                    ? Row(children: [
                        TreeMenu(app: app),
                        const VerticalDivider(width: 1),
                        Expanded(child: body),
                        if (!app.showOverview) ...[
                          const VerticalDivider(width: 1),
                          ModeBar(app: app),
                        ],
                      ])
                    : (app.showOverview
                        ? body
                        : Row(children: [
                            Expanded(child: body),
                            const VerticalDivider(width: 1),
                            ModeBar(app: app),
                          ])),
          ),
        ]),
      );
    });
  }

  PreferredSizeWidget _appBar(BuildContext context, bool wide) {
    final s = app.session;
    final metrics = ControlScaleScope.of(context);
    final compactActions = !wide && metrics.touchTarget > 48 &&
        MediaQuery.sizeOf(context).width < metrics.touchTarget * 6 + 120;
    return AppBar(
      title: Row(children: [
        Flexible(
          child: InkWell(
            onTap: app.openOverview,
            child: const LText('Fraktal HMI',
                maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
        ),
      ]),
      actions: [
        ConnectionChip(state: app.link),
        if (compactActions)
          PopupMenuButton<String>(
            key: const Key('shell-more-actions'),
            tooltip: context.tr('std.nav.more'),
            child: SizedBox.square(dimension: metrics.touchTarget,
              child: Icon(Icons.more_vert, size: metrics.iconSize)),
            itemBuilder: (_) => [
              PopupMenuItem(value: 'view', height: metrics.touchTarget,
                child: LText(app.showFieldbus ? 'Show modules' : 'Show fieldbus')),
              PopupMenuItem(value: 'overview', height: metrics.touchTarget,
                child: const LText('std.nav.overview')),
              PopupMenuItem(value: 'settings', height: metrics.touchTarget,
                child: const LText('std.settings.title')),
            ],
            onSelected: (action) {
              switch (action) {
                case 'view': app.setFieldbusView(!app.showFieldbus);
                case 'overview': app.openOverview();
                case 'settings': _showSettings(context);
              }
            },
          )
        else if (wide)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1),
            child: ViewSwitch<bool>(
              options: const [
                ViewSwitchOption(
                    value: false,
                    icon: Icons.account_tree,
                    label: 'Modules'),
                ViewSwitchOption(
                    value: true, icon: Icons.lan_outlined, label: 'Fieldbus'),
              ],
              value: app.showFieldbus,
              onChanged: app.setFieldbusView,
            ),
          )
        else
          IconButton(
            tooltip:
                context.tr(app.showFieldbus ? 'Show modules' : 'Show fieldbus'),
            icon: Icon(
                app.showFieldbus ? Icons.account_tree : Icons.lan_outlined),
            onPressed: () => app.setFieldbusView(!app.showFieldbus),
          ),
        const SizedBox(width: 8),
        if (!compactActions) IconButton(
          tooltip: context.tr('std.nav.overview'),
          icon: const Icon(Icons.dashboard_outlined),
          onPressed: app.openOverview,
        ),
        // One settings entry consolidates theme, language, keyboard, and the
        // admin connection/unit-edit flows (declutters the bar; Core O9).
        if (!compactActions) IconButton(
          key: const Key('settings'),
          tooltip: context.tr('std.settings.title'),
          icon: const Icon(Icons.settings_outlined),
          onPressed: () => _showSettings(context),
        ),
        if (s.level == AccessLevel.none && wide)
          TextButton.icon(
              onPressed: () => showLoginDialog(context, app),
              icon: const Icon(Icons.login),
              label: const LText('Login'))
        else if (s.level == AccessLevel.none)
          IconButton(
            tooltip: context.tr('std.login.title'),
            onPressed: () => showLoginDialog(context, app),
            icon: const Icon(Icons.login),
          )
        else if (wide)
          TextButton.icon(
            onPressed: () =>
                app.repo.logout(app.rootOf(app.selectedPath ?? '')?.path ?? ''),
            icon: const Icon(Icons.logout),
            label: LText('${s.user} (${s.level.name})'),
          )
        else
          IconButton(
            tooltip: context.tr('Logout {user} ({level})', {
              'user': s.user,
              'level': context.tr('std.access.${s.level.name}'),
            }),
            onPressed: () =>
                app.repo.logout(app.rootOf(app.selectedPath ?? '')?.path ?? ''),
            icon: const Icon(Icons.logout),
          ),
        // §8.3(b) fault clear — fixed upper-right position, right of login.
        GlobalResetButton(app: app),
        const SizedBox(width: 8),
      ],
    );
  }

  void _showSettings(BuildContext context) => showSettingsDialog(context, app,
    onEditConnection: onEditConnection,
    onEditUnitSelection: onEditUnitSelection,
    onEditAppearance: onEditAppearance,
    onEditAccess: onEditAccess,
    onLanguageChanged: onLanguageChanged);
}
