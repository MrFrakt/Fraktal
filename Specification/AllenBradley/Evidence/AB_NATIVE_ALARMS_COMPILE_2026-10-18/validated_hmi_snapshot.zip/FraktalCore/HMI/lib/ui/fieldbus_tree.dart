/// Fieldbus topology tree (Core §10.5.1 / §3.13): the physical bus beside the
/// logical module tree. Nodes coloured by state (worst-in-subtree tints ancestors,
/// like the module tree); channels show live values — digital on/off, analog
/// value+unit.
///
/// Read/diagnostic by default. The output-force control is driven entirely by
/// the PLC's published `Forceable` capability, which is FALSE on every channel
/// unless the §7.5 OUTPUT_FORCING commissioning gate is active in the deployed
/// build — so on a production station this page renders no force affordance at
/// all, not a greyed one (§3.9). There is deliberately no HMI-side switch for
/// it: the capability is a property of the controller image, and a client that
/// could turn it on would be exactly the authority §7.5.1 denies.
///
/// Forcing goes AROUND a module; a manual command goes THROUGH it (§7.6.1). The
/// two must stay visually and functionally distinct, which is why the force
/// dialog states its scope rather than reading like an ordinary command.
library;

import '../localization/localized_text.dart';
import 'package:flutter/material.dart';
import '../domain/fieldbus.dart';
import '../domain/types.dart';
import '../state/app_state.dart';
import 'app_theme.dart';
import 'hmi_icons.dart';
import 'io_signal_led.dart';
import 'theme_chrome.dart';
import 'touch_text_field.dart';

Color nodeStateColor(BuildContext ctx, NodeState s) {
  switch (s) {
    case NodeState.operational:
      return okColor(ctx);
    case NodeState.safeop:
    case NodeState.preop:
    case NodeState.init:
      return warningColor(ctx); // degraded -> warning
    case NodeState.offline:
    case NodeState.fault:
      return Theme.of(ctx).colorScheme.error;
  }
}

String nodeStateLabel(NodeState s) => switch (s) {
      NodeState.operational => 'OP',
      NodeState.safeop => 'SAFEOP',
      NodeState.preop => 'PREOP',
      NodeState.init => 'INIT',
      NodeState.offline => 'OFFLINE',
      NodeState.fault => 'FAULT',
    };

class FieldbusTree extends StatefulWidget {
  final AppState app;
  const FieldbusTree({super.key, required this.app});
  @override
  State<FieldbusTree> createState() => _FieldbusTreeState();
}

class _FieldbusTreeState extends State<FieldbusTree> {
  final Set<String> _expanded = {};

  /// Selection is held as the node's NAME, not the [BusNode] object.
  ///
  /// Each refresh rebuilds the whole projection, so every node is a NEW
  /// instance. Holding the object pinned the pane to the snapshot taken when the
  /// row was tapped: node state and channel values froze until the user selected
  /// away and back (which re-captured a fresh object). `Name` is the stable
  /// identity here — it is the exact schematic tag (Core §10.5.1) and unique
  /// within the bus.
  String? _selectedName;

  @override
  void initState() {
    super.initState();
    // The fieldbus I/O tree is drill-down data (Core §3.13): the direct OPC UA
    // transport reads it only while this page is mounted, keeping ~thousands of
    // channel-state nodes off the always-on snapshot. A no-op on other transports.
    widget.app.repo.setFieldbusViewActive(true);
  }

  @override
  void dispose() {
    widget.app.repo.setFieldbusViewActive(false);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final roots = widget.app.fieldbus;
    if (roots.isEmpty) {
      // A discovered-but-not-yet-populated topology (direct OPC UA/ADS reads it
      // on demand when this page opens) shows a loading indicator; a transport
      // with no fieldbus at all shows the empty state.
      if (widget.app.repo.fieldbusExpected) {
        return const Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            SizedBox(
                width: 40,
                height: 40,
                child: CircularProgressIndicator(strokeWidth: 4)),
            SizedBox(height: 16),
            LText('std.fieldbus.loading'),
          ]),
        );
      }
      return const Center(
          child: Padding(
              padding: EdgeInsets.all(24),
              child: LText(
                  'No fieldbus diagnostics available on this transport.')));
    }
    BusNode? mappingFault;
    for (final root in roots) {
      if (!root.mappingValid) {
        mappingFault = root;
        break;
      }
    }
    return Column(children: [
      if (mappingFault != null)
        Container(
          width: double.infinity,
          color: Theme.of(context).colorScheme.errorContainer,
          padding: const EdgeInsets.all(12),
          // (the LText below already sets onErrorContainer explicitly)
          child: LText(
            mappingFault.mappingDiagnosticKey.isEmpty
                ? 'std.error.fieldbusMappingInvalid'
                : mappingFault.mappingDiagnosticKey,
            style: TextStyle(
                color: Theme.of(context).colorScheme.onErrorContainer,
                fontWeight: FontWeight.w700),
          ),
        ),
      Expanded(
        child: Row(children: [
          SizedBox(
            width: 340,
            child: Material(
              color: Theme.of(context).colorScheme.surfaceContainerLow,
              child: ListView(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  children: [
                    for (final n in roots) ..._nodeTiles(context, n, 0),
                  ]),
            ),
          ),
          const VerticalDivider(width: 1),
          Expanded(child: _channelPanel(context)),
        ]),
      ),
    ]);
  }

  List<Widget> _nodeTiles(BuildContext context, BusNode n, int depth) {
    final eff = n.effectiveState;
    final tint = nodeStateColor(context, eff);
    final ownBad = n.state != NodeState.operational;
    final open = _expanded.contains(n.name) || depth == 0;
    final selected = _selectedName == n.name;
    final tiles = <Widget>[
      InkWell(
        onTap: () => setState(() => _selectedName = n.name),
        child: Container(
          height: 40,
          margin: EdgeInsets.only(left: 4.0 + depth * 14, right: 4, bottom: 2),
          decoration: BoxDecoration(
            color: ownBad
                ? tint.withValues(alpha: 0.20)
                : (selected
                    ? Theme.of(context).colorScheme.secondaryContainer
                    : null),
            borderRadius: BorderRadius.circular(10),
            border: Border(
                left: BorderSide(
                    width: 4,
                    color: eff == NodeState.operational
                        ? (selected
                            ? Theme.of(context).colorScheme.primary
                            : Colors.transparent)
                        : tint)),
          ),
          child: Row(children: [
            if (n.children.isNotEmpty)
              IconButton(
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                iconSize: 18,
                icon: Icon(open ? Icons.expand_more : Icons.chevron_right),
                onPressed: () => setState(() =>
                    open ? _expanded.remove(n.name) : _expanded.add(n.name)),
              )
            else
              const SizedBox(width: 28),
            Icon(fieldbusIcon(n),
                size: 20, color: eff == NodeState.operational ? null : tint),
            const SizedBox(width: 6),
            Expanded(
                child: LText(n.name,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontWeight: ownBad ? FontWeight.w600 : FontWeight.w400,
                        // Selected rows are filled with secondaryContainer.
                        color: (!ownBad && selected)
                            ? Theme.of(context).colorScheme.onSecondaryContainer
                            : null))),
            if (!n.linkOk)
              Icon(Icons.link_off,
                  size: 16, color: Theme.of(context).colorScheme.error),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 6),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                  color: tint.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(6)),
              child: LText(nodeStateLabel(n.state),
                  style: TextStyle(
                      fontSize: 11, color: tint, fontWeight: FontWeight.w600)),
            ),
          ]),
        ),
      ),
    ];
    if (n.children.isNotEmpty && open) {
      for (final c in n.children) {
        tiles.addAll(_nodeTiles(context, c, depth + 1));
      }
    }
    return tiles;
  }

  /// Depth-first search for [name] in the CURRENT tree, so the detail pane always
  /// renders live data instead of the instance captured when the row was tapped.
  BusNode? _findNode(List<BusNode> roots, String name) {
    for (final root in roots) {
      if (root.name == name) return root;
      final hit = _findNode(root.children, name);
      if (hit != null) return hit;
    }
    return null;
  }

  Widget _channelPanel(BuildContext context) {
    final name = _selectedName;
    // Re-resolve every build: each refresh produces new BusNode instances.
    final n = name == null ? null : _findNode(widget.app.fieldbus, name);
    if (n == null)
      return const Center(child: LText('Select a node to see its I/O'));
    if (n.channels.isEmpty)
      return Center(
          child: LText('${n.name} — ${n.typeId}\nNo channels (coupler/master)',
              textAlign: TextAlign.center));
    return ListView(padding: const EdgeInsets.all(16), children: [
      LText('${n.name}  ·  ${n.typeId}',
          style: Theme.of(context).textTheme.titleMedium),
      if (n.descriptionKey.isNotEmpty) LText(n.descriptionKey),
      LText(
          '${n.address}  ·  ${nodeStateLabel(n.state)}${n.linkOk ? '' : '  ·  LINK DOWN'}',
          style: TextStyle(color: nodeStateColor(context, n.state))),
      const Divider(),
      for (final c in n.channels) _channelTile(context, c),
    ]);
  }

  Widget _channelTile(BuildContext context, IoChannel c) {
    final bosch = FraktalChromeTheme.of(context) != null;
    Widget value;
    if (!c.quality || (c.kind == ChannelKind.analog && !c.analogValue.isFinite)) {
      value = Tooltip(message: context.tr('std.io.unavailable'),
          child: const Text('—'));
    } else if (c.kind == ChannelKind.digital && bosch) {
      value = LText(c.boolValue ? 'std.io.on' : 'std.io.off');
    } else if (c.kind == ChannelKind.digital) {
      value = Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(
          color: c.boolValue
              ? const Color(0xFF2E7D32)
              : Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(6),
        ),
        child: LText(c.boolValue ? 'ON' : 'OFF',
            style: TextStyle(
                color: c.boolValue ? Colors.white : null,
                fontWeight: FontWeight.w600)),
      );
    } else {
      value = LText('${c.analogValue.toStringAsFixed(2)} ${c.unit}',
          style: Theme.of(context).textTheme.titleMedium);
    }
    final isOutput = c.dir == ChannelDir.output;
    final ownerRoot = widget.app.rootOf(c.modulePath);
    final canForce = isOutput &&
        c.forceable &&
        ownerRoot != null &&
        widget.app.permitsLocal(GatedAction.manual,
            forSession: ownerRoot.access ?? const AccessSession());
    return ListTile(
      dense: true,
      leading: bosch && c.kind == ChannelKind.digital
          ? IoSignalLed(direction: c.dir, value: c.quality ? c.boolValue : null, size: 20)
          : Icon(
        channelIcon(c.kind, c.dir),
        color: c.forced
            ? warningColor(context)
            : (c.quality && !c.faultActive
                ? null
                : Theme.of(context).colorScheme.error),
      ),
      title: Text(c.name,
          style: TextStyle(
              fontFamily: 'monospace',
              fontWeight: c.faultActive ? FontWeight.w700 : FontWeight.w500,
              color:
                  c.faultActive ? Theme.of(context).colorScheme.error : null)),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (c.descriptionKey.isNotEmpty) LText(c.descriptionKey),
        if (c.faultActive && c.diagnosticKey.isNotEmpty)
          LText(c.diagnosticKey,
              style: TextStyle(
                  color: Theme.of(context).colorScheme.error,
                  fontWeight: FontWeight.w600)),
        LText(
            '${c.address.isEmpty ? '' : '${c.address}  ·  '}${c.path}  ·  ${c.dir.name} ${c.kind.name}${c.forced ? ' · FORCED' : ''}${c.quality ? '' : ' · BAD QUALITY'}'),
      ]),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        value,
        if (c.modulePath.isNotEmpty)
          IconButton(
            tooltip: context.tr('std.fieldbus.openModule'),
            icon: const Icon(Icons.open_in_new, size: 18),
            onPressed: () {
              widget.app.select(c.modulePath);
              widget.app.setFieldbusView(false);
            },
          ),
        if (canForce)
          IconButton(
            tooltip: context.tr(c.forced
                ? 'std.fieldbus.forceClear'
                : 'std.fieldbus.forceTitle'),
            icon: Icon(c.forced ? Icons.lock_open : Icons.push_pin_outlined,
                color: c.forced ? warningColor(context) : null),
            onPressed: () => _force(context, c),
          )
        else if (isOutput && c.forceable)
          IconButton(
            tooltip: context.tr('std.fieldbus.forceWhyBlocked'),
            icon: const Icon(Icons.lock_outline, size: 18),
            onPressed: ownerRoot == null
                ? () => _snack(context, 'std.fieldbus.forceNoRoot')
                : () => widget.app.showReleaseReportAction(ownerRoot.path,
                    GatedAction.manual, 'std.fieldbus.forceBlocked'),
          ),
        // inputs are read-only: no force control (output-only rule, §10.5.1)
      ]),
    );
  }

  Future<void> _force(BuildContext context, IoChannel c) async {
    final root = widget.app.rootOf(c.modulePath)?.path;
    if (root == null) {
      _snack(context, 'std.fieldbus.forceNoRoot');
      return;
    }
    if (c.forced) {
      final ok = await widget.app.repo.forceChannel(root, c.path, force: false);
      if (context.mounted) {
        _snack(context,
            ok ? 'std.fieldbus.forceCleared' : 'std.fieldbus.forceDenied');
      }
      return;
    }
    bool boolVal = !c.boolValue;
    final analogCtrl =
        TextEditingController(text: c.analogValue.toStringAsFixed(2));
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: LText('${context.tr('std.fieldbus.forceTitle')} — ${c.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          // Two sentences, both load-bearing: WHY this control exists at all
          // (a commissioning gate, §7.5) and HOW FAR the force reaches (idle
          // MANUAL only, §10.5.1 rule 3). An operator who reads neither should
          // still not be able to mistake this for a manual command.
          const LText('std.fieldbus.forceWhy'),
          const SizedBox(height: 8),
          const LText('std.fieldbus.forceScope'),
          const SizedBox(height: 12),
          if (c.kind == ChannelKind.digital)
            StatefulBuilder(
                builder: (_, set) => PresetSwitchListTile(
                    title: LText(
                        '${context.tr('std.fieldbus.forceValue')}: ${boolVal ? 'ON' : 'OFF'}'),
                    value: boolVal,
                    onChanged: (v) => set(() => boolVal = v)))
          else
            TouchTextField(
                controller: analogCtrl,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                    labelText: context.tr('std.fieldbus.forceValue'),
                    suffixText: c.unit)),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const LText('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const LText('std.fieldbus.forceApply')),
        ],
      ),
    );
    if (confirmed != true) return;
    final ok = await widget.app.repo.forceChannel(root, c.path,
        force: true,
        boolValue: boolVal,
        analogValue: double.tryParse(analogCtrl.text) ?? 0);
    if (context.mounted) {
      _snack(context,
          ok ? 'std.fieldbus.forceApplied' : 'std.fieldbus.forceDenied');
    }
  }

  void _snack(BuildContext context, String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: LText(msg)));
}
