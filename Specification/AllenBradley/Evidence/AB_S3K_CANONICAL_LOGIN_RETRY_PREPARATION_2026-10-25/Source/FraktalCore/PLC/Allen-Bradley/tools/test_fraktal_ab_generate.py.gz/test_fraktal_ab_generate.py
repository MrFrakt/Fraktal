"""Tests for the declaration-to-Logix generator and the press demo it emits.

The negative tests matter more than the positive ones. Every rule S16
established is a rule here only if the generator can *refuse* something for
breaking it; a rule that cannot reject is a comment. Each rule below therefore
has a test that breaks it deliberately and requires the refusal.
"""

import dataclasses
import re
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

import fraktal_ab_declaration as decl
import fraktal_ab_generate as gen
import fraktal_ab_mailbox as mailbox
import fraktal_ab_manifest as manifest
import fraktal_ab_press_demo as demo
import fraktal_ab_press_echo38 as echo38


SEED = """<?xml version="1.0" encoding="UTF-8"?>
<RSLogix5000Content SchemaRevision="1.0" TargetName="FraktalPhase0" ExportDate="x">
<Controller Use="Target" Name="FraktalPhase0" ProcessorType="1769-L24ER-QB1B" MajorRev="33" SFCExecutionControl="CurrentActive" SFCRestartPosition="MostRecent" SFCLastScan="DontScan">
<DataTypes/>
<Modules>
<Module Name="Local" Inhibited="false"></Module>
<Module Name="Discrete_IO" Inhibited="false"></Module>
</Modules>
<AddOnInstructionDefinitions/>
<Tags/>
<Programs/>
<Tasks/>
</Controller>
</RSLogix5000Content>
"""


def emit(app):
    """Emit into a temporary directory and return (root, text, evidence)."""
    with tempfile.TemporaryDirectory() as directory:
        source = Path(directory) / "seed.L5X"
        source.write_text(SEED, encoding="utf-8")
        output = Path(directory) / "app.L5X"
        evidence = gen.generate(app, source, output)
        text = output.read_text(encoding="utf-8")
        return ET.fromstring(text), text, evidence


# A fresh SDK-created 5580 project: the controller module only. The L24ER's
# fresh shape carried the embedded Discrete_IO module; a ControlLogix 5580
# has no local discrete I/O at all, so there is no module entry.
SEED_38 = """<?xml version="1.0" encoding="UTF-8"?>
<RSLogix5000Content SchemaRevision="1.0" TargetName="FraktalPhase0" ExportDate="x">
<Controller Use="Target" Name="FraktalPhase0" ProcessorType="1756-L81E" MajorRev="38" SFCExecutionControl="CurrentActive" SFCRestartPosition="MostRecent" SFCLastScan="DontScan">
<DataTypes/>
<Modules>
<Module Name="Local" CatalogNumber="1756-L81E" Inhibited="false"></Module>
</Modules>
<AddOnInstructionDefinitions/>
<Tags/>
<Programs/>
<Tasks/>
</Controller>
</RSLogix5000Content>
"""


def emit_seed(app, seed):
    """Emit against an explicit seed shape and return (root, text, evidence)."""
    with tempfile.TemporaryDirectory() as directory:
        source = Path(directory) / "seed.L5X"
        source.write_text(seed, encoding="utf-8")
        output = Path(directory) / "app.L5X"
        evidence = gen.generate(app, source, output)
        text = output.read_text(encoding="utf-8")
        return ET.fromstring(text), text, evidence


class DeclarationRuleTests(unittest.TestCase):
    """The five S16 findings, each provably enforced."""

    def test_the_press_demo_declaration_is_emittable(self):
        self.assertEqual(decl.validate(demo.application()), [])

    def test_a_par_cfg_record_must_lead_with_schema_version(self):
        """Core §3.8: a reader must know which contract it holds."""
        app = demo.application()
        bad = decl.Record(
            "FRK_T_Bad",
            (decl.scalar("SomethingElse"), decl.scalar(decl.SCHEMA_VERSION_MEMBER)),
            par_cfg=True,
        )
        app = dataclasses.replace(app, records=(bad,) + app.records)
        findings = decl.validate(app)
        self.assertTrue(any("SchemaVersion" in f for f in findings), findings)

    def test_a_bool_member_cannot_reach_a_public_contract_udt(self):
        """The BOOL-member layout is a recorded S12 hole, not a local decision."""
        app = demo.application()
        bad = decl.Record("FRK_T_Bad", (decl.Member("Flag", "", "scalar"),))
        bad = dataclasses.replace(
            bad, members=(dataclasses.replace(bad.members[0]),))
        # force a non-DINT carrier the way a careless edit would
        object.__setattr__(bad.members[0], "name", "Flag")
        app = dataclasses.replace(app, records=(bad,) + app.records)
        # the emitter's own assertion is the backstop
        types_xml = gen.data_types(app)
        self.assertNotIn('DataType="BOOL"', types_xml)

    def test_a_duration_outside_the_checked_range_is_refused(self):
        app = demo.application()
        bad = decl.Record("FRK_T_Bad", (
            decl.scalar(decl.SCHEMA_VERSION_MEMBER),
            decl.duration_ms("Forever", initial=decl.DURATION_MAX_MS + 1),
        ), par_cfg=True)
        app = dataclasses.replace(app, records=(bad,) + app.records)
        findings = decl.validate(app)
        self.assertTrue(any("outside the checked range" in f for f in findings), findings)

    def test_a_timeout_that_is_not_whole_scans_is_refused(self):
        """The task period is part of the contract; a module must count it exactly."""
        app = demo.application()
        module = dataclasses.replace(app.modules[0], timeout_ms=505)
        app = dataclasses.replace(app, modules=(module,) + app.modules[1:])
        findings = decl.validate(app)
        self.assertTrue(any("whole number" in f for f in findings), findings)

    def test_a_boolean_carrier_holds_only_zero_or_one(self):
        app = demo.application()
        bad = decl.Record("FRK_T_Bad", (
            decl.scalar(decl.SCHEMA_VERSION_MEMBER),
            decl.boolean("Truthy", initial=7),
        ), par_cfg=True)
        app = dataclasses.replace(app, records=(bad,) + app.records)
        self.assertTrue(any("0 or 1" in f for f in decl.validate(app)))

    def test_a_step_targeting_a_missing_step_is_refused(self):
        app = demo.application()
        auto = next(c for c in app.chains if c.name == "AUTO")
        broken = dataclasses.replace(auto.steps[0], on_advance=12345)
        auto = dataclasses.replace(auto, steps=(broken,) + auto.steps[1:])
        app = dataclasses.replace(
            app, chains=tuple(auto if c.name == "AUTO" else c for c in app.chains))
        self.assertTrue(any("missing step" in f for f in decl.validate(app)))

    def test_a_condition_on_an_undeclared_input_is_refused(self):
        """Nothing would define that tag; Studio should never be the one to say so."""
        app = demo.application()
        auto = next(c for c in app.chains if c.name == "AUTO")
        step = next(s for s in auto.steps if s.action == decl.AWAIT)
        broken = dataclasses.replace(step, conditions=("FRK_Press_Imaginary",))
        auto = dataclasses.replace(
            auto, steps=tuple(broken if s is step else s for s in auto.steps))
        app = dataclasses.replace(
            app, chains=tuple(auto if c.name == "AUTO" else c for c in app.chains))
        self.assertTrue(any("not a declared" in f for f in decl.validate(app)))

    def _broken_guard(self, **changes):
        app = demo.application()
        auto = next(c for c in app.chains if c.name == "AUTO")
        step = next(s for s in auto.steps if s.action == decl.GUARDED)
        broken = dataclasses.replace(step, **changes)
        auto = dataclasses.replace(
            auto, steps=tuple(broken if s is step else s for s in auto.steps))
        app = dataclasses.replace(
            app, chains=tuple(auto if c.name == "AUTO" else c for c in app.chains))
        return decl.validate(app)

    def test_a_guarded_command_names_what_it_raises_and_where_it_goes(self):
        """Abandoning is a warning the operator reads and a recovery the chain
        takes; an unnamed one of either is refused."""
        self.assertTrue(any("warning" in f for f in self._broken_guard(report_reason=0)))
        self.assertTrue(any("jump" in f for f in self._broken_guard(on_jump=-1)))
        self.assertTrue(any("guard condition" in f for f in self._broken_guard(
            conditions=(), condition_labels=())))

    def test_a_policy_must_be_a_station_flag(self):
        step = next(s for c in demo.application().chains for s in c.steps
                    if s.action == decl.GUARDED)
        guard = dataclasses.replace(step.conditions[0], policy="StationNumber")
        self.assertTrue(any("not a boolean member of the StationCfg" in f
                            for f in self._broken_guard(conditions=(guard,))))

    def test_an_unemittable_declaration_raises_instead_of_emitting(self):
        app = demo.application()
        app = dataclasses.replace(app, task_period_ms=0)
        with self.assertRaises(decl.DeclarationError):
            decl.require_valid(app)

    def test_scans_for_refuses_a_duration_that_is_not_whole_scans(self):
        app = demo.application()
        self.assertEqual(decl.scans_for(app, 200), 20)
        with self.assertRaises(decl.DeclarationError):
            decl.scans_for(app, 205)


class EmittedProjectTests(unittest.TestCase):
    def setUp(self):
        self.root, self.text, self.evidence = emit(demo.application())

    def test_it_targets_the_pinned_v33_controller(self):
        controller = self.root.find(".//Controller")
        self.assertEqual(controller.get("ProcessorType"), "1769-L24ER-QB1B")
        self.assertEqual(controller.get("MajorRev"), "33")

    def test_one_aoi_per_module_type_plus_the_mode_owner(self):
        # Per TYPE, as the name always said. The assertion counted modules - one
        # per INSTANCE - so it pinned the duplication it was named against:
        # three cylinders were three identical definitions, and this passed.
        import fraktal_ab_library as library

        names = [a.get("Name") for a in self.root.findall(".//AddOnInstructionDefinition")]
        types = library.types_used(demo.application())
        self.assertEqual(len(names), len(types) + 1)
        self.assertLess(len(types), len(demo.application().modules),
                        "the press has more instances than types; one AOI "
                        "per instance would make these equal")
        self.assertIn(gen.unit_aoi_name(demo.application()), names)
        self.assertIn("FRK_M_Cylinder", names)

    def test_every_contract_member_is_a_dint(self):
        import fraktal_ab_sets as sets
        # The one exception is a Logix string, whose layout Logix dictates: a
        # StringFamily type is LEN plus a SINT array and there is no DINT-based
        # string to choose instead. It is exempted as a shape, not as a type -
        # the next test pins that shape so the exemption cannot widen.
        strings = {d.get("Name") for d in self.root.findall(".//DataType")
                   if d.get("Family") == "StringFamily"}
        for data_type in self.root.findall(".//DataType"):
            if data_type.get("Name") in strings:
                continue
            for member in data_type.findall("./Members/Member"):
                if member.get("DataType") in strings:
                    continue
                if (data_type.get('Name') == gen.mailbox.request_type_name(demo.application())
                        and member.get('Name') == 'ConfigSet'
                        and member.get('DataType') == sets.request_name()):
                    # Appended V2 request payload. Its own definition is walked
                    # below, so every leaf still has to be DINT.
                    continue
                import fraktal_ab_mailbox_frame as frame
                if (data_type.get('Name') == gen.mailbox.request_type_name(demo.application())
                        and member.get('Name') == 'Frame'
                        and member.get('DataType') == frame.type_name(demo.application())):
                    continue  # frame definition is walked below; all leaves DINT
                self.assertEqual(member.get("DataType"), "DINT",
                                 f"{data_type.get('Name')}.{member.get('Name')}")

    def test_a_string_family_type_carries_nothing_but_the_logix_string_layout(self):
        found = set()
        for data_type in self.root.findall(".//DataType"):
            if data_type.get("Family") != "StringFamily":
                continue
            found.add(data_type.get("Name"))
            members = data_type.findall("./Members/Member")
            self.assertEqual([m.get("Name") for m in members], ["LEN", "DATA"],
                             data_type.get("Name"))
            self.assertEqual(members[0].get("DataType"), "DINT")
            self.assertEqual(members[1].get("DataType"), "SINT")
            self.assertGreater(int(members[1].get("Dimension")), 0)
        # The exemption widened once, deliberately. It was "only the manifest
        # key string"; the command mailbox then needed the oracle's own string
        # fields - TargetPath, TextValue, the Diagnostic an operator reads - and
        # a contract cannot carry those as DINTs. So the allowed set is named
        # rather than counted, and anything else that becomes a string still
        # fails here.
        app = demo.application()
        allowed = {manifest.key_string_type(app)}
        allowed |= {mailbox.string_type_name(app, n)
                    for n in mailbox.string_lengths()}
        self.assertEqual(found, allowed)

    def test_no_bool_member_in_any_public_contract_udt(self):
        self.assertEqual(self.evidence["BoolMembersInPublicUdt"], 0)
        self.assertNotIn('<Member Name="', self.text.split("<DataTypes>")[0])
        for data_type in self.root.findall(".//DataType"):
            kinds = {m.get("DataType") for m in data_type.findall("./Members/Member")}
            self.assertNotIn("BOOL", kinds)

    def test_the_par_cfg_record_leads_with_schema_version(self):
        cfg = [d for d in self.root.findall(".//DataType")
               if d.get("Name") == "FRK_T_PressParCfg"][0]
        first = cfg.findall("./Members/Member")[0]
        self.assertEqual(first.get("Name"), decl.SCHEMA_VERSION_MEMBER)

    def test_the_task_carries_the_declared_period(self):
        app = demo.application()
        task = self.root.find(".//Task")
        self.assertEqual(task.get("Rate"), str(app.task_period_ms))
        self.assertEqual(task.get("DisableUpdateOutputs"), "true")

    def test_the_declared_period_is_published_for_a_reader(self):
        """A reader can check the period the timeouts were converted from."""
        self.assertIn("FRK_Press_TaskPeriodMs", self.evidence["EvidenceTags"])

    def test_the_mode_owner_self_checks_child_ordering(self):
        unit = [a for a in self.root.findall(".//AddOnInstructionDefinition")
                if a.get("Name") == gen.unit_aoi_name(demo.application())][0]
        body = "\n".join((l.text or "") for l in unit.findall(".//STContent/Line"))
        for module in demo.application().modules:
            self.assertIn(f"Ctx{module.name}.ModuleScan <> Scan", body)
        self.assertIn("Ctx.OrderFail := Ctx.OrderFail + 1;", body)

    def test_a_held_command_does_not_accrue_its_timeout(self):
        """Held is 'the operator let go', not 'the machine is broken'."""
        app = demo.application()
        body = "\n".join(gen.module_logic(app, app.modules[0]))
        # held on the simulated permissive loss, the application's interlock
        # (TC3's SetAreaSafe) or a missing directional permit (TC3's
        # SetDirectionalPermits) - one branch, one behaviour
        held = body.split("ELSIF (Ctx.HoldRequest <> 0) OR (Ctx.AreaSafe = 0) "
                          "OR (Ctx.Permit = 0) THEN")[1]
        held = held.split("ELSE")[0]
        self.assertNotIn("ElapsedMs := Ctx.ElapsedMs", held)
        self.assertIn("Ctx.OutImm_Held := 1;", held)
        self.assertIn(f"Ctx.OutImm_Severity := {gen.SEVERITY_LOW};", held)
        self.assertNotIn("Ctx.Error := 1;", held)

    def test_an_aoi_never_reaches_a_controller_scoped_tag(self):
        """Add-On Instructions may only touch their own parameters."""
        for aoi in self.root.findall(".//AddOnInstructionDefinition"):
            body = "\n".join((l.text or "") for l in aoi.findall(".//STContent/Line"))
            stray = sorted(set(re.findall(r"\bFRK_[A-Za-z0-9_]+", body)))
            self.assertEqual(stray, [], f"{aoi.get('Name')} reaches {stray}")

    def test_the_declared_channels_are_the_only_physical_operands(self):
        # The press declares its cabinet now, so reaching a terminal is
        # expected - but only the output word, and only from the force logic.
        # An operand appearing anywhere else would mean the plant arithmetic
        # had quietly started driving hardware.
        self.assertEqual(self.evidence["PhysicalIoReferences"], 20)
        operands = set(re.findall(r"\bLocal:\d+:[IOC][.\w]*", self.text))
        self.assertEqual(operands, {"Local:1:O.Data"})

    def test_forcing_reaches_only_the_declared_outputs(self):
        self.assertEqual(self.evidence["ForceableOutputs"], 8)

    def test_an_application_without_declared_io_cannot_reach_a_terminal(self):
        # The guard the two tests above used to be. It is the declaration that
        # decides, so this is the form that still protects every other project:
        # no declared channels, no un-inhibit, no operand, nothing emitted.
        bare = dataclasses.replace(demo.application(), io_modules=())
        root, text, evidence = emit(bare)
        self.assertEqual(evidence["PhysicalIoReferences"], 0)
        self.assertIs(evidence["EmbeddedIoInhibited"], True)
        self.assertEqual(re.findall(r"\bLocal:\d+:[IOC]", text), [])
        modules = {m.get("Name"): m.get("Inhibited")
                   for m in root.findall(".//Module")}
        self.assertEqual(modules["Discrete_IO"], "true")

    def test_the_pending_decision_is_lowered_every_scan(self):
        """Raised on one path, lowered on none - the mailbox latch again.

        A DECISION step sets DecisionId and nothing cleared it, so the id
        outlived the step: a chain that had answered and moved on, or been
        stood down entirely, still published a question. The operator was
        shown a prompt for a decision that no longer existed, and answering
        it did nothing.

        The clear has to come BEFORE the dispatch, so that only a step which
        is active this scan re-raises it.
        """
        body = chr(10).join(gen.unit_logic(demo.application()))
        self.assertIn("Ctx.DecisionId := 0;", body)
        clear = body.index("Ctx.DecisionId := 0;")
        dispatch = body.index("IF Ctx.Running <> 0 THEN")
        self.assertLess(clear, dispatch,
                        "the clear must precede the chain dispatch")

    def test_a_decision_step_still_raises_its_id(self):
        # The other half: the per-scan clear must not have disabled the
        # feature it guards.
        body = chr(10).join(gen.unit_logic(demo.application()))
        self.assertIn("Ctx.DecisionId := 2;", body)

    def test_the_embedded_module_runs_when_channels_are_declared(self):
        modules = {m.get("Name"): m.get("Inhibited")
                   for m in self.root.findall(".//Module")}
        self.assertEqual(modules["Discrete_IO"], "false")

    def test_the_chart_carries_the_section_3_13_marks(self):
        chart = [d for d in self.root.findall(".//DataType")
                 if d.get("Name") == "FRK_T_PressChart"][0]
        names = {m.get("Name") for m in chart.findall("./Members/Member")}
        for expected in ("StepCursor", "StallReason", "Visited", "LastMs",
                         "EnterCount", "CurrentStepMs"):
            self.assertIn(expected, names)

    def test_a_completed_chain_does_not_re_arm_itself(self):
        """Otherwise Running oscillates while the run request is held."""
        body = chr(10).join(gen.unit_logic(demo.application()))
        latch = body.split("Ctx.RunRequest <> 0")[1].split("END_IF;")[0]
        self.assertIn("Ctx.Complete = 0", latch)

    def test_every_declared_step_has_a_chart_slot(self):
        app = demo.application()
        self.assertLessEqual(self.evidence["DistinctSteps"], app.chart_steps)

    def test_every_commanding_step_drops_execute_on_entry(self):
        """Core 6.1 Execute-drop reset: without it a terminated child is pinned.

        A step that asserted Execute unconditionally could never release a child
        that had already faulted, so the fault would be permanent and every later
        step aiming at that module would stall forever.
        """
        app = demo.application()
        commanding = (decl.ISSUE, decl.ADOPT, decl.REPORT)
        checked = 0
        for chain in app.chains:
            for step in chain.steps:
                if step.action not in commanding:
                    continue
                body = chr(10).join(gen.step_logic(app, chain, step, 0))
                self.assertIn("IF Scan = Ctx.StepScan THEN", body, step.name)
                self.assertIn("Ctx" + step.module + ".Execute := 0;", body, step.name)
                checked += 1
        self.assertGreater(checked, 0)

    def test_adopting_a_fault_also_releases_the_child(self):
        """Adopting must not pin the child in the state nothing can then clear."""
        app = demo.application()
        auto = next(c for c in app.chains if c.name == "AUTO")
        step = next(s for s in auto.steps if s.action == decl.ADOPT)
        body = chr(10).join(gen.step_logic(app, auto, step, 0))
        adopt = body.split("ELSIF Ctx" + step.module + ".Error <> 0 THEN")[1]
        self.assertIn("Ctx" + step.module + ".Execute := 0;", adopt)

    def test_the_awaited_child_fault_is_adopted_verbatim(self):
        """The rollup: the parent republishes the child's reason, not its own."""
        app = demo.application()
        auto = next(c for c in app.chains if c.name == "AUTO")
        step = next(s for s in auto.steps if s.action == decl.ADOPT)
        body = "\n".join(gen.step_logic(app, auto, step, 0))
        self.assertIn(f"Ctx.ErrorID := Ctx{step.module}.ErrorID;", body)
        self.assertIn("Ctx.Error := 1;", body)

    def test_the_reported_child_condition_is_not_adopted(self):
        """A message, not a fault: adopting would replace a designed recovery."""
        app = demo.application()
        auto = next(c for c in app.chains if c.name == "AUTO")
        step = next(s for s in auto.steps if s.action == decl.REPORT)
        body = "\n".join(gen.step_logic(app, auto, step, 0))
        self.assertIn("Ctx.ReportedReason :=", body)
        self.assertNotIn("Ctx.Error := 1;", body)

    def test_the_decision_step_waits_without_faulting(self):
        app = demo.application()
        auto = next(c for c in app.chains if c.name == "AUTO")
        step = next(s for s in auto.steps if s.action == decl.DECISION)
        body = "\n".join(gen.step_logic(app, auto, step, 0))
        self.assertNotIn("Ctx.Error := 1;", body)
        self.assertIn("Ctx.DecisionId :=", body)

    def test_it_refuses_to_overwrite_an_existing_output(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "seed.L5X"
            source.write_text(SEED, encoding="utf-8")
            output = Path(directory) / "app.L5X"
            output.write_text("x", encoding="utf-8")
            with self.assertRaises(ValueError):
                gen.generate(demo.application(), source, output)

    def test_it_rejects_a_source_that_is_not_the_empty_v33_seed(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "seed.L5X"
            source.write_text("<RSLogix5000Content/>", encoding="utf-8")
            with self.assertRaises(ValueError):
                gen.generate(demo.application(), source, Path(directory) / "a.L5X")

    def test_out_of_scope_constructs_are_fenced_out(self):
        # Two frozen-contract manifest members name structures that do not exist
        # yet - a module's registry index, a root's mailbox identity. They are
        # published as zero references under the names the contract requires, so
        # the fence exempts those two names and nothing else.
        fenced = self.text
        for allowed in gen.SCOPE_FENCE_ALLOWED:
            fenced = fenced.replace(allowed, "")
        for term in gen.EXCLUDED_SCOPE_TERMS:
            self.assertNotIn(term, fenced)

    def test_the_fence_exemptions_are_the_only_way_those_words_appear(self):
        """The negative test: the exemption is by exact name, not by substring."""
        for allowed in gen.SCOPE_FENCE_ALLOWED:
            self.assertTrue(
                any(term in allowed for term in gen.EXCLUDED_SCOPE_TERMS),
                f"{allowed} exempts nothing and should not be in the list")

    def test_a_task_period_that_disagrees_with_the_declaration_is_refused(self):
        """The build-time assertion: the shipped task carries the declared period."""
        app = demo.application()
        original = gen.tasks

        def wrong(a):
            return original(a).replace(f'Rate="{a.task_period_ms}"', 'Rate="20"')

        gen.tasks = wrong
        try:
            with self.assertRaises(AssertionError):
                emit(app)
        finally:
            gen.tasks = original


class PressDemoShapeTests(unittest.TestCase):
    """The application mirrors the TC3 press demo's observable shape."""

    def setUp(self):
        self.app = demo.application()

    def test_the_declared_modes_are_the_oracle_s(self):
        # TC3's MANUAL has no sequence, so it is a mode without a chain.
        self.assertEqual({c.name for c in self.app.chains},
                         {"AUTO", "HOME", "CHANGEOVER"})
        self.assertEqual(self.app.manual_mode, demo.MODE_MANUAL)

    def test_every_mode_ordinal_is_distinct_and_from_e_mode(self):
        # The ordinals ARE the contract the HMI resolves against; a duplicate
        # would publish one mode under another's name.
        ordinals = [c.mode_ordinal for c in self.app.chains] + [self.app.manual_mode]
        self.assertEqual(len(set(ordinals)), len(ordinals))
        self.assertEqual(sorted(ordinals), [0, 1, 2, 3])
        self.assertEqual(decl.declared_modes(self.app), (0, 1, 2, 3))

    def test_the_auto_chain_carries_the_oracle_step_numbers(self):
        auto = next(c for c in self.app.chains if c.name == "AUTO")
        numbers = [s.number for s in auto.steps]
        for expected in (0, 100, 110, 130, 150, 170, 180, 200, 210, 215, 220, 999):
            self.assertIn(expected, numbers)

    def test_the_auto_chain_loops(self):
        auto = next(c for c in self.app.chains if c.name == "AUTO")
        self.assertTrue(auto.loops)
        self.assertEqual(auto.steps[-1].on_advance, 100)

    def test_home_completes_rather_than_looping(self):
        home = next(c for c in self.app.chains if c.name == "HOME")
        self.assertFalse(home.loops)
        self.assertTrue(any(s.action == decl.COMPLETE for s in home.steps))

    def test_exactly_one_adopted_and_one_reported_child_condition(self):
        auto = next(c for c in self.app.chains if c.name == "AUTO")
        self.assertEqual(sum(1 for s in auto.steps if s.action == decl.ADOPT), 1)
        self.assertEqual(sum(1 for s in auto.steps if s.action == decl.REPORT), 1)

    def test_exactly_one_decision_step(self):
        auto = next(c for c in self.app.chains if c.name == "AUTO")
        self.assertEqual(sum(1 for s in auto.steps if s.action == decl.DECISION), 1)

    def test_the_door_close_is_tc3s_guarded_command(self):
        """TC3's N180: released during the close, the press warns, reopens the
        door (N185), slides the part out (N190) and waits for a fresh start."""
        auto = next(c for c in self.app.chains if c.name == "AUTO")
        by = {s.number: s for s in auto.steps}
        guarded = [s for s in auto.steps if s.action == decl.GUARDED]
        self.assertEqual([s.number for s in guarded], [180])
        close = guarded[0]
        self.assertEqual((close.module, close.command, close.report_reason,
                          close.on_advance, close.on_jump),
                         ("Door", "EXTEND", demo.REASONS["TWO_HAND_RELEASED"], 200, 185))
        self.assertEqual((by[185].module, by[185].command, by[185].on_advance),
                         ("Door", "RETRACT", 190))
        self.assertEqual((by[190].module, by[190].command, by[190].on_advance,
                          by[190].marks),
                         ("PartSlide", "RETRACT", 100, ("Ctx.StartLatched := 0",)))

    def test_no_control_power_or_io_concept_is_declared(self):
        text = " ".join(
            [self.app.comment] + [m.comment for m in self.app.modules]
            + [s.comment for c in self.app.chains for s in c.steps])
        for forbidden in ("ControlOn", "ControlPower", "Local:", "Discrete_IO:"):
            self.assertNotIn(forbidden, text)


class Echo38TargetTests(unittest.TestCase):
    """The Logix Echo retarget: a ControlLogix 5580 seed at major revision 38.

    Echo cannot emulate the 1769-L2x bench controller, and this
    workstation's Echo Dashboard offers no CompactLogix 5380 type, so the
    simulated station is a 1756-L81E project. Its fresh seed carries no
    embedded-I/O module entry (a 1756 chassis is populated with modules),
    and the AOIs and the manifest identity carry the v38 identity instead of
    the bench's.
    """

    def test_the_echo38_declaration_is_emittable(self):
        self.assertEqual(decl.validate(echo38.application()), [])

    def test_it_targets_the_emulator_and_stamps_the_v38_identity(self):
        root, text, evidence = emit_seed(echo38.application(), SEED_38)
        self.assertIn('ProcessorType="1756-L81E"', text)
        self.assertIn('MajorRev="38"', text)
        self.assertEqual(evidence["ControllerIdentity"], "1756-L81E/A 38.011")
        self.assertIn("1756-L81E/A 38.011", text)

    def test_aois_carry_the_declared_revision(self):
        root, text, _ = emit_seed(echo38.application(), SEED_38)
        revisions = set(re.findall(r'SoftwareRevision="([^"]+)"', text))
        self.assertEqual(revisions, {"v38.00"})

    def test_a_5580_seed_needs_no_embedded_module_entry(self):
        root, text, evidence = emit_seed(echo38.application(), SEED_38)
        self.assertFalse(evidence["EmbeddedIoModuleInSeed"])
        self.assertIsNone(evidence["EmbeddedIoInhibited"])
        self.assertNotIn('Name="Discrete_IO"', text)

    def test_the_bench_v33_evidence_keys_are_unchanged(self):
        # The default path must keep its recorded evidence shape: a seed that
        # carries the module still reports the inhibit decision, not None.
        _, _, evidence = emit(demo.application())
        self.assertFalse(evidence["EmbeddedIoModuleInSeed"] is None)
        self.assertFalse(evidence["EmbeddedIoInhibited"])

    def test_the_echo_mailbox_is_writable_and_the_bench_stays_write_only(self):
        # The Echo drops connected writes to ExternalAccess=None members, so
        # the simulation build declares the mailbox argument members
        # Read/Write; the bench build keeps the guarded write-only form.
        _, echo_text, _ = emit_seed(echo38.application(), SEED_38)
        request_type = re.search(
            r'<DataType Name="FRK_T_PressHmiRequestV3".*?</DataType>',
            echo_text, re.S)
        self.assertIsNotNone(request_type)
        self.assertIn(
            'Name="Kind" DataType="DINT" Dimension="0" Radix="Decimal"'
            ' Hidden="false" ExternalAccess="Read/Write"',
            request_type.group(0))
        _, bench_text, _ = emit(demo.application())
        bench_request = re.search(
            r'<DataType Name="FRK_T_PressHmiRequestV3".*?</DataType>',
            bench_text, re.S)
        self.assertIsNotNone(bench_request)
        self.assertIn(
            'Name="Kind" DataType="DINT" Dimension="0" Radix="Decimal"'
            ' Hidden="false" ExternalAccess="None"',
            bench_request.group(0))


if __name__ == "__main__":
    unittest.main()
