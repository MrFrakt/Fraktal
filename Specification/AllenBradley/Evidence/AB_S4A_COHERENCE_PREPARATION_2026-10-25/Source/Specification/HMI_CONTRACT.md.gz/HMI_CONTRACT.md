# Fraktal HMI Contract — what a generic client binds (Core §3.10(a′), §3.13)

*The HMI never binds PLC-language properties or calls PLC methods: everything it
renders is **data** in the Fraktal Self-Description Service repository. A
binding may obtain that data from a native namespace or reconstruct it from a
validated live manifest. A station adds zero HMI code (O1); the same logical
structures serve every binding (O8).*

All displayed strings follow `LOCALIZATION_AND_MODULE_CONTENT.md`: PLC display fields carry stable `std.*`/`project.*` keys, never operator prose. Standard and project catalogs, first-run language selection, CSV administration, module PDF content, and per-section view policy are part of this contract.

In the TwinCAT binding, externally written request/configuration data is `VAR_INPUT` and published result/status data is `VAR_OUTPUT`; implementation `VAR` is private. This IEC access classification is a transport mapping, not authorization: every write listed below is still release-gated and re-checked by the PLC.

## Part genealogy (Core §3.16)

The generic Part card renders `Part.Parents` as ordered, selectable component
UIDs alongside the current Part/result. UIDs are identifiers and are displayed
verbatim. A binding may publish an aggregate string array or indexed scalar
`Part/Parents[i]` leaves; the client consumes the published extent, including
native array browse layouts, without a station-specific capacity or history.
An absent/empty parent set clears the display on the next snapshot. The PLC
owns genealogy and its lifecycle; the HMI neither accumulates consumption nor
reconstructs historical parent sets. Optional AB HostEvents V5 records carry a
captured `Parents` list independent of the current Part context.

## Discovery
Walk the canonical hierarchy returned by the Self-Description Service (§3.10).
**A record is a module iff it declares the standard module `Status` contract.**
`Status.Name` = qualified identity/tile caption, `Status.ModuleType` = tile kind
(Unit / EM / CM), `Status.TileEnable` = render on the parent's child view.
Children are the records whose declared parent is that module. In a native
hierarchical namespace such as Fraktal/TC3, that relation is the instance tree;
in a manifest binding such as Fraktal/AB, the gateway reconstructs the identical
repository hierarchy from stable module/parent IDs (§4.8).

## Per-tile bindings (every module)
| UI element | Symbol |
|---|---|
| Caption / kind | instance `Status.Name` identity plus optional `DisplayNameKey`, `Status.ModuleType` |
| State LED | `Status.State` (READY/BUSY/DONE/ERROR/ABORTED) |
| Message line | `Status.Diagnostic.Description` (+ `SourcePath`, `IoTag`, `IoAddress`, `Since`, `TimeSynchronized`) — the §6.9 first-out; `IoTag` is rendered verbatim/monospace and never localized; an unsynchronized stamp is visibly marked untrusted; on a Unit this shows the live stall (`Pending`) whenever no fault is active |
| PLCopen strip | `Busy`, `Done`, `Error`, `Aborted`, `ErrorID` |
| Command timing table (detail) | `Timing.Rows[i]` = {Id, Label, Count, Last, Minimum, Maximum, Avg}, `Timing.LastCmdTime`, `Timing.Truncated` (§8.11.4(a)) |

## Tabbed module detail and administrator customization

Every module detail offers the built-in **card tabs**: **Overview**, **Hardware**
(safety, system health, control power, device link, motion, nameplate), **Statistics**
(counters, OEE, shift, cycle analysis; Units only), **Events** (active events, event
history), **Description** (module information, documents) and, for a module with
editable values, **Configuration**. A card tab is a flow of cards, not a grid: each card
goes into the currently shortest column (ties go left), so the columns stack
independently and a tall card leaves no row-high gap beside it; a card with nothing to
show takes no place, and a column is dropped when a card would be narrower than it can
be read. The Overview carries every card, two columns by default,
with the description, documents and configuration cards present but hidden; every other
card tab carries its own cards in one column. The tab strip is omitted when only one tab
is visible. A tab with nothing to show this session - a card tab none of whose cards is
shown (hidden, above the session's level, or without data on this module), or a custom
view with neither controls nor a picture - is left out of the strip; in edit mode every
tab is shown, so an empty one can still be arranged.

Large detail tables are requested for the selected tab's visible cards, using
the same card and section access rules. Closed tabs and hidden cards do not
consume periodic ring/trend reads; an initially empty table still has an owning
view that can request it. Authored controls derive demand from their bindings.
Budgeted tiered transports stream the demanded tables through their slow tier;
closing the view excludes them again. Other transports use bounded targeted
reads. Source freshness remains independent of the live station sample (see [transport read tiers](OPCUA_TRANSPORT.md)).

An empty forest caused by temporary data withdrawal preserves the selected
module path and local tree scope. It clears usable module data and permissions;
the connection owner still blocks interaction on STALE/DOWN. Recovery between
frames retains the mounted tab and its presentation filters instead of silently
opening the plant overview. A populated replacement forest that no longer
contains the selected module resets selection to the overview as usual.

The selected tab ID and each view's time/severity filter choices are HMI-local
presentation state. They survive a painted connection screen and the resulting
detail-widget remount. No module samples, permissions or commands are retained
with these choices: recovery renders newly accepted data, and STALE/DOWN still
withdraws the interactive shell. A removed module discards its presentation state.

Filter selection changes geometry immediately. Controls and cards isolate their
repainting so selection/ink animation does not redraw neighbouring charts on every
frame. These presentation changes issue no PLC command.

In edit mode an authenticated `ADMIN` arranges each card tab - adds or removes cards,
drags them into order, hides or shows each, sets the minimum `AccessLevel` to see each
(on top of the module's section policy) and sets the column count - and drags the tabs
themselves into order. Any tab, a custom one included, may be made the **default tab**:
the module opens on it, and it stays first. Each tab has an HMI-local minimum
`AccessLevel`; only an `ADMIN` may change that threshold, title, order, trigger, or
content. Like section policy, tab and card visibility is defense in depth rather than
transport read authorization.

Typed/category capabilities add reusable detail tabs without station screens:

- a motion facet adds position/target/velocity/error and axis-state presentation;
- `FB_TcpVisionCM`-shaped data adds judgement, result, trigger, and optional-image
  presentation;
- `FB_TcpCodeReaderCM`-shaped data adds decoded value, no-read/match state, link state,
  statistics when published, and a catalog-routed trigger;
- RFID-shaped data adds current UID, tag-present/read-quality, link state, and a
  catalog-routed read action.

These are standard category renderers, not vendor or station pages. Missing optional
values render as unavailable; they are never synthesized. High-performance defaults
use neutral surfaces and reserve strong colour for abnormal/judgement state.

In `ADMIN` edit mode, a custom or guidance tab may contain localized text, scalar value
outputs, Boolean LED indicators, bounded local trend charts, PLC-validated action
buttons, configuration text inputs, and embedded images. The control editor presents
an autocomplete/search selector populated only from scalar repository values owned by the
selected canonical module; it never accepts an invented free-text path. Values
below child module nodes belong to that child. `OPC.UA.DA := '0'` therefore removes a
TC3 value from custom binding just as it removes it from every OPC UA client;
other bindings enforce the same exclusion through their manifest/access gate. Value, LED,
and configuration-input controls link one compatible value; a chart links up to eight
numeric values and renders them as distinct series. Chart periods are clamped to
250–60000 ms and histories to 20–600 points; these are volatile display samples, not
a historian or a control-time source. A temporarily unavailable imported link is
shown as unavailable and retained for reconnect/change-resistant import rather than
silently discarded.

Each selected scalar retains the repository value envelope's quality,
source/server timestamp, synchronization flag, and logical runtime type. A TC3
OPC UA adapter maps its `DataValue` into that envelope; an AB adapter maps the
CIP sample and gateway receipt state into the same fields. Only Good-severity values are usable. Bad or Uncertain values are
shown with an explicit quality/status indication; LEDs do not imply an ON/OFF state,
charts do not append a sample, and configuration inputs are disabled until Good data
returns. The flat snapshot value map remains a Good-only compatibility surface.

Controls have portable responsive width presets (quarter, third, half, two-thirds,
full). Narrow displays collapse them to safe full/half-width rows; wide displays use
a wrapping grid. Edit mode supports drag reordering plus keyboard-accessible move
actions. Layouts remain flow-based and responsive rather than persisting fragile
pixel coordinates.

A custom tab with a background image is an overlay container
(`LOCALIZATION_AND_MODULE_CONTENT.md` §7.2): a control may carry a placement whose
position and size are fractions of the image's own painted box, computed with the
same fit/alignment/margin arithmetic that draws the image, so a lamp placed on a
sensor stays on it on every panel size and fit. Unplaced controls stay in a flow
list beside the picture, never over it. An ADMIN drags a control from a palette onto
the picture, drags a placed control to move it and its corner to resize it; each
completed gesture is one draft step. Two kinds exist for pictures: a state shape
(rectangle, rounded rectangle, circle) and a level bar (vertical when drawn taller
than wide, over a declared minimum/maximum). Their colour comes from at most four
ordered rules - binding, comparison (is TRUE, is FALSE, =, ≠, >, <) against a
constant, semantic state token - and a default token (§7.3): the first match
wins, a non-numeric value never matches, and any Bad/Uncertain or missing binding
renders the control unavailable instead of a state. A stored rule that names a
binding the control no longer has rejects the control rather than dropping the rule.

A layout is authored against a module **type** (`Status/TypeKey`,
`LOCALIZATION_AND_MODULE_CONTENT.md` §7.1), and a module's own layout is the
override: the HMI resolves a module's tabs from its path, else its type key, else the
defaults, and an override replaces the type's layout whole (no partial merge). The
editor publishes to "this module" or "every module of this type"; dropping an override
falls back to the type and is recorded as a revision. A type layout is stored under the
scope `type:<TypeKey>`, travels in the customization profile, and is never remapped as a
module path on import. A module that publishes no type key keeps per-path layouts.

Every custom view declares a display class (§7.4) - operating, maintenance or
engineering - shown as a badge on the view and recorded in the export.
An operating view is refused a picture at publish; a view stored without a class takes
maintenance if it carries a picture and operating otherwise. Every view is also
refused at publish above its read budget (§7.3): the standard 200 bound reads, or a lower
`readBudget` the view declares (a declaration above 200 reads as the standard). On an
operating view an `ok` state token draws neutral: colour is reserved for the abnormal.

A custom view without a picture may use a **grid container** (§7.2) instead of the flow:
`grid.base` is a column and row count (at most 12 × 24) and the cell of each control it
places, by control id — a column/row origin and span, drawn as that fraction of the tab.
`grid.variants` may re-place the same controls for a control-scale preset (`compact`,
`medium`, `large`); a scale with no variant shows the base, scaled rather than
reflowed. A control with no cell in the grid in force is listed beneath it. A cell outside
its grid, or for a control the view does not hold, is dropped on load rather than drawn
somewhere nobody placed it; resizing a grid takes off the cells that no longer fit; a view
with a picture places on the picture and keeps no grid. A placed control is drawn at its
cell's width and scaled down, never clipped mid-row, when the cell is shorter.

Every control may name a **layer** (§7.2): controls sharing it form a show/hide set the
viewer toggles with chips (per panel, never while editing). **Z-order** is control
order; the placement toolbar brings a control to the front or sends it to the back. A
control may carry a bound **`visible`** - one tag, a comparison and a constant - and
stays shown while that tag is unavailable, so missing data never hides an indicator; it
is presentation, never enforcement. A button or input may also carry a bound
**`enabled`** of the same shape; there an unavailable tag *disables*, because
Bad/Uncertain data never enables an input. A state rule may **blink** while it is the
rule in force, and holds steady when the platform asks for reduced motion. A state rule,
and the default state, may name an **icon** from the bounded `ModuleGlyph` set, drawn in
the state's token colour. A shape may carry a bound **rotation**: one numeric tag whose
range maps linearly onto two angles within ±360°, clamped at both ends, upright while
the tag is unavailable. Any control may carry a bound **opacity** (`dimmedWhen`, the
`visible` shape) and draws at 35 % while it holds; unavailable data never dims. A view
may bind a **layer's** visibility (`layerConditions`, one condition per layer name): the
whole set is shown only while it holds, never hidden on unavailable data, and the
viewer's chip still applies on top. Every condition, rotation and layer tag counts
toward the read budget. Every state token, `off` included, is
measured at 3:1 on a card in every theme (`theme_contrast_test.dart`), which is what
"contrast enforced at publish" (§7.4) reduces to when authored colour can only be a
token.

**Configuration values are edited in the control their type calls for.** A
`BOOLEAN` value is a checkbox; a value with an `EnumDomain` is a dropdown whose labels
come from the catalogs as `<EnumLabelKey>.<value>` (the raw value when the entry names
no prefix or the catalog has no entry); anything else is a text field. The unit is a
code, `UnitCode` (`E_EngUnit`, ordinals mirrored by the HMI's `EngUnit` and checked by
lint E1): the HMI shows its own translated symbol (`std.unit.<name>`) after the value,
in the reading direction, and shows nothing for `NONE`. A controller that publishes no
`UnitCode` keeps its legacy `Unit` text, which a current PLC derives from the code.

The **station tile** (§7.5) keeps its fixed geometry - identity, state, the built-in
chips, the message line - and adds authored slot contents: up to three metrics (value
controls) and two badges (state shapes), authored per station or per type (`type:<key>`
scope) from a root Unit's edit bar and published directly, outside the tab draft.
Metric *N* always occupies column *N*, an unavailable metric shows a dash in its column,
and a badge's OK state draws neutral because the tile is an operating view by
definition. A profile is refused whole if any slot is invalid, travels in the
customization profile as `tiles`, and an older bundle without it imports unchanged.

An administrator may select a whitelisted portable icon preset for each custom or
guidance tab. A custom tab may also carry an embedded background image with
contain/cover/fit-width/fit-height aspect-ratio presets, nine-point alignment, and
independent bounded margins. The image remains presentation-only behind the tab's live
controls; it cannot replace the PLC-owned status contract. The card tabs, the Overview
included, carry none: a picture stored on one by an older HMI is dropped on load.

Layout editing cannot create an arbitrary write path. Buttons map only to the existing
manual-command catalog, Unit start/stop/reset, or `DecisionAnswer`; inputs use the
existing acknowledged configuration mailbox. The PLC remains authoritative for
publication, type/range validation, access, releases, interlocks, audit, and acceptance.
Rejected actions follow act-or-explain and no write is queued across reconnect.
Manual-command and decision buttons store only a value selected from the current PLC
catalog and execute against their current canonical module/root; an older imported
free-form target path is ignored. State-changing buttons may require an operator
confirmation and disable while one acknowledged request is in flight. A missing
catalog entry disables the button rather than guessing or sending an obsolete value.

### Configuration write capabilities

The editor is derived only from writable §3.10.2 manifest entries. Each field carries
`Scope`, display/browse `Item`, stable `WriteKey`, non-zero `WriteRevision`, `ConfigKind`,
`ValueType`, optional bounds/exact enum domain, unit/label, and `RequiresReady`. The HMI
shows Apply only when that complete capability is valid, belongs to the current canonical
module, the required root state is satisfied, and the current session permits
`DATA_WRITE`. Missing metadata, duplicate `(Scope, WriteKey)` entries, older manifests,
and arbitrary scalar tags are read-only. A custom configuration-input binding must match
the capability's `Item`; it may not manufacture a field from the final browse segment.

The repository re-resolves the current capability immediately before sending
`WRITE_CONFIG`: `TargetPath=Scope`, `NameValue=WriteKey`, `IntValue=WriteRevision`,
`TextValue=candidate`, then `Sequence` last. Client type/range checks provide immediate
feedback only; the PLC repeats them and remains authoritative. A stale revision or
reconnect never falls back to a browse write and is never queued for replay.

A value published with `ModelScoped = TRUE` (Core §3.8a, Core 0.19+) belongs to the root's
model record. The model-data card offers every `AvailableModels` entry beside the running
one: `QUERY_CONFIG` and `WRITE_CONFIG` carry the chosen model in `DurationMs`
(0 = running, n = `AvailableModels[n]`), and the card reads the record back after each
accepted write because another model's values are not in the live tree. A query for
another model answers with its model-scoped values only - normally one page - never the
station manifest. `DurationMs` is 0 for every other value. Model config, station config and line config are separate
cards (`modelData`, `stationData`, `lineData`); a stored layout naming the former single
`configuration` card expands to the three in place.

### Parameter sets (Core §3.8b)

Set operations are separate from field edits in both directions. The HMI offers
save/load/list only when the session permits `CONFIG_SET` (a model set also
requires `CHANGEOVER`) and the owning root is `READY`; a load is presented as
replacing the machine's parametrization, not as an edit. Because the PLC stages
and validates the whole set before applying any of it, a rejection returns the
offending `(Scope, WriteKey)` and the HMI shall show that identity rather than a
generic failure — the operator's next action is to fix one value, and they cannot
if the client hides which. Durability is displayed, never assumed: `PersistPending`
and `PersistFailed` from the root drive an explicit indication, and a restore
failure reported at startup stays visible until acknowledged. The client never
serializes or repairs a set itself; it names one and reports what the PLC did.

## Sequence-triggered Unit guidance

A Unit may have one or more **guidance** tabs. A guidance tab can match an exact
`CurrentStep.StepNo`, an exact `CurrentStep.StepName`, or `*`; the wildcard opens only
for `WAIT_OPERATOR` steps. On entry to a newly matched step the HMI opens a full-screen
operator guide containing the live step/awaited conditions, any `Decision` prompt, and
the administrator-authored controls. Dismissing it does not complete or acknowledge
the sequence. Completion still comes only from published PLC conditions or the typed
`DecisionAnswer`; the same step is not reopened repeatedly until the step identity
changes. This supports changeover/cleaning/tooling instructions without a
press-specific HMI page or PLC-authored prose.

## Portable HMI customization bundle

An `ADMIN` can export/import one versioned UTF-8 JSON customization bundle. It includes
all persistent administrator-owned presentation state: module tabs and controls,
per-tab and per-section access policy, tab icon choices, guidance triggers, embedded
control and tab background images with layout settings, module PDF
documents/metadata, canonical repository control bindings (including their
binding-specific transport locator where required), and both standard/project localization
overrides for every language. Import validates the complete bundle and explicitly
confirms a merge:
imported IDs/keys update matching items while target-only customization is preserved.
It reconciles module identities conservatively: exact paths first, then a mapped
parent plus unchanged local name, then a unique longest dotted-path suffix. A uniquely
remapped descendant may establish a root-rename hint. Ambiguous or absent modules do
not fail the import and are not discarded; their profiles remain stored under the
original path as **deferred**, and the administrator receives an exact/remapped/deferred
report. Malformed schemas or payloads still fail closed.

Administrator edits are drafts: add/edit/delete/reorder operations update only an
in-memory working copy with undo/redo. Operators continue to see the last published
layout until `Publish` succeeds. Publishing records the previous layout, UTC time,
administrator identity, and optional change note. At most 20 revisions per module are
retained; restoring a revision first records the layout being replaced. Revision
history is part of customization schema 4 and follows the same deterministic module
path reconciliation during import.
Connection endpoint/transport, proven-connection state, selected Unit scope,
credentials/session state, and language selection are connection/bootstrap settings
and are deliberately excluded. The shipped native and Web stores remain device-local;
the bundle is the portable commissioning/backup path. Native storage replaces files
through a flushed temporary generation and retains a last-known-good backup; Web uses
IndexedDB and migrates the older local-storage record when encountered.

## Unit detail view (additional)
| UI element | Symbol |
|---|---|
| Current step | `CurrentStep` (StepNo, StepName, AwaitingLabel, TimeClass, ExpectedTime, Conds[] with per-condition Label/Ok — §6.5/§6.9(b)) |
| Model catalog | optional `AvailableModelCount` + `AvailableModels[]/ModelCode`; render a selector when present, otherwise validated free text (§3.8) |
| Live stall reason | `Pending` (Low; distinct from a fault) |
| Cycle waterfall | `Profiler.LastCycle` — ordered `Steps[]` {StepNo, StepName, **TimeClass** (color), Started, Duration}; header: `Total`, **`WorkTime` (real cycle time)**, `WaitTime`, `ByClass[0..4]` (§8.11.4(b)/(f)) |
| Step Pareto | `Profiler.StepStats[]` (Avg/Max per StepNo, class-tagged), `Profiler.Current` for the live bar |
| Counters | `GoodCount`, `NokCount`, `Starved`, `Blocked` (§8.11) |
| Fault history | `History[1..MAX_DIAG_RING]`, newest at `HistoryHead` (§6.9(a) ring — shift post-mortem) |
| Operator decision | read `Decision` (Prompt/Options/Default/Timeout); **write** `DecisionAnswer` (1-based option; 0 = none) (§6.11) |
| Alarm/event list | sparse `AlarmLog.Active[1..MAX_ALARM_ACTIVE]` slots whose State is ACTIVE/WAIT_RESET (Severity, Reason, Source, optional exact `IoTag`/`IoAddress`, ComeAt + time-quality flag, ResetClass) — WAIT_RESET rows render as "cleared, awaiting reset" (§8.3(b)) |
| Event history | `AlarmLog.Ring[]`, newest at `AlarmLog.RingHead` — each closed event with optional exact `IoTag`/`IoAddress`, **`Duration`**, ComeAt/GoneAt/ResetAt and their time-quality flags (§8.3(a)/(d)); unsynchronized records are marked untrusted, never discarded; full history via an `I_EventSink` historian adapter (deferred by design) |
| Blocked banner | `AlarmLog.Blocking` — Unit will refuse `Start` until **OperatorReset** (write, release-gated §7.6/§14) |

The cycle timing charts expose selectable legend chips and **Show all**.
Cycle trend, Gantt and step Pareto filter by the published time class. Each
chart's selection is local presentation state. Hidden classes are excluded from
its bars/rows and the axis fits the remaining data. Filtered Gantt uses a linear
elapsed-time axis starting at zero: visible steps are concatenated and hidden
durations contribute neither offsets nor axis extent. Its Start cells use that
same filtered axis and retain the original cycle start in their tooltips. The
filtered axis is explicitly labelled. Full-cycle totals and PLC aggregates remain
unchanged.
The trend labels the selected-class sum as **Shown**, retains the full cycle's
readout, and omits the full-cycle best reference while filtered. Empty selections
are explicit and retain the chips/Show all; a class disappearing from the data
releases its hidden state so it can return visible. Command timing aggregates do
not carry time classes, so no work/wait attribution is inferred for them.

## Safety and control-power facets (§9.8)

Any module may publish `Safety : ST_SafetyStatus` and `ControlPower : ST_ControlPowerStatus`; `Present=FALSE` hides the card. A root Unit additionally publishes read-only `Domain : ST_ControlDomainStatus` and `Status.ControlDomainId` (`''` = no arrangement). Its application-fed `ControlDomain` input is private and excluded from the Self-Description Service; clients bind only `Domain` (TC3 realizes the exclusion with OPC UA publication attributes). One domain may serve several root Units; mirrored cards with the same ID are one shared domain, not independent power controls. Safety rows are read-only and include device kind/state, demand, safe-state feedback, reset-required, fault, muting, keyed bridge, fieldbus health, and affected power groups. Muting/bridge are conspicuous and never rendered as normal bypass controls. Control power shows domain Control On/Off state, affected member Units, and each named power group's request, feedback, safety permit, fieldbus health, reaction, and rearm requirement. `Start` is unavailable when an assigned domain is not `ReadyForStart`; an unassigned Unit adds no gate. The ordinary HMI never writes safety reset, bridge, muting, or guard unlock.

Control On/Off is data-driven through the selected root Unit's `HmiRequest` mailbox (`CONTROL_ON` / `CONTROL_OFF`). The base acknowledges only after applying the `POWER_CONTROL` access gate, then emits one-scan `ControlOnRequest` / `ControlOffRequest` outputs. A one-Unit application may consume those pulses locally; a shared-domain application shall route every member request to the single domain coordinator. Reconnection never replays either request.

## System health, clock quality, and signal tower (§2.7/§8.12/§8.13)

A Unit with `SystemHealth.Present=TRUE` renders the bounded live health card from
task cycle/jitter/overrun, explicit controller/IPC/fieldbus/DC availability and
values, and `SystemHealth.TimeQuality`. Unavailable is distinct from zero and a
clock that is unavailable, unsynchronized, or outside the configured tolerance is
conspicuous. Within the IPC group, `FanAvailable`/`StorageAvailable` say whether
`FanHealthy`/`StorageHealthPct` are measurements; `LostFrameCount`/`SlaveErrorCount`
count the current or last complete 10 s window, not the master's lifetime totals. `SignalTower` renders the semantic Red/Amber/Green/Blue/White/Horn and
`TestActive` state beside it; no HMI code knows electrical output addresses.

Lamp test writes only append-only mailbox request `LAMP_TEST := 26`. The control is
shown through the existing act-or-explain path, requires the Unit's `MANUAL` access
gate and an idle Unit, waits for acknowledgement, and is disabled while
`TestActive`. The PLC owns the bounded timeout, so disconnect never leaves the test
latched. Health/tower fields are generic Unit facets and shall not create a
station-specific page.

## Connector sub-tile
`Status` as any module; link detail: LastSeen/Reaction are on the connector's mirror/diag (`Status.Diagnostic` = link first-out when unlinked).

## Commissioning gates (§7.5)

While a station's engineering-gate register is non-empty the PLC raises one
`COMMISSIONING_GATE_ACTIVE` (reason 2030) event per active gate: `LOW` severity,
`SYSTEM` category, `AUTO_RESET`, and rationalized **not shelvable**. The client
**shall** render a **permanent, non-dismissible** indication for as long as any
such event is active, listing each gate's localized description.

It is deliberately a **separate strip from the global alarm banner**. That banner
shows the single worst active event, and this is the lowest-priority event the
framework raises — so during commissioning, the phase that produces the most
process alarms, a severity-ordered banner would bury the one message that says
the machine is not running its production software. For the same reason the strip
is warning-tinted rather than error-tinted: the station is not faulted, and
dressing a build statement as a fault trains operators to ignore real ones.

Three things the client shall **not** do: offer a close/dismiss control (no
operator action closes the underlying event, so a dismissible banner would give
that capability back); filter the event by `Shelved` (the reason is not
shelvable, and honouring a shelf would defeat the clause); or infer the gate set
from anything but these events. The strip disappears when the PLC stops reporting
gates, which — gates being build constants — means a new download.

## Fieldbus and I/O identity

The physical topology binds `Topology : ST_FieldbusTopology`: `NodeCount`, `Nodes[] : ST_BusNode`, `MappingValid`, and `MappingDiagnostic`. An invalid mapping is a commissioning fault and shall be displayed rather than treated as an empty/healthy bus. Discovery reads `NodeCount` and each active node's `ChannelCount` before traversing the bounded arrays; unused fixed-array elements are not part of an HMI snapshot. For every `ST_IoChannel`, the client maps `Name`, `DescriptionKey`, `Address`, `Path`, `ModulePath`, `Dir`, `Kind`, values, `Unit`, `Forced`, `Quality`, `FaultActive`, `Diagnostic`, and `Forceable`. `Name` is the exact approved electrical/I/O-list tag and is shown verbatim in monospace; `DescriptionKey` and `Diagnostic` are localized by the project catalog. `Address` shows the terminal/channel locator. `Path` remains the unique forcing/audit identity, while `ModulePath` opens the owning module and defines the HMI assignment boundary. `Forceable` is an explicit PLC capability and defaults false when absent; output direction by itself never creates a force control. It is additionally FALSE on every channel unless the deployed image carries an active §7.5 `OUTPUT_FORCING` commissioning gate, so on a production station the client renders **no force affordance at all** — absent, not greyed (§3.9). The client shall not offer a local switch to reveal it: the capability is a property of the controller image, and a client that could turn it on would be exactly the authority §7.5.1 denies. The force dialog states both why the control exists (a commissioning gate) and how far it reaches (only while the owning Unit is idle in `MANUAL`; starting it or leaving `MANUAL` withdraws every force), so it can never be mistaken for the manual-command path that goes *through* a module. A snapshot marked `truncated=true` is rejected before mapping and shall never produce a `LIVE` repository or an empty-but-healthy fieldbus view.

When `FaultActive` is true the channel and its diagnostic are highlighted. A module alarm simultaneously shows `ST_Diagnostic.IoTag`/`IoAddress`, so a cylinder timeout can read, for example, “press did not reach DOWN” plus `_101B202A · EL1809 Ch5`; the same exact tag is highlighted in the fieldbus tree. Transport adapters shall copy these fields without normalizing case, stripping the leading mapping marker, translating, or substituting a friendly label.

The manual-command card also displays the physical I/O whose `ModulePath`
exactly equals the selected module identity, grouped as Inputs and Outputs.
It uses the same channel records, preserves electrical tags verbatim and
localizes descriptions. Analog signals show value and unit; forced and fault
indications remain visible. Missing, non-Good or disconnected data displays
unavailable quality rather than an assumed OFF value. This is a read-only
surface; commands continue through the existing release-gated module path.

While that card is visible, the repository demands the selected channels'
quality/diagnostic fields and their bus ancestors' health. Hidden or access-gated
cards and other tabs withdraw that demand. The full bus view independently owns
its broader demand; closing either consumer shall not stop the other. An HMI
root assignment also bounds module I/O demand. The Like a Bosch theme draws
circular white down/up arrows for inputs/outputs, light green/red active fills
and gray inactive fills. Unavailable quality has a distinct neutral mark.

## Tree & theming (client behaviour)

**Inline spacing:** chips, badges, card-heading items and compact action groups
use the unit card's spacing. The shared `kInlineItemGap` visual token owns the
horizontal gap, wrap-run gap and separation between stacked status rows, so
similar groups inherit one policy throughout the client.

**Control size:** the selected compact/medium/large preset applies to pressable
controls, including time/event filters, choice chips, chip actions and deletion,
checkboxes, radio selectors and switches. `UiMetrics` owns their dimensions;
button themes, `PresetChip` and `PresetToggle` share those metrics. Glyphs and
tap areas grow together, with layout space reserved for the enlarged control.
Read-only status badges retain their compact layout. Timing filters and their
Show all action have the same height at each preset. The time-quality badge is
the first item in the system-health metrics row, before Task and Jitter.

**Tree highlighting (§3.13):** per node, effective severity = max(own active events, children's) with HIGH > MED > LOW; tint every ancestor down to the source, strongest at the source. Derived purely from `Status`/`AlarmLog` — no extra PLC symbols. **Themes:** Material 3, selectable (light/dark/high-contrast). The picker lists the **industrial standard** themes first - flat colour, colour reserved for status, the ANSI/ISA-101 high-performance greys leading - and the **modern** decorated ones (glow, glass, grid, paper, reflection) after; the grouping is derived from each theme's finish, and a selection is still stored by its unchanging index. Theme *changing* is an HMI-local setting gated by a configurable minimum `Access.CurrentLevel` (default `NONE` = open) — it is client config, not a PLC gated action. **Transports:** every UI platform binds the abstract repository. Fraktal/TC3 native clients may use OPC UA directly and Web uses the repository gateway; Fraktal/AB uses its EtherNet/IP/CIP gateway for native and Web clients. Transport choice changes only the adapter, never the domain or UI contract.

## Connection bootstrap (fail-closed)

Settings displays the active PLC/gateway endpoint to every operator when the
connection owner provides it. This is the endpoint used to create the current
repository, with URI user information, query and fragment removed. An ADS target
retains its AmsNetId and runtime port; a direct CIP target retains its host and
port. A gateway URL identifies the service and does not claim to identify the
controller behind it. Editing setup does not relabel an existing session.
The administrator Disconnect action closes that session through the connection
owner; a new endpoint takes effect only after Connect.

Connection ownership precedes the operator shell. On first use—or whenever settings exist but have never produced a `LIVE` repository state—the HMI **shall open a connection wizard**. Step 1 configures and proves the endpoint. After `LIVE` discovery, step 2 lists canonical root Unit repository paths and requires at least one Unit assignment for this HMI. The selected paths are saved locally and form both a display filter and a repository write boundary, including fieldbus branches through their channel-to-module paths; global connection status remains visible. `EverConnected` becomes true only after the repository is live and Unit assignment is complete; saving an endpoint alone is not proof.

When settings have previously connected, startup goes directly to a full-screen **Connecting to PLC** view. The interactive HMI is not built while the repository is `CONNECTING`, `STALE`, or `DOWN`. A transition away from `LIVE` removes operator interaction immediately; commands are never queued or replayed across reconnection. After 30 seconds without `LIVE`, and not before, the view exposes **Edit connection settings**. A successful `LIVE` transition cancels that timer and opens the shell only if every saved Unit path is rediscovered; missing/renamed assignments return to step 2 fail-closed. An authenticated `ADMIN` may edit the Unit assignment later from the shell. Native settings use a local JSON file; Web uses browser local storage. Both are HMI-local connection configuration, not PLC recipe/station config.

## Access levels (§7.7) — how the Flutter client behaves

An asynchronous provider may also publish read-only integer
`Access.LoginTimeoutMs`, present from discovery onward. The generic repository
uses a value in `1..600000` as its result wait after mailbox consumption; an
absent, zero, negative or excessive value retains the six-second default. This
budget describes the provider's bounded computation and transport margin, not
the session idle timeout. It cannot confer a role: the published result still
decides authentication. A provider shall bound its per-task work independently
of this client wait.

A provider may publish optional read-only integer
`Access.LoginResultSequence`, present from discovery onward. It identifies the
sampled mailbox request whose authentication has completed, independent of
other mailbox acknowledgements. The repository shall wait for its own LOGIN
sequence before accepting success or rejection; an older failure or session
shall not settle the pending attempt. Comparison uses the unsigned 32-bit
sequence representation, including bindings with signed DINT counters.
Providers without this field retain the existing outcome fields.

The result wait uses a monotonic clock and also bounds an individual result
read. A timeout, lost connection or unconsumed LOGIN is an unavailable result;
the dialog shall not describe it as incorrect credentials. Only the completed
provider's negative result produces the generic user/PIN error.

Per root Unit: read `Access.CurrentLevel` / `Access.CurrentUser` / `Access.LoginFailed`, `Access.Policy.Required[0..11]` (index = `E_GatedAction`, including append-only `ALARM_SHELVE` at 9, `POWER_CONTROL` at 10 and `CONFIG_SET` at 11), and `Access.Policy.SessionTimeout`. A blocked control remains pressable only to open its release explanation; it never issues the mutation. Login is **data-driven** through the root mailbox; the PLC clears the transported secret after each attempt. Idle auto-logout (`T#0S` = never) is rearmed by successful login and accepted authenticated operator mutations, never by snapshot/manifest/release polling. An asynchronous access provider may publish the optional Boolean `Access.LoginBusy`, present from discovery onward; while TRUE the generic repository waits for its bounded result and the mailbox remains available. Providers without this field retain synchronous behavior. A mailbox `Accepted` acknowledgement means the login request was consumed, **not** that credentials were accepted; login succeeds only when the resulting access snapshot has `LoginFailed = FALSE`, `CurrentUser` equal to the requested user, and `CurrentLevel > NONE`. On failure the dialog stays open, clears the secret field, and shows a localized generic user/PIN error (never reveals which credential was wrong). **Shipped default policy is fully open** (all thresholds `NONE`) — a station may require no login at all. The settings view edits the selected root's persistent policy through append-only mailbox kinds `SET_ACCESS_LEVEL=24` and `SET_SESSION_TIMEOUT=25`, serially; both are PLC-rechecked against `ACCESS_POLICY`, and the PLC rejects raising that threshold above the active session level to prevent retained self-lockout. The PLC re-checks all mutations, including decisions, power, shelving, force, and configuration writes. Accepted privileged mutations and denied attempts land in the §8.3 ring without secrets.

## Alarm shelving & rationalization (§8.9/§8.10)
Units publish the generated rationalization catalog (`Meta`: per-ReasonCode priority, category, operator action, consequence, and shelvable flag) which the HMI joins onto events by `reasonCode` — the alarm row shows *what to do*. The HMI carries the same generated catalog as a deterministic fallback for a partial/older manifest, while the PLC remains authoritative for alarm behavior. A record with no operator action is an event and is not rendered as an actionable alarm. Active alarms carry `Shelved`; a shelved alarm is **de-emphasized (never hidden) in lists and excluded from the banner** — annunciation only: **Blocking, interlocks, and release reports are untouched**. Shelve/unshelve via `shelveAlarm`/`unshelveAlarm` (ALARM_SHELVE-gated §7.7, act-or-explain §7.8, PLC re-checks: SAFETY never shelvable, unrationalized reasons refuse). Shelves auto-expire in the PLC (time-bounded); every shelve/unshelve/expiry is a §8.3 event.

## OEE (§8.5.1)
Units publish `Oee` (run/down/idle ms buckets + Availability/Performance/Quality/OEE, each with a validity flag) and `OeeTrend` (bounded sample ring). The HMI renders an OEE facet: factors + OEE% with **exception-based colouring** (muted at/above target, amber/red below) and a **sparkline** from the ring. **Invalid factors render as '—' and are omitted from the product — never assumed 100%** (O7). `resetOee` is DATA_WRITE-gated (§7.7), audited (§8.3), and follows act-or-explain (§7.8). Long-horizon trending is the historian's job, not the ring's.

## Digital nameplate (§3.10.1)
A module with a non-empty `Nameplate` (`ST_Nameplate`: product URI, manufacturer, designation, serial, year, HW/FW/SW versions, order code, documentation URL) renders a **nameplate facet card** on its detail view — identity, versions, and a tappable documentation link. Read-only by contract: identity, not configuration (outside §3.8/§7.7 entirely). Empty nameplate = no card. Root Units always publish one; any module may (a purchased CM keeps its own identity). Projection to AAS/IEC 63278 (IDTA 02006 Digital Nameplate et al.) is Annex K.

## Release panel (§7.8) — "why is this blocked?"
Pressing a blocked control (Start, or a manual command) never silently no-ops: it opens a **persistent bottom panel immediately** in a localized “checking release conditions” state, then calls the pure query `releaseReportStart(unitPath)` or `releaseReportManual(unitPath,targetPath,value)` and renders the FULL rollup — every unmet precondition at once (mode, access, active alarm, and each failed interlock), each with its localized description, kind icon, numeric reason, and qualified owning `SourcePath`. The manual query includes the selected command value because directional interlocks may differ. The panel stays while blocked and can be dismissed; while open it refreshes at a controlled, non-overlapping interval, and when the action releases it shows a brief 'now released'. A repository snapshot emitted by a query acknowledgement **shall not itself trigger another query** (that feedback loop can flood the PLC mailbox). The query computes the same predicate the gate uses (no drift). Interlock reasons reuse the §7.2 PermIntlk descriptions. **Every** gated control follows act-or-explain — Start/Stop/step/reset/changeover/manual open the release panel when blocked; channel force (fieldbus-scoped) explains inline. No gated control is ever a silent dead button. If a rejected action yields no reasons, the panel explicitly reports the contract/publication defect rather than rendering an empty area.

## Mode bar (§3.4.1/§3.4.2)
Right-side vertical bar controlling the selected module's owning Unit: **mode selector** (current-mode icon on top, menu of `supportedModes`), **play/stop** at the bottom (play = `start`; while running it becomes a red stop = graceful `stop`, finishing the sequence — reads `running`), and an optional **step toggle** cycling CONTINUOUS→SINGLE_STEP→HOLD_TO_RUN for modes whose `supportedRunStyles` allow it (`setRunStyle`; SINGLE_STEP shows a step button → `stepRequest`; HOLD_TO_RUN shows a press-and-hold → `setHoldRun`). **MANUAL shows no play/stop/step** (no sequence). The stop button **blinks** while `stopPending` (stop requested, sequence still finishing) and is non-interactive during that window. Per-step `steppable` (default true) means some steps run through even in step mode (published on `CurrentStep`). Mode changes honour the per-mode `modePolicy` (§3.4.1): `blockedWhileRunning` refuses with a hint, `confirm` prompts (graceful "finish & switch" vs immediate "interrupt & switch"), `interruptible` proceeds. **Hold-to-run is NON-SAFETY** (§3.4.2/§9) — never a dead-man. All gated by MODE_CHANGE/START_STOP (§7.7).

## Show-why-blocked (§7.6.0)
## Manual commands (§7.6.1)
Each CM/EM publishes a **command catalog** (`{value,label}` list); the HMI renders a button per entry — no per-type code. A command is issued via `manualCommand(unitPath, targetPath, value)` and accepted **only** when the owning Unit is in `MANUAL` mode (§3.4) **and** the user holds `MANUAL` access (§7.7); it routes *through* the module (interlocks/first-out/timing still apply — the opposite of a fieldbus force). Every accept/reject is a §8.3 event. The panel is visually distinct from the fieldbus force (bordered 'Manual commands' card on the module) so the two risk levels are never confused. Single path only — no mode-bypass override.

## Write surface (deliberately narrow, §14)
Writes are limited to module `Command` + `Execute`/`Abort`, `DecisionAnswer`, Unit mode/run-style/start/stop/step/hold, release-gated manual commands and bounded lamp test, alarm reset/shelving, model/configuration changes, and explicitly authorized channel force. Every path is gated and re-checked by the PLC; commands are never queued across connection loss.

For a guided model change, the HMI writes `CHANGEOVER` mode, submits the selected model through the
transactional model request, then starts the Unit sequence. The live `CurrentStep` and `Decision`
records drive the instructions and confirmation buttons; no press- or station-specific page is used.

Every transport adapter shall issue those operations through the root Unit's
typed request/response mailbox; it never calls PLC-language methods or exposes a
generic symbol/tag write. Arguments are written first and the nonzero commit
sequence last. The Unit samples a new sequence once, routes it through the same
operations and release gates used internally, clears transported secrets, and
writes the matching acknowledgement only after processing. TC3 names these
records `HmiRequest : ST_HmiRequest` / `HmiResponse : ST_HmiResponse`; AB uses
the logical schema in Part III §7.7 and freezes its physical layout after S9/S12.
See `OPCUA_TRANSPORT.md` for the TC3 mapping.

The repository shall serialize each mailbox transaction, shall not allow a
periodic refresh to starve its writes, and shall wait for any already-running
refresh before evaluating acknowledgement data. Control success means the exact
`Sequence` was acknowledged and `Accepted=TRUE`; rejection and timeout are
different results, and the PLC's localizable `Diagnostic` is logged/displayed
for a rejection. Static browse discovery should be cached for the session;
cyclic updates use subscriptions or bounded batch reads rather than recursively
rediscovering the complete hierarchy every refresh interval.
The repository gateway exposes the same tier capability as any direct adapter
through versioned path discovery, compact tier indices, and bounded targeted reads. The
gateway intersects every connected browser's slow/on-demand sets before changing
its one shared PLC session, so one client can never reduce another client's live
surface. Optional deployment `read-root` subtrees filter snapshots, discovery,
tier setup, and targeted reads consistently; the selected PLC/transport
authorization remains the primary confidentiality boundary when no additional
gateway read scope is set.
Discovery shall canonicalize module identity before rendering. `Status.Name` is
the qualified dotted identity (`Root.Child`); a real module's declared local
segment equals the final segment of that identity. Candidates are deduplicated
by the complete `Status.Name`, and declared parent/root identity must agree with
its dotted prefix. TC3 chooses the shallowest matching OPC UA path and rejects a
`REFERENCE TO`/owner alias whose local browse segment disagrees; AB rejects an
inconsistent manifest ID/path/parent row. Duplicate root identities are a
contract/deployment diagnostic and shall never be passed unchanged into station
selectors.

## Line calendar and shift history (Core §3.8e / §8.5.2)

Calendar V3 adds `line.shift.<index>.productionTarget` (good parts, 0 unset)
and may increase the declared shift capacity; the weekday editor recognizes
any positive declared row index, including the fifth row. Configuration is
still read from the complete PLC page and written through its capability gates.
`ShiftProductionTarget` is the PLC-latched target for the current interval;
`ShiftHistory[index]/ProductionTarget` is its immutable closing snapshot.
The Shift card renders current `GoodCount / target`, attainment percentage and
a bar capped visually at 100%, while percentages may exceed 100%. Its history
table shows each record's own target and attainment. NOK/rework do not count
toward the good-part goal. Zero shows an unconfigured target and no progress
bar; absent target leaves legacy binding presentation unchanged. The client
never looks up today's calendar to assign targets to old records.

Line config uses the normal `LINE_CFG` capability editor. For calendar
V2, `line.shift.<1..MAX_SHIFTS>.activeDays` is an integer mask 0..127 rendered
as seven translated weekday checkboxes, Monday bit 0 through Sunday bit 6.
The controls use the selected interaction preset and shared inline spacing;
effective PLC read/write permissions still govern their input and Save action.
Start and duration remain bounded number capabilities in minutes. A parameter
set is a complete calendar transaction, validated on the PLC before commit.

A root publishes `CurrentShift`, `ShiftStartedAt`, the bounded
`ShiftHistory`/`ShiftHistoryCount` and `ShiftHistoryTruncated`. Calendar V2 may
also publish `ShiftEndsAt`, `ShiftTimeSynchronized` and `ShiftCalendarPending`.
The facet exists when `CurrentShift` is present, including 0 (Unscheduled),
and is absent when the root has no line. Show the next boundary and pending
calendar changes. Relative elapsed/remaining display is an approximate clock
view, shown only with verified clock quality; it never accumulates production.

Each closed row carries its controller-owned boundary times, time-quality and
manual-reset flags, good/NOK/rework counts, run/down/idle milliseconds and OEE
factors with their validity flags. The generic table displays those quantities;
an invalid factor is shown as an em dash, and unverified or partial records are
marked. The UI never reconstructs shift history from polls or clears totals.
Version 1 producers retain their existing daily calendar and history shape;
missing V2 optional fields do not invent a boundary or pending edit.

## Known deferred (tracked)
§8.3(d) `I_EventSink` historian implementations (OPC UA A&C / SQL / MES
adapters — interface is normative and shipped; adapters are deployment work) and
external §11.6 `I_HostEventSink` deliveries. The fixed bounded `HostEvents`
Self-Description projection (OPC UA in TC3), HMI hydration, and §8.8/§8.9
generated catalog are shipped and
freshness-checked; historian/MES/REST/MQTT delivery adapters remain deployment
profiles. Core §8.10's optional Alarm-performance profile (long-window
rate/standing/stale/chatter/flood analytics) is likewise owned once by the chosen
station/line aggregator or historian, not duplicated in every root HMI. Unknown external/application reasons still fall back to the PLC
diagnostic description and require a complete runtime rationalization before
they may be shelved.

## Fieldbus channel state (§10.5.1)

The topology subtree is on-demand — identity, addressing and diagnostic text are
large and only feed the bus page. **The channel value is the exception and is live**:
`Channels[i]/BoolValue` and `Channels[i]/AnalogValue` are classified `live` even
though they sit inside an on-demand container, because an operator watches an
interlock that will not clear or a sensor that never comes on without opening the
bus page at all. It is one leaf per channel, so the promotion costs a fraction of
the subtree it lives in; `Address`, `Path`, `Diagnostic`, `Forced` and `Quality`
stay gated.

A leaf-level `liveLeaves` rule is checked **before** the container rules, which is
what lets it outrank the subtree it belongs to.

## Derived state flags (§3.12)

| PLC symbol | Type | HMI use |
|---|---|---|
| `<module>/StateFlagCount` | INT | published length of the table below |
| `<module>/StateFlags[i]/Key` | STRING | localization key. **Empty ⇒ the slot was never published**: skip it, do not render a nameless chip |
| `<module>/StateFlags[i]/Value` | BOOL | the fact, as of this scan |
| `<module>/StateFlags[i]/Since` | DT | when `Value` last **changed** — not when it was last written. Render as a duration ("closed · 4s") |
| `<module>/StateFlags[i]/Stale` | BOOL | the PLC stopped publishing this flag. Render as **unknown**, never as a confident "off" — the PLC has already forced `Value` false, and showing that as a claim would be inventing one |

These are `OutImm`-role values: facts recomputed every scan from what is actually
true underneath, as opposed to `OutCmd`, which is what a command produced and stays
latched until the next one. Any module of any tier may publish them, so the HMI
renders them generically from the key — it never needs to know the module type.

## Sequence flow chart (§3.13)

| PLC symbol | Type | HMI use |
|---|---|---|
| `<module>/SequenceViewEnabled` | BOOL | shows or hides the **Sequence** tab for that module. The PLC owns this: a type too simple to be worth drawing leaves it FALSE, a Unit defaults TRUE and may vary it per mode. The HMI never infers it from the module type. |
| `<unit>/SequenceStepCount` | INT | published length of the rows below; a row beyond it is ignored even if present on the wire |
| `<unit>/SequenceSteps[i]/StepNo` | INT | row label (`N100`) and the key matched against `CurrentStep/StepNo` to find the active row |
| `<unit>/SequenceSteps[i]/StepName` | STRING | localization key for the row title. **Served by the §3.10.2 config manifest**, not cyclically — see below |
| `<unit>/SequenceSteps[i]/Branch` | INT | §6.12 concurrent leg. 0 = the chain's main line; >0 indents the row under the fork and shows a `∥n` badge |
| `<unit>/SequenceSteps[i]/Active` | BOOL | **this row is running now.** With a parallel step several rows are Active at once, which is why liveness may not be derived from `CurrentStep` |
| `<unit>/SequenceSteps[i]/Elapsed` | TIME | that row's own clock |
| `<unit>/SequenceSteps[i]/TimedOut` | BOOL | that row outran its own `ExpectedTime` — a leg's guard, since the §6.9 stall watchdog follows the main line only |
| `<unit>/SequenceSteps[i]/AwaitingLabel` | STRING | secondary line, e.g. `PressRam.EXTEND`. Manifest-served |
| `<unit>/SequenceSteps[i]/AwaitsPath` | STRING | **drill-down target.** Non-empty ⇒ the row is click-through and selects that module. Empty ⇒ tapping opens the step detail instead |
| `<unit>/SequenceSteps[i]/TimeClass` | E_TimeClass | shown in the step detail |
| `<unit>/SequenceSteps[i]/ExpectedTime` | TIME | the guard drawn beside the elapsed time (`1.4 s / 2.0 s`); 0 = no guard |
| `<unit>/SequenceSteps[i]/Visited` | BOOL | dims rows the chain has not reached yet |
| `<unit>/SequenceSteps[i]/LastDuration` | TIME | elapsed shown on an inactive row |
| `<unit>/SequenceSteps[i]/ErrorActive` | BOOL | this row raised an error (§6.9(d)). Marks the row red **whether or not it is still the active one**, unlike a timeout. **This flag is authoritative** — see the annotation table |
| `<unit>/SequenceSteps[i]/WarningActive` | BOOL | this row raised a **non-blocking** message (§6.9(e)). Steady mark, never the error blink — nothing stopped |
| `<unit>/CurrentStepElapsed` | TIME | elapsed shown on the **active** row |
| `<unit>/CurrentStepTimedOut` | BOOL | active row blinks between surface and error container |

**Liveness is per row (§6.12).** A chain with a parallel step has one Active row per
leg, so the HMI shall highlight every Active row and show each one's own `Elapsed`.
When **no** row reports Active — an older runtime that does not publish it — the HMI
shall fall back to matching `CurrentStep/StepNo`, which is the pre-§6.12 behaviour, so
the tab never goes blank against an older PLC. `CurrentStepElapsed` and
`CurrentStepTimedOut` remain the **main line's** clock and guard.

**A row arrives from three places, and the HMI joins them.** The row was split by
how often each part changes, so that a 128-row chart costs ~47 kB per Unit instead of
~145 kB:

| part | where it comes from | changes |
|---|---|---|
| `StepNo`, `Branch`, `TimeClass`, `ExpectedTime`, `StepName`, `AwaitingLabel`, `AwaitsPath` | the **§3.10.2 config manifest**, published under these same `SequenceSteps[i]/…` repository paths | never, after first visit |
| `Active`, `Elapsed`, `TimedOut` | the `ActiveSteps` **cursor**, one entry per concurrent leg, joined by `RowIdx` — **live tier** | per scan |
| `Visited`, `LastDuration`, `ErrorActive`, `WarningActive` | the `SequenceSteps` array (on-demand read) | over time, per row |
| the text and link of an error/message | the `SequenceAnnotations` table, joined by `RowIdx` | rarely, and sparse |

| PLC symbol | Type | HMI use |
|---|---|---|
| `<unit>/ActiveSteps[b]/RowIdx` | INT | the `SequenceSteps` row leg `b` is running. **0 ⇒ that leg has no active step.** A row is `Active` exactly when some leg's cursor points at it |
| `<unit>/ActiveSteps[b]/Elapsed` | TIME | how long that row has been running |
| `<unit>/ActiveSteps[b]/TimedOut` | BOOL | it outran its own `ExpectedTime` — the leg's own guard |

The cursor is indexed **by branch** (0 = main line), so it is ~10 entries however long
the chain is. It is small enough to stay in the cyclic read, which is what makes the
chart correct the instant its tab opens instead of after the first on-demand read.

**What the HMI shall NOT reconstruct.** `Visited`, `LastDuration`, `ErrorActive` and
`WarningActive` stay per-row and PLC-authoritative, and a client **shall not** derive
them by watching the cursor. The HMI polls at a few Hz; the PLC steps at scan rate, so
a step shorter than one poll interval is never observed. A chart that accumulated these
client-side would silently skip fast steps, mistime visits, and lose transient errors
entirely — it would show what the client happened to catch rather than what the chain
did (§1.1 O3).

Because the manifest reproduces the live half's repository paths, the mapper reads
`SequenceSteps[i]/StepName` without knowing it arrived by a different route. The HMI
should cache manifest values and re-fetch on `Status/ConfigRev`.

| PLC symbol | Type | HMI use |
|---|---|---|
| `<unit>/SequenceAnnotationCount` | INT | published length of the note table |
| `<unit>/SequenceAnnotations[i]/RowIdx` | INT | the `SequenceSteps` row this note belongs to. **0 ⇒ a freed slot**: skip it, it is not a note |
| `<unit>/SequenceAnnotations[i]/IsError` | BOOL | TRUE = §6.9(d) raise (the chain stopped), FALSE = §6.9(e) message |
| `<unit>/SequenceAnnotations[i]/Key` | STRING | localization key of the reason or message |
| `<unit>/SequenceAnnotations[i]/SourcePath` | STRING | module to drill into; empty ⇒ the Unit itself |

**The row flag is authoritative, not the note.** The note table is small on purpose;
if it fills, the PLC keeps `ErrorActive`/`WarningActive` and drops only the text. The
HMI shall therefore colour a row from its flag and treat a missing note as "nothing
more to say" — deriving the mark from the note would silently unmark a real failure.

**The rows are an on-demand subtree.** `SequenceSteps` is bounded at
`MAX_SEQUENCE_STEPS` (128) × 17 fields = 2176 nodes per Unit and feeds exactly one
view, so it **shall** be read by a targeted batch while the Sequence tab is open and
**never** in the cyclic snapshot — the same treatment as the rings and trends (§3.10,
§1.1 O4). `SequenceViewEnabled`, `SequenceStepCount`, `CurrentStepElapsed` and
`CurrentStepTimedOut` are leaves at the module root and stay live.

Consequently the **tab's existence is decided by `SequenceStepCount`, not by the rows**.
Gating it on the rows would deadlock: no tab → no on-demand read → no rows → no tab.

**The chart belongs to the ACTIVE mode.** The PLC clears the row table when a mode
commits, so `SequenceStepCount` drops to 0 and rebuilds as the new chain runs. The HMI
therefore renders whatever is published without filtering by mode, and must tolerate
the count going to 0 and back up — that is a mode change, not a lost connection.

**The inventory is discovered, not authored.** The PLC registers each step the
first time it runs, so a chain author writes nothing and a step not yet reached is
simply absent — the chart shows what the chain has actually done, never a
hand-maintained drawing that can drift from the code.

**A raised error supplies the link `Awaits` could not.** When a step raises an
error explicitly (Core §6.9(d)) — a child commanded behind an `IF`, or an
application rule — the PLC stamps that row's `ErrorActive` and `ErrorSourcePath`.
The HMI shall resolve a row's target most-specific-first — `ErrorSourcePath`, then
`WarningSourcePath`, then `AwaitsPath`: the operator wants the module that actually
went wrong, not the one the step nominally commands.
A row with neither stays non-click-through and opens its detail, where the raised
error is listed. The marks are cleared by the PLC when the error state ends, so a
stale red row is a PLC contract violation, not something the HMI ages out.

**A message is not an error.** `WarningActive` reports a condition the chain
**handled** — press AUTO `N180` (two-hand released while the door closes) and `N200`
(the ram did not reach, which the chain confirms and scraps) both use it. The row is
tinted steadily and carries an info marker; it shall never blink, never be coloured
`error`, and never be counted as a fault. It still supplies a drill-down link through
`WarningSourcePath`, which is how `N200` stays click-through to the ram with
`AwaitsPath` empty. The PLC clears the mark when the step is entered again, so an
amber row means "this is what happened on the last pass".

**`AwaitsPath` is the "direct wiring" rule.** A row is click-through only when the
step *declared* the module it commands through `Awaits`; no `IF`/`CASE` chose it.
A step that drops its await — to own that child's failure and disposition it
itself, as press AUTO `N200` does — publishes an empty path and is deliberately
not click-through. The HMI must not guess a target from the label.


### Optional runtime model catalog and current-value export

| Published value | HMI use |
| --- | --- |
| `ModelCapacity` > 0 | Show **New model** with the current catalog count and capacity. |
| `AvailableModels[*].ModelCode` | Source-model selection, uniqueness feedback and the existing edit/changeover selectors. |
| `Features/ExportCurrentConfig` = TRUE | Show **Export current values** on each supported configuration card. |

**New model** sends CREATE_MODEL (37): `NameValue` is the new code; `IntValue`
selects the source model (0 = running); `BoolValue = TRUE` selects a saved Model
set named by `TextValue`. The dialog states that creation is inactive, remains
open on refusal, and closes only after acknowledgement. It requires CONFIG_SET
and DATA_WRITE to offer the action; the PLC rechecks every copied value's read
and write permissions. Creating an inactive model does not require READY.
A Model set offers **Create model from set** when the root advertises capacity;
this does not load into the running recipe. Activation uses ordinary Changeover.

**Export current values** sends EXPORT_CURRENT_CONFIG (38) with `TextValue`
for the export name, `IntValue` for ConfigKind and `DurationMs` for the model
index (0 = running). Header line zero and successive EXPORT_CONFIG_SET lines
form one immutable, connection-scoped document. The client generates a fresh
128-bit hexadecimal token in `NameValue` for the header and every continuation.
TC3 binds its cursor to that token, the PLC session generation and the exact
next line. Logout, an intervening operation, a foreign token or an out-of-order
line invalidates the cursor. Saved-set exports keep `NameValue` empty. Any missing/refused line rejects
the entire export. A current export does not consume a saved-set slot. Current
and saved exports offer **Download file** (`.jsonl`, UTF-8) and Copy.

Missing/zero ModelCapacity hides creation; a missing/false export feature hides
current export. Capability absence never implies a platform-specific fallback.
