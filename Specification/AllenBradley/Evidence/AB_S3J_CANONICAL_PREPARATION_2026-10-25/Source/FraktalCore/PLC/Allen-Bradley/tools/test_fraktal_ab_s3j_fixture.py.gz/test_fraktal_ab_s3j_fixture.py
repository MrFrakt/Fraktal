"""S3j word apparatus: exact arm, bounded writes, independent captures, cleanup."""
from copy import deepcopy
from pathlib import Path
import json
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import fraktal_ab_s3j_io_execute as fixture


class WordFixtureTests(unittest.TestCase):
    def test_current_exact_image_authorization_required_before_any_connection(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'approval.json';pin='A'*64
            base=dict(CurrentOwnerApproved=True,S3jIoVectorsAuthorized=True,Serial=fixture.SERIAL,
                      CanonicalSha256=pin,FaultClearAuthorized=False,ClockSetAuthorized=False)
            path.write_text(json.dumps(base));self.assertEqual(fixture.authorize(path,pin),base)
            for field,value in (('CurrentOwnerApproved',False),('S3jIoVectorsAuthorized',False),('Serial','00000000'),
                                ('CanonicalSha256','B'*64),('ClockSetAuthorized',True),('FaultClearAuthorized',True)):
                path.write_text(json.dumps(dict(base,**{field:value})))
                with self.subTest(field=field),self.assertRaisesRegex(Exception,'current exact-image'):fixture.authorize(path,pin)

    def run_fixture(self,*,failure=False):
        original=dict(InputWord=7,OutputWord=8,FaultWord=0,InputValid=1,OutputValid=1,FaultValid=1,ForcedWord=0,ForcePermitted=0)
        live=deepcopy(original);writes=[];guards=[];captures=[];failed=False
        class Comm:
            def guard(self):guards.append(1)
            def Write(self,tag,value):
                nonlocal failed
                writes.append((tag,value))
                if failure and not failed and len(writes)==4:
                    failed=True;return SimpleNamespace(Status='refused')
                live[tag.rsplit('.',1)[1]]=value;return SimpleNamespace(Status='Success')
            def Read(self,tag):return SimpleNamespace(Status='Success',Value=0)
        run=fixture.WordRun(Comm(),Path('unused.json'))
        run.guard=lambda:guards.append(1)
        run.observe=lambda phase:captures.append(phase)
        with patch.object(fixture.reader,'read_document',return_value=({},dict(manifest=dict(contentHash=fixture.publication.manifest_values(run.app)['ContentHash'])))), \
             patch.object(fixture.execute,'read_layout',side_effect=lambda *args:deepcopy(live)):
            evidence=run.execute()
        self.assertEqual(live,original);self.assertTrue(evidence['sourceRestored'])
        self.assertEqual({tag for tag,value in writes},run.allowed)
        self.assertTrue(all(type(v) is int for tag,v in writes))
        self.assertGreaterEqual(len(guards),len(writes))
        return evidence,writes,captures

    def test_all_nine_vectors_restore_all_words_and_use_ten_observations(self):
        e,w,c=self.run_fixture();self.assertTrue(e['passed']);self.assertEqual(len(e['rows']),9)
        self.assertEqual(len(w),80);self.assertEqual(len(c),10);self.assertEqual(c[-1],'source_restored')
        self.assertTrue(all(tag.startswith(fixture.SOURCE+'.') for tag,value in w))

    def test_partial_write_failure_restores_original_and_stops_vectors(self):
        e,w,c=self.run_fixture(failure=True);self.assertFalse(e['passed'])
        self.assertEqual(e['rows'],[]);self.assertEqual(len(w),12);self.assertEqual(c,['source_restored'])


if __name__=='__main__':unittest.main()
