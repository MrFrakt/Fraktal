# Part III canonical publication amendment — approved target draft

2026-10-20. **Owner-approved target; not yet effective.** This is proposed replacement text for the named
clauses, based on [S0 evidence](Evidence/AB_S0_CANONICAL_TYPES_2026-10-20.md)
and [the V2 draft](AB_FROZEN_CONTRACTS_V2.json). Part III and frozen contracts
V1 remain authoritative for the shipping implementation. Approval settles the
target contract; it does not establish implementation or runtime conformance.
S1–S7 retain the implementation plan's gates.

Owner approval on 2026-10-20: “Approve drafts and proceed to S1”. This approves
the target contract and S1 work; additional controller changes require their
own current authorization. The archived S0 review drafts remain historical.

The owner-approved S3f and S3g finite corrections extend this target draft.
S3g binds the 64 consumed OEE values to exact Core REAL arithmetic, 101
numeric paths to the full UInt32 domain and 35 to Int16. Its separately
approved 224 dependent values follow those Core arithmetic/count semantics;
all 631 other S3g values/types stay exact. The [plan §1](AB_CANONICAL_PUBLICATION_PLAN_2026-10-20.md)
links the enumerations. This records the approved target, without activating
Part III/V2 or establishing runtime acceptance.

## AB §1, §2.1 and §4.1 — reference profile

The reference profile is a CIP Security-capable CompactLogix 5380 or
ControlLogix 5580 at firmware v37 or above. Each different family/revision
requires the applicable compiler, type-map, transport and runtime qualification.
The development bench is FactoryTalk Logix Echo emulating a 1756-L81E at
38.011; simulation evidence is identified as such and grants no physical fit,
retention, I/O or CIP Security acceptance.

The 1769-L24ER-QB1B/v33 is retired as a reference target. Its dated evidence
and V1 contract remain history at their recorded scope. A future constrained
profile uses this same canonical architecture and declares its reductions;
it does not introduce a station-specific projection architecture.

## AB §3.8 — type map V2

The PLC publishes the logical Core contract itself. Type bindings are defined
by frozen contracts V2; the manifest supplies logical information absent from
the controller's native type system. A client never infers logical type or
array bounds from a member's name or a station declaration.

- BOOL members are native. A reader honors template offsets and bit metadata.
  Native BOOL arrays may be described as DWORD storage; the manifest supplies
  their logical Boolean type, lower bound and element count. Only that logical
  extent enters the canonical snapshot.
- SINT, INT, DINT, REAL, LINT and LREAL are native. Core enum ordinals remain
  generated DINT constants. Int64 transport uses exact integers/decimal
  strings and never passes through a float. Generation preserves the declared
  floating-point precision; an untyped REAL literal widened into LREAL is not
  a conforming full-precision initializer. Supplementary S0 qualifies the ST
  `L` suffix and typed Decorated LREAL initial data on Echo v38: pi and
  1.0000000000000002 are preserved exactly.
- **D6: Core TIME binds to DINT milliseconds**, with the manifest logical type
  DURATION and wire ordinal 3. Its signed 32-bit range and millisecond units
  match Core directly. Native TIME32 has microsecond units and insufficient
  range for this contract; native TIME has 64-bit microseconds. Neither is
  substituted for the published DINT representation. An internal native time
  value is converted and range-checked by its owning provider before publication.
- **D7: Core timestamps bind to native LDT**, 64-bit Unix nanoseconds, mapped
  to UTC DateTime; zero retains Core's unset meaning. Snapshot encoding is an
  ISO UTC string with three to nine fractional digits, or numeric zero for
  unset. Retain at least three digits to match the existing millisecond
  spelling; retain additional digits when required for exact nanoseconds.
  Conversion from a microsecond clock is owned once by its provider. A LINT
  supplied to the time-type assignment is a nanosecond value: S0 measured a
  microsecond LINT assigned to DT being divided by 1,000, while nanoseconds
  assigned to LDT were preserved exactly.
- Strings retain the owning Core/application byte capacities. A StringFamily
  is recognized from its LEN DINT / DATA SINT[n] template shape. LEN counts
  UTF-8 bytes. Generation rejects an over-width literal; acquisition rejects
  invalid length or encoding rather than truncating it.

Canonical array indices equal the declared Core indices. Logix physical
storage starts at zero; the manifest supplies logical lower bound and element
count. Packed Boolean bits are expanded before that bound is applied.
The five V1 corrections are exactly ActiveSteps, ModePolicy,
SupportedModesPublished, SupportedRunStylesPublished and Access.Policy.Required,
all changing from lower bound 1 to 0. Other arrays keep their Core bounds.

The owner selected preservation of the oracle's logical path set on 2026-10-21.
Reserved physical slots do not automatically become published logical entries.
The V6.1 candidate carries explicit selected indices and same-root live count
references in its PLC-resident manifest; these are range/type checked against
the native template and the acquired record. Empty views still validate their
full annotation schema. See the [S3a wire draft](AB_CANONICAL_PUBLICATION_S3A_WIRE_DRAFT_2026-10-21.md).
This adds no station declaration or name-based inference to the client and
does not expand the five permitted D2 differences.

The native units and LINT conversion rule agree with Rockwell's
[time and date type documentation](https://www.rockwellautomation.com/en-us/docs/studio-5000-logix-designer/37-01/contents-ditamap/instruction-set/time-and-date-data-types.html).
The D6/D7 selections above are binding decisions from the measurements, not a
claim that Rockwell prescribes those Fraktal representations.

## AB §3.10 — canonical exposure and self-description

Each deployed root is one controller-scope tag named exactly as its local
browse name. Its record declares the standard Status contract; children are
records named exactly as their local instance/schematic names. Status.Name
carries the qualified Fraktal identity. Infrastructure, private state and
reference aliases do not create additional roots.

Discovery uses the controller's Symbol object (0x6B), Template object (0x6C)
and validated PLC-resident manifest. A module is recognized through its Status
contract, as on TC3 and TIA. The structure flag and complete 12-bit template
handle govern references; a handle's low byte matching an atomic code does not
make the referenced record an atomic type.

The new physical manifest major is 6. It describes canonical paths and carries
logical types, logical array bounds/extents, and effective member access
where native Template metadata is insufficient. These facts are derived from
the same owning declarations as the UDTs and their access settings. Physical word count cannot replace logical Boolean
element count. Static metadata is cached by the validated manifest content hash
and configuration revision; existing coherence, invalid-manifest and
incompatible-major refusals remain.

The S3c V6.2 candidate adds explicit bindings from separate scalar data
records to discovered roots, with disjoint native leaves and matching array
containers. Step definitions can be cached outside cyclic whole-root reads;
FragmentRevision invalidates their values independently of the schema hash.
History remains PLC-owned. See the [V6.2 draft](AB_CANONICAL_PUBLICATION_S3C_WIRE_DRAFT_2026-10-22.md).
This is a staged implementation proposal; shipping activation is still gated.

Published data is effectively Read Only, HmiRequest alone is effectively
Read/Write, and private storage has access None. The generated access audit
proves the effective leaf policy. A writable mailbox requires Read/Write on
its ancestors; other public branches are Read Only. Private None members are
kept outside records that a client reads whole. Supplementary S0 measured that
a Read Only parent denies its Read/Write child, and a None member blocks the
whole record read. The captured Template metadata does not distinguish member
permissions, so the manifest publishes them; a client does not infer them from
pylogix access properties or a station declaration. These findings and the
2 MiB fragmented-read qualification are recorded in
[supplementary evidence](Evidence/AB_S0_SUPPLEMENTARY_RUNTIME_2026-10-21.md).

The client decodes the PLC-owned contract. There is no runtime station
declaration, client-owned derivation, hard-coded station tree, or station HMI
screen. During S2–S3, old contexts coexist only for migration/equivalence; S6
removes them after all harnesses and adapters have moved.

## AB §11.1 — desktop and gateway topology (D9)

One generic CipSessionClient in fraktal_opcua_client emits
fraktal.opcua.snapshot.v1. The desktop selects it through cip://. The Dart
gateway uses the same client for Web clients, as it does for ADS and S7 Web API.
The PLC's canonical tree and manifest are the sole runtime description.

Direct writes require a commissioned CIP Security session proved on capable
hardware. Without it, direct CIP is explicitly read-only in the HMI. Echo
implements no CIP Security, so direct desktop acceptance on Echo is read-only.

Commands on the Echo/isolated gateway path use the existing authenticated
wss:// gateway posture, recorded per-deployment write choice, root scope and
PLC mailbox gates. Browser clients do not open raw CIP sockets. Existing
§11.2.1 authenticated-principal, least-privilege and no-anonymous-write rules
remain in force for a write-enabled production deployment.

Every mailbox transaction is serialized. All argument writes must succeed
before a separate Sequence commit. Success requires the matching PLC
acknowledgement and acceptance; timeouts and reconnects never replay a request.
CIP sample receipt time is recorded without inventing device source time or
clock synchronization.

## Approval and implementation boundary

The owner approved this target draft on 2026-10-20; it is not yet effective.
Supplementary S0 size/fragmentation, root-name, effective access and precise
LREAL vectors now pass at their recorded Echo scope. Per-surface Capacity,
native scan and S2-S6 implementation/equivalence, plus S7 physical/security
acceptance, remain open. The 2 MiB UDT qualification is not a global array-tag
size limit or a frozen application/manifest capacity.

## Approved S3f correction (offline implementation, 2026-10-23)

The owner approved the explicit configuration correction in
`call_eead11c567404709986d61b2907a3d61:0`. See its
[enumerated review](AB_CANONICAL_PUBLICATION_S3F_CONTRACT_REVIEW_2026-10-22.md)
and [V6.3 wire draft](AB_CANONICAL_PUBLICATION_S3F_WIRE_DRAFT_2026-10-23.md).
The target now includes bounded PLC-owned pages, the 110 corrected Core types,
12 missing Core fields, PLC-owned revision/absolute time and a validated
PLC-held medium-provider response. This amends the oracle only at that explicit
scope; the five D2 array-bound changes remain the entire bound-change list.

SetSchema's Core UINT is carried by a native DINT with logical UINT16 and
checked 0..65535 range. The generic reader returns UInt16. Revisions retain
the full UInt32 bit pattern, counters are native INT, bounds are LREAL and
timestamps LDT. V6.3 hashes versioned service descriptors alongside the existing
fields/bindings. Provider responses use the existing mailbox/session/access
gates, bounded UTF-8 and commit-last staging; no private tag is exposed.

Both native compiler/read-back/access gates and exact-image automatic Capacity
pass for the prepared S3f candidate. Runtime equivalence, native revision/
timestamp/provider behavior, scan/rollback and later stages remain open.
Neither this approval nor QUERY_CONFIG creates a direct-write exception to D9.

## Approved S3g and S3h finite corrections (2026-10-23)

The target includes the [200 S3g Core numeric corrections](AB_CANONICAL_PUBLICATION_S3G_CONTRACT_REVIEW_2026-10-23.md)
and [224 dependent values](AB_CANONICAL_PUBLICATION_S3G_DEPENDENT_VALUES_REVIEW_2026-10-23.md),
including exact Float32 OEE arithmetic and full UInt32 counter visibility.
S3g native acceptance passes at its recorded genealogy/Echo scope; this is
not physical/security acceptance or V2 activation.

The owner approved the [36 S3h type corrections](AB_CANONICAL_PUBLICATION_S3H_CONTRACT_REVIEW_2026-10-23.md):
sixteen UInt32 event sequences, three native INT ring counters and seventeen
LDT timestamps. Unset Part Stamp becomes canonical zero. The other 242 added
paths retain exact types and values. Existing AB genealogy/delivery metadata,
append/epoch/carrier/measurement/tower ownership and consumed bounds remain.
The event ring uses its PLC-published count for occupied physical slots;
measurement scaling occurs in LREAL before publication. Nameplate facts are
initialized by the PLC declaration. S3h offline gates pass; native session,
scan and rollback remain open. These finite lists add no general coercion,
tolerance, ignored path or direct-write exception to D9.

## Approved V6.4 type-scoped manifest (offline, 2026-10-24)

The owner approved [R1's finite wire change](AB_CANONICAL_MANIFEST_V64_CONTRACT_REVIEW_2026-10-24.md).
With the declaration opt-in `canonical_type_manifest`, SchemaMinor=4 replaces
Fields with TypeAnnotations and PathExceptions. TypeAnnotations names the
owning Template type and member, logical type, logical bound/count, sibling
CountMember and effective access; empty type/access means the native mapping
and Read Only. The sparse exception table names explicit index selections.
Bindings/services retain their meanings. ContentHash includes both new tables;
ConfigRevision derives from it. A zero-count table omits its physical array.

The generic reader resolves every type fact through the discovered Template
name/member, then applies the path exceptions. Every physical array needs an
extent, including arrays below empty views. Counts refer to an integer sibling
in the assembled logical tree, including bound metadata records. Missing,
ambiguous or conflicting facts fail closed. Unsupported per-instance facts
and non-sibling count exceptions are refused by generation.

V6.0?6.3 readers/captures and released images remain supported. Canonical
paths, values, logical types, selections and occupied counts are unchanged;
only the configuration identity changes. This is an inactive V2 draft,
not native acceptance or a direct-write exception to D9.

## Approved S3j fieldbus product (offline, 2026-10-24)

The [approved S3j review](AB_CANONICAL_PUBLICATION_S3J_CONTRACT_REVIEW_2026-10-24.md)
adds a separate PLC-owned ST_FieldbusTopology product. Its
[V6.5 wire draft](AB_CANONICAL_PUBLICATION_S3J_WIRE_DRAFT_2026-10-24.md)
retains V6.4 type annotations and adds the DataProducts binding table.
Identity is on demand, state per row/group; clients infer no station facts.
Declared counts stay inside Core's ceilings, with process-word child nodes
for the reviewed over-bound catalog. Node and channel counts/indices are INT,
AnalogValue REAL, flags BOOL and strings at Core widths. Missing sampled words
fail closed. A mapping error is visible. Force capability remains absent
without a registered OUTPUT_FORCING gate. This inactive draft does not grant
controller writes or physical/security acceptance.
